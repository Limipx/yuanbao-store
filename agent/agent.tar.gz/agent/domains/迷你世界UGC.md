# 迷你世界 UGC 3.0 · 领域专长

## 环境硬事实
- `loadstring` **实测返回 nil**；`load` 是 Lua 5.2 的 → 动态执行只能用自写 VM
- Lua 5.1：无 goto / bit32 / table.unpack（用全局 unpack）/ 无整数除法
- `bit` 模块**一定存在**；`os` 只有 date/time/timeMs，**没有 clock**
- `Mini.X.__className_` 恒等于 `"X"`（50 种类型无一例外）

## 引擎元数据铁律（每条都踩过）
`propertys` / `openFunctions` / `openFnArgs` 都是**加载期**读的元数据：
1. **绝不能搬进 OnStart** → 否则属性面板空白、二维表 ID 读不到
2. **元方法（`__index`）不能改名** → 数组返回值失效
3. **开放函数名改名时登记表键必须同步改** → 否则触发器看得到但调用返回 nil
4. **生命周期 OnStart/OnDestroy/OnUpdate 永不改名**（引擎按名字调用）
5. **元数据字符串不要用 `_DEC()`** → 引擎受限环境看不见 chunk 顶层 local
   → 用 `string.char(...)`（纯全局，可达）

## arrayWrapper（数组返回值）
- `getcount == 3` 是**引擎硬编码**查询次序，Lua 只能迎合
- 真机实测序列：`Array > Array > <元素类型> > Array > Array`
- 改动计数（1/2/4/5）全部错位
- 原版只覆盖 String/Number/Bool/Item，其余 46 种返回 `"Unknown"`
- **唯一可安全改进**：`return propertytype.__className_ or "Unknown"`
- 九项细节全部与引擎耦合，动一个就崩

## 二维表
- 上限：500KB / 2000 行 / 512KB
- 单 blob 上限（GitHub 侧）38~40MB，分片建议 3MB
- 无表头行，多列兼容（行号/内容/空）
