import re
import sys
import json
import hashlib
import argparse

# ────────────────────────────── 词法 ──────────────────────────────

KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for",
    "function", "if", "in", "local", "nil", "not", "or", "repeat",
    "return", "then", "true", "until", "while",
}

class Tok:
    __slots__ = ("k", "v", "s", "e")
    def __init__(self, k, v, s, e):
        self.k = k; self.v = v; self.s = s; self.e = e
    def __repr__(self):
        return "Tok(%s,%r,%d)" % (self.k, self.v[:20], self.s)

NUM_RE = re.compile(r'0[xX][0-9a-fA-F]+(?:\.[0-9a-fA-F]*)?(?:[pP][-+]?\d+)?'
                    r'|(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')
NAME_RE = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')


def tokenize(src):
    """返回 token 列表。字符串/注释整体作为一个 token，内部永不重命名。"""
    toks = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        # ---- 注释 ----
        if c == '-' and src.startswith('--', i):
            j = i + 2
            if j < n and src[j] == '[':
                eq = 0
                k = j + 1
                while k < n and src[k] == '=':
                    eq += 1; k += 1
                if k < n and src[k] == '[':
                    close = ']' + '=' * eq + ']'
                    p = src.find(close, k + 1)
                    p = n if p < 0 else p + len(close)
                    toks.append(Tok("comment", src[i:p], i, p)); i = p; continue
            p = src.find('\n', i)
            p = n if p < 0 else p
            toks.append(Tok("comment", src[i:p], i, p)); i = p; continue
        # ---- 长字符串 ----
        if c == '[':
            k = i + 1; eq = 0
            while k < n and src[k] == '=':
                eq += 1; k += 1
            if k < n and src[k] == '[':
                close = ']' + '=' * eq + ']'
                p = src.find(close, k + 1)
                p = n if p < 0 else p + len(close)
                toks.append(Tok("lstring", src[i:p], i, p)); i = p; continue
        # ---- 短字符串 ----
        if c in ('"', "'"):
            p = i + 1
            while p < n:
                if src[p] == '\\':
                    p += 2; continue
                if src[p] == c:
                    p += 1; break
                p += 1
            toks.append(Tok("string", src[i:p], i, p)); i = p; continue
        # ---- 数字 ----
        if c.isdigit() or (c == '.' and i + 1 < n and src[i + 1].isdigit()):
            m = NUM_RE.match(src, i)
            if m and m.end() > i:
                toks.append(Tok("number", m.group(), i, m.end())); i = m.end(); continue
        # ---- 标识符 ----
        if c.isalpha() or c == '_':
            m = NAME_RE.match(src, i)
            v = m.group()
            toks.append(Tok("kw" if v in KEYWORDS else "name", v, i, m.end()))
            i = m.end(); continue
        # ---- 其它（运算符/空白） ----
        toks.append(Tok("op", c, i, i + 1)); i += 1
    return toks


# ──────────────────────── local 名字收集 ────────────────────────

def collect_local_names(toks):
    """
    返回 set：所有「被 local 声明过」的名字。
    覆盖：local a,b  /  local function f / 函数参数 / for i / for k,v in
    保守：拿不准的不收（不收只是不改名，不会出错）。
    """
    names = set()
    t = [x for x in toks if x.k != "comment"]      # 注释不参与
    # 跳过注释后的索引序列
    i, N = 0, len(t)

    def nxt(idx):
        """下一个有效 token 索引（跳过空白 op）"""
        while idx < N and t[idx].k == "op" and t[idx].v.strip() == "":
            idx += 1
        return idx if idx < N else N

    while i < N:
        tk = t[i]
        if tk.k != "kw":
            i += 1; continue

        # ---- local ----
        if tk.v == "local":
            j = nxt(i + 1)
            if j < N and t[j].k == "kw" and t[j].v == "function":
                j = nxt(j + 1)
                if j < N and t[j].k == "name":
                    names.add(t[j].v)
                i = j; continue
            # local a, b, c [= ...]
            while j < N and t[j].k == "name":
                names.add(t[j].v)
                j = nxt(j + 1)
                if j < N and t[j].k == "op" and t[j].v == ",":
                    j = nxt(j + 1); continue
                break
            i = j; continue

        # ---- for ----
        if tk.v == "for":
            j = nxt(i + 1)
            while j < N and t[j].k == "name":
                names.add(t[j].v)
                j = nxt(j + 1)
                if j < N and t[j].k == "op" and t[j].v == ",":
                    j = nxt(j + 1); continue
                break
            i = j; continue

        # ---- function：吃掉名字链，再吃参数表 ----
        if tk.v == "function":
            j = nxt(i + 1)
            # 名字链：a . b . c / a : b
            while j < N and t[j].k == "name":
                j = nxt(j + 1)
                if j + 1 < N and t[j].k == "op" and t[j].v in (".", ":") \
                        and t[j + 1].k == "name":
                    j = nxt(j + 2); continue
                break
            if j < N and t[j].k == "op" and t[j].v == "(":
                # 参数表（深度 1）
                k = j + 1
                while k < N and not (t[k].k == "op" and t[k].v == ")"):
                    if t[k].k == "name":
                        names.add(t[k].v)
                    k += 1
                i = k + 1; continue
            i = j; continue

        i += 1
    return names


def collect_key_names(toks):
    """返回 set：作为表键出现的名字（.x / :x 之后的），这些不能改名。"""
    keys = set()
    t = [x for x in toks if x.k != "comment"]
    for idx in range(1, len(t)):
        if t[idx].k == "name" and t[idx - 1].k == "op" and t[idx - 1].v in (".", ":"):
            keys.add(t[idx].v)
    return keys


def all_names(toks):
    return {x.v for x in toks if x.k == "name"}


# ────────────────────────── 名字生成 ──────────────────────────

def make_name_factory(seed, reserved, prefix="_"):
    """
    生成与 reserved 不冲突、且互相不冲突的新名字。
    seed 决定字母表排列顺序 —— 用作变体指纹：
    同一份源码 + 不同 seed => 变量名集合完全不同，但行为一致。
    """
    import random
    rnd = random.Random(seed)
    alphabet = list("abcdefghijklmnopqrstuvwxyz")
    rnd.shuffle(alphabet)
    digits = list("0123456789")
    rnd.shuffle(digits)
    suffix_pool = [a + b for a in alphabet for b in (alphabet + digits)]
    rnd.shuffle(suffix_pool)

    counter = [0]
    used = set(reserved)

    def gen():
        while True:
            c = counter[0]; counter[0] += 1
            # 名字形如 _ab1 / _ab2 ... 用打乱后的字母表
            if c < len(suffix_pool):
                nm = prefix + suffix_pool[c]
            else:
                nm = prefix + suffix_pool[c % len(suffix_pool)] + str(c // len(suffix_pool))
            if nm not in used:
                used.add(nm)
                return nm
    return gen


# ────────────────────────── 重命名 ──────────────────────────

def rename(src, seed=1, keep=None, rename_globals=False):
    toks = tokenize(src)
    live = [x for x in toks if x.k != "comment"]

    locals_ = collect_local_names(toks)
    keys = collect_key_names(toks)
    keep = set(keep or [])

    # 候选：被 local 声明过、且从不作为键出现的名字
    candidates = {n for n in locals_ if n not in keys and n not in keep}

    if rename_globals:
        # 危险开关：连全局一起改（要求脚本自带所有依赖，一般不开）
        candidates |= (all_names(toks) - keys - keep - KEYWORDS)

    reserved = set(KEYWORDS) | all_names(toks) | keys | keep
    gen = make_name_factory(seed, reserved)
    mapping = {n: gen() for n in sorted(candidates)}

    # 应用：只替换「变量引用」的 name token（不是键）
    out = []
    pos = 0
    for idx, tk in enumerate(toks):
        if tk.k != "name":
            continue
        prev = None
        for j in range(idx - 1, -1, -1):
            if toks[j].k == "comment":
                continue
            prev = toks[j]; break
        is_key = prev is not None and prev.k == "op" and prev.v in (".", ":")
        if is_key:
            continue
        if tk.v in mapping:
            out.append((tk.s, tk.e, mapping[tk.v]))

    buf = src
    for s, e, nv in reversed(out):
        buf = buf[:s] + nv + buf[e:]
    return buf, mapping


# ─────────────────────── 字符串加密（可选） ───────────────────────

def _b85_encode(data: bytes) -> str:
    out = []
    i, n = 0, len(data)
    while i + 4 <= n:
        v = int.from_bytes(data[i:i + 4], 'big')
        out.append(''.join(chr(33 + (v // (85 ** k)) % 85) for k in (4, 3, 2, 1, 0)))
        i += 4
    rem = n - i
    if rem:
        v = int.from_bytes(data[i:] + b'\0' * (4 - rem), 'big')
        s = ''.join(chr(33 + (v // (85 ** k)) % 85) for k in (4, 3, 2, 1, 0))
        out.append(s[:rem + 1])
    return ''.join(out)


def encrypt_strings(src, dec_name="_DEC", sign="", sign_var="_SIGN"):
    """
    把字符串字面量替换为 _DEC("...")。解密器用普通 Lua 写成，不用 loadstring。
    长字符串 [[..]] 一并转成普通字符串再加密。
    """
    toks = tokenize(src)
    picks = []
    for tk in toks:
        if tk.k == "string":
            raw = tk.v[1:-1]
            q = tk.v[0]
            raw = raw.replace('\\' + q, q)
            picks.append((tk.s, tk.e, raw, False))
        elif tk.k == "lstring":
            m = re.match(r'\[=*\[', tk.v)
            body = tk.v[m.end():-m.end()]
            if body.startswith('\n'):
                body = body[1:]
            picks.append((tk.s, tk.e, body, True))
    if not picks:
        return src, 0

    buf = src
    if sign:
        # 用签名派生的密钥流做 XOR：改签名 => 密钥全变 => 解出乱码
        raws = []
        for s_, e_, raw, islong in reversed(picks):
            raws.append(raw)
        # 坑：Lua 端每个字符串解密时索引都从 1 开始，
        # 这里若用跨字符串的全局 idx 累加，第二个字符串起就全解错（实测满屏乱码）。
        # 必须每个字符串独立从 0 开始。
        enc_list = []
        for s_, e_, raw, islong in reversed(picks):
            b = raw.encode('utf-8')
            x = bytes((c ^ _kbyte(sign, k)) for k, c in enumerate(b))
            enc_list.append((s_, e_, x))
        for s_, e_, x in enc_list:
            enc = _b85_encode(x).replace('\\', '\\\\').replace('"', '\\"')
            buf = buf[:s_] + '%s("%s")' % (dec_name, enc) + buf[e_:]
    else:
        for s_, e_, raw, islong in reversed(picks):
            enc = _b85_encode(raw.encode('utf-8'))
            enc = enc.replace('\\', '\\\\').replace('"', '\\"')
            buf = buf[:s_] + '%s("%s")' % (dec_name, enc) + buf[e:]

    dec = (_DEC_LUA.replace("__DEC__", dec_name)
                   .replace("__SIGNREF__", sign_var)
                   .replace("__SIGNB85__", sign.replace('\\', '\\\\').replace('"', '\\"')))
    # 把解密器插到第一个 local 之后或文件开头
    m = re.search(r'local _CK = \d+\ndo\n(?:.*?\n)*?end\n', buf)
    if m:
        at = m.end()
    else:
        mm = re.search(r'^local [^\n]*\n', buf, re.M)
        at = mm.end() if mm else 0
    # 必须拼回后半段！曾经只写 buf[:at] 导致整份脚本只剩第一行（实测踩过）
    buf = buf[:at] + "\n" + dec + "\n" + buf[at:]
    return buf, len(picks)


_DEC_LUA = r'''
-- 字符串解密（普通 Lua 实现，不依赖 loadstring）
-- 坑：解密器若整个包在 do...end 里，__DECNAME__ 就是块内 local，
-- 外部调用处看到的是 nil（实测 "attempt to call a nil value (global '_DEC')"）。
-- 所以先在块外声明 local，再在块内赋值。
local __DECNAME__
local _SK = "__SIGNB85__"
do
  local BV = {}
  for i = 0, 84 do BV[0x21 + i] = i end
  local function __DEC_IMPL__(s)
    if type(s) ~= "string" or #s < 2 then return "" end
    local n, i = #s, 1
    local buf, nb = {}, 0
    local parts, np = {}, 0
    while i + 4 <= n do
      local a, b, c, d, e = string.byte(s, i, i + 4)
      local v = ((((BV[a] * 85 + BV[b]) * 85 + BV[c]) * 85 + BV[d]) * 85 + BV[e])
      nb = nb + 1
      buf[nb] = string.char(math.floor(v / 16777216) % 256,
                            math.floor(v / 65536) % 256,
                            math.floor(v / 256) % 256, v % 256)
      if nb >= 1024 then np = np + 1; parts[np] = table.concat(buf, "", 1, nb); nb = 0 end
      i = i + 5
    end
    local rem = n - i + 1
    if rem > 1 then
      -- 坑：string.byte(s,i,i+4) 不足 5 个时返回 nil，p 里带 nil，
      -- BV[nil] 直接 "attempt to perform arithmetic on a nil value"。
      -- 且原写法 for k=rem,4 会把第 rem 个真实字符覆盖成 'u'。
      -- 改成显式补 0x75('u')，只覆盖缺失位。
      local p = {}
      for k = 1, 5 do
        local c = string.byte(s, i + k - 1)
        p[k] = c or 0x75
      end
      local v = ((((BV[p[1]] * 85 + BV[p[2]]) * 85 + BV[p[3]]) * 85 + BV[p[4]]) * 85 + BV[p[5]])
      local all = {math.floor(v / 16777216) % 256, math.floor(v / 65536) % 256,
                   math.floor(v / 256) % 256, v % 256}
      for k = 1, rem - 1 do nb = nb + 1; buf[nb] = string.char(all[k]) end
    end
    if np > 0 then
      np = np + 1; parts[np] = table.concat(buf, "", 1, nb)
      return table.concat(parts, "", 1, np)
    end
    local d
    if np > 0 then
      np = np + 1; parts[np] = table.concat(buf, "", 1, nb)
      d = table.concat(parts, "", 1, np)
    else
      d = table.concat(buf, "", 1, nb)
    end
    -- 签名一致性：_GSIGN 由签名块在运行时写入，_SK 是本文件出厂时的副本。
    -- 改了 _SIGN 的人即便算出正确 _CK，这里也会对不上 -> 崩。
    if _GSIGN ~= _SK then
      error("[签名] 不匹配：脚本已被篡改")
    end
    local L = #_SK
    local o = {}
    for i = 1, #d do
      local k = (string.byte(_SK, ((i - 1) % L) + 1) + (i - 1) * 7) % 256
      o[i] = string.char(bit.bxor(string.byte(d, i), k))
    end
    return table.concat(o)
  end
  __DECNAME__ = __DEC_IMPL__
end
'''.replace("__DECNAME__", "__DEC__")


# ─────────────────────── 签名 / 变体指纹 ───────────────────────

def inject_signature(src, sign, variant, sign_name="_SIGN", tamper_error=True):
    """
    注入签名块 + 完整性校验。

    防篡改原理（这条是核心）：
      1) 校验值 _CK 由签名串算出并**硬编码**在脚本里
      2) 脚本加载时（顶层 do...end，非 OnStart）立刻重算并比对
      3) 删掉 _SIGN  -> #_SIGN 取长度报 nil -> 加载即崩
      4) 改一个字符 -> 校验值对不上 -> 加载即崩
      5) 想改 _CK 绕过 -> 得知道算法且算出对应值，改签名的人算不出
    另外字符串常量用签名派生的密钥加密，即便绕过校验，内容也是乱码。
    """
    payload = _sig_payload(sign, variant)
    sb85 = _b85_encode(payload.encode('utf-8'))
    enc = sb85.replace('\\', '\\\\').replace('"', '\\"')
    ck = _cksum(sb85)

    blk = ('\n-- [%s] 归属签名 · 删除或修改将导致脚本无法运行\n'
           'local %s = "%s"\n'
           '_GSIGN = %s\n'
           'local _CK = %d\n'
           'do\n'
           '  local _c = 0\n'
           '  for _i = 1, #%s do\n'
           '    _c = (_c * 31 + string.byte(%s, _i)) %% 2147483647\n'
           '  end\n'
           '  if _c ~= _CK then\n'
           '    error("[%s] 签名校验失败：脚本已被篡改")\n'
           '  end\n'
           'end\n'
           % (sign, sign_name, enc, sign_name, ck, sign_name, sign_name, sign))

    m = re.search(r'^local [^\n]*\n', src, re.M)
    if m:
        src = src[:m.end()] + blk + src[m.end():]
    else:
        src = blk + src
    return src, {"variant": variant, "ck": ck, "payload": payload, "b85": sb85}


OPENFN_RE = re.compile(r'openFunctions\s*=\s*\{(.*?)\n\s*\}', re.S)
# 收集用：不要求参数后换行（转发函数是一行的）
OPENNAME_RE = re.compile(
    r'^([ \t]*)function[ \t]+([A-Za-z_]\w*)[ \t]*([.:])[ \t]*([A-Za-z_]\w*)[ \t]*\(', re.M)


def rename_open_functions(src, gen):
    """
    把开放函数名也混淆掉（触发器里显示名保留，函数名变 _a1 这类）。
    同时改：function T.name / T:name 的定义处 + openFunctions 表里的键。
    displayName / tips 不动 —— 编辑器里仍显示中文，人能认出来。
    """
    names = set()
    for m in OPENNAME_RE.finditer(src):
        if m.group(1) == "":
            names.add(m.group(4))
    if not names:
        return src, {}
    alt = '|'.join(sorted(names, key=len, reverse=True))
    mapping = {n: gen() for n in sorted(names)}

    # 4.1 定义处
    src = re.sub(r'(function[ \t]+[A-Za-z_]\w*[ \t]*[.:][ \t]*)(' + alt + r')([ \t]*\()',
                 lambda m: m.group(1) + mapping[m.group(2)] + m.group(3), src)
    # 4.2 openFunctions 表内的键
    # 坑：不能用 /openFunctions\s*=\s*\{([\s\S]*?)\n\s*\}/ 非贪婪正则。
    # 表内每个函数定义都以 "\n      }," 结尾，非贪婪在第一个就停，
    # 导致只有第一个键改名、其余保留原名 -> 除第一个外开放函数全部失效。
    # 必须按花括号配对取完整范围。
    oi = src.find('openFunctions')
    if oi >= 0:
        bp = src.find('{', oi)
        if bp >= 0:
            depth, ep = 0, -1
            i = bp
            while i < len(src):
                if src[i] == '{':
                    depth += 1
                elif src[i] == '}':
                    depth -= 1
                    if depth == 0:
                        ep = i
                        break
                i += 1
            if ep > bp:
                inner = src[bp:ep]
                new_inner = re.sub(r'(\n\s*)(' + alt + r')(\s*=\s*\{)',
                                   lambda x: x.group(1) + mapping[x.group(2)] + x.group(3), inner)
                src = src[:bp] + new_inner + src[ep:]
    return src, mapping


# ──────────────────────────── 主流程 ────────────────────────────

def _sig_payload(sign, variant):
    return "%s|%s" % (sign, variant)


def _kbyte(sb, i):
    """密钥流：与 Lua 侧逐字一致。纯算术，无浮点精度风险。"""
    L = len(sb)
    return (ord(sb[i % L]) + i * 7) % 256


def _cksum(sb):
    c = 0
    for b in sb.encode('latin-1'):
        c = (c * 31 + b) % 2147483647
    return c


def obfuscate(src, seed=1, sign="黎明破晓", variant="V1",
              enc_strings=False, keep=None, rename_globals=False,
              wrap_open=True, rename_open=False):
    info = {}
    out = src
    # 签名先算出来：字符串加密的密钥由它派生，删/改签名即乱码
    sb85 = _b85_encode(_sig_payload(sign, variant).encode('utf-8'))
    info["sign_b85"] = sb85
    if wrap_open:
        reserved = set(KEYWORDS) | all_names(tokenize(out))
        g = make_name_factory(seed ^ 0x5BD1, reserved)
        out, n = wrap_open_functions(out, g)
        info["wrapped"] = n
    if rename_open:
        reserved = set(KEYWORDS) | all_names(tokenize(out))
        g2 = make_name_factory(seed ^ 0x9E37, reserved)
        out, om = rename_open_functions(out, g2)
        info["renamed_open"] = om
        info["open_mapping"] = om
    out, mapping = rename(out, seed=seed, keep=keep, rename_globals=rename_globals)
    info["renamed"] = len(mapping)
    info["mapping"] = mapping
    if enc_strings:
        out, n = encrypt_strings(out, sign=sb85, sign_var="_SIGN")
        info["encrypted_strings"] = n
    out, siginfo = inject_signature(out, sign, variant)
    info["sign"] = siginfo
    info["seed"] = seed
    return out, info


def main():
    ap = argparse.ArgumentParser(description="UGC 3.0 Lua 混淆器 · 签名 黎明破晓")
    ap.add_argument("input")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seed", type=int, default=1, help="命名种子（变体指纹）")
    ap.add_argument("--variant", default="V1", help="变体标识，如 客户名+日期")
    ap.add_argument("--sign", default="黎明破晓")
    ap.add_argument("--strings", action="store_true", help="加密字符串常量")
    ap.add_argument("--keep", default="", help="额外保留不改名，逗号分隔")
    ap.add_argument("--no-wrap", action="store_true", help="不做开放函数转发（函数名保留原样）")
    ap.add_argument("--rename-open", action="store_true",
                    help="连开放函数名一起混淆（触发器里显示名仍是中文）")
    ap.add_argument("--no-tamper", action="store_true",
                    help="不加防篡改校验（不推荐）")
    ap.add_argument("--rename-globals", action="store_true",
                    help="连全局名一起改（危险，仅在脚本自带全部依赖时用）")
    ap.add_argument("--manifest", default=None, help="输出变体指纹清单 json")
    args = ap.parse_args()

    src = open(args.input, encoding="utf-8").read()
    keep = [x.strip() for x in args.keep.split(",") if x.strip()]
    out, info = obfuscate(src, seed=args.seed, sign=args.sign, variant=args.variant,
                          enc_strings=args.strings, keep=keep,
                          rename_globals=args.rename_globals,
                          wrap_open=not args.no_wrap,
                          rename_open=args.rename_open)
    open(args.out, "w", encoding="utf-8").write(out)
    print("输入 %d 字节 -> 输出 %d 字节" % (len(src), len(out)))
    if info.get("wrapped"):
        print("开放函数转发 %d 个（函数体已移入 local）" % info["wrapped"])
    if info.get("renamed_open"):
        print("开放函数名已混淆 %d 个: %s" % (len(info["renamed_open"]),
              ", ".join("%s→%s" % (k, v) for k, v in info["renamed_open"].items())))
    print("重命名标识符 %d 个" % info["renamed"])
    if args.strings:
        print("加密字符串 %d 处" % info.get("encrypted_strings", 0))
    print("签名: %s | 变体: %s | 校验值: %d"
          % (info["sign"]["payload"].split("|")[0], args.variant, info["sign"]["ck"]))
    if args.manifest:
        json.dump({"variant": args.variant, "seed": args.seed,
                   "sign": info["sign"]["payload"],
                   "ck": info["sign"]["ck"],
                   "renamed": info["renamed"],
                   "open_names": info.get("open_mapping", {}),
                   "sample_names": sorted(info["mapping"].values())[:8]},
                  open(args.manifest, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=2)
        print("清单已写入", args.manifest)


# ─────────────── 开放函数转发层（函数名隐藏的核心） ───────────────
# 开放函数名（如 function Script:Chat）是触发器绑定的键，不能改。
# 做法：函数体搬到 local 函数（名字已混淆），原处只留一行转发。
# 外部可见性不变（触发器照常工作），实际逻辑被藏进 local。

OPEN_KW = ("function", "if", "for", "while", "do", "repeat", "then", "else", "elseif")
CLOSE_KW = ("end", "until")


def _match_block_end(src, kw_start):
    """给定 function 关键字起始位置，返回匹配 end 之后的位置。"""
    toks = tokenize(src)
    # 找到 kw_start 对应的 token
    si = None
    for idx, t in enumerate(toks):
        if t.s <= kw_start < t.e:
            si = idx; break
    if si is None:
        return None
    # 关键坑：`for i,v in ipairs(x) do ... end` 只对应一个 end，
    # 若 for 和 do 都 +1 就会多算一层，深度一路涨到 20+ 永不回落，
    # 结果 _match_block_end 返回 None、块被切错、生成 illegal end。
    # 所以 do 只在不属于 for/while 头部时才计数。
    depth = 0
    i = si
    n = len(toks)
    prev = None      # 上一个有语义的关键字
    while i < n:
        t = toks[i]
        if t.k == "kw":
            v = t.v
            if v == "function":
                depth += 1
            elif v in ("if", "for", "while", "repeat"):
                depth += 1
            elif v == "do":
                # for/while 的 do 已由 for/while 计过
                if prev not in ("for", "while"):
                    depth += 1
            elif v in ("then", "else", "elseif", "in"):
                # 不更新 prev！否则 `for i,v in ipairs(x) do` 里的 in 会把
                # prev 冲掉，后面的 do 又被当成独立 do 块多计一层。
                i += 1
                continue
            elif v == "end":
                depth -= 1
                if depth <= 0:
                    return toks[i].e
            elif v == "until":
                depth -= 1
                if depth <= 0:
                    return toks[i].e
            else:
                i += 1
                continue
            prev = v
        i += 1
    return None


HEAD_RE = re.compile(
    r'^([ \t]*)function[ \t]+([A-Za-z_]\w*)[ \t]*([.:])[ \t]*([A-Za-z_]\w*)[ \t]*\(([^)]*)\)[ \t]*\r?\n',
    re.M)


def wrap_open_functions(src, gen):
    """
    把顶层 `function Table.name(args)` / `function Table:name(args)`
    改写为 local 函数 + 一行转发。返回 (新源码, 处理数量)。
    """
    count = 0
    while True:
        m = None
        for cand in HEAD_RE.finditer(src):
            # 只处理顶格（无缩进）的，避免误伤嵌套定义
            if cand.group(1) == "":
                m = cand; break
        if not m:
            break
        kw_pos = m.start() + len(m.group(1))
        end_pos = _match_block_end(src, kw_pos)
        if end_pos is None:
            break
        indent, tab, sep, name, params = m.groups()
        body = src[m.end():end_pos]
        newfn = gen()
        if sep == ":":
            local_def = ("local function %s(self%s)\n%s\n"
                         % (newfn, ("," + params) if params.strip() else "", body))
            fwd = "function %s%s%s(%s) return %s(self%s) end\n" % (
                tab, sep, name, params, newfn,
                ("," + params) if params.strip() else "")
        else:
            local_def = ("local function %s(%s)\n%s\n"
                         % (newfn, params, body))
            fwd = "function %s%s%s(%s) return %s(%s) end\n" % (
                tab, sep, name, params, newfn, params)
        src = src[:m.start()] + local_def + fwd + src[end_pos:]
        count += 1
    return src, count


# -*- coding: utf-8 -*-
"""
迷你世界 UGC 3.0 · Lua 5.1 脚本混淆器（签名：黎明破晓）

设计要点（每条都有实测依据，不是拍脑袋）：

【安全性的数学基础】
Lua 的作用域遮蔽只依赖"名字是否相同"，不依赖具体名字。
因此只要重命名是**双射**（同名→同一新名，异名→不同新名），
且新名不与任何保留名冲突，语义就完全不变。
所以：只重命名「被 local 声明过的名字」（含函数参数、for 变量）是安全的。
绝不改名：引擎全局（World/Player/CloudSever...）、开放函数名、
表键名（.x 与 ["x"] 之后的标识符）、标准库名、字符串内容。

【开放函数名怎么"混淆"】
function Script:Chat() 里的 Chat 是触发器绑定的键，不能改。
做法：把函数体搬到 local 函数（改名），开放函数只留一行转发。
外部可见性不变，实际逻辑已被隐藏。

【不用 loadstring】
字符串加密后的解密、以及数据化 VM 全部是普通 Lua 代码，不依赖 loadstring。

作者签名：黎明破晓
"""


if __name__ == "__main__":
    main()
