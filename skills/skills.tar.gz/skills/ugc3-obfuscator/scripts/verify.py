# -*- coding: utf-8 -*-
"""混淆正确性验证：同一 stub 环境下，原脚本 vs 混淆脚本，逐条比对行为日志。"""
import sys, json
from lupa import LuaRuntime

STUB = r"""
-- ===== 迷你世界 API stub（记录调用日志） =====
function _L(...) local a={} for i=1,select('#',...) do a[i]=tostring((select(i,...))) end
  LOG[#LOG+1]=table.concat(a,'|') end
TriggerEvent = setmetatable({}, {__index=function(t,k) return 'TE_'..k end})
World = {}
function World:GetAllPlayers(x) _L('World.GetAllPlayers',x) return ALLP end
Player = {}
function Player:NotifyGameInfo2Self(p,s) _L('Notify',tostring(p),s) end
function Player:GetNickname(p) return 'nick_'..tostring(p) end
function Player:HideUIView(p,u) _L('HideUIView',tostring(p),u) end
function Player:OpenUIView(p,u) _L('OpenUIView',tostring(p),u) end
function Player:PlayAdvertisingCallback(p,s,f) _L('Ad',tostring(p),s) end
CloudSever = {}
function CloudSever:GetDataListByKey(k1,k2,f)
  _L('CGet',tostring(k1),tostring(k2))
  local v = DB[k2]
  if v == nil then f(2,k2,nil) else f(0,k2,v) end
  return true end
function CloudSever:SetDataListBykey(k1,k2,v)
  _L('CSet',tostring(k1),tostring(k2), type(v))
  DB[k2]=v; return true end
Backpack = {}
function Backpack:GetItemNum(p,id) _L('BGetNum',tostring(p),id) return ITEMS[id] or 0 end
function Backpack:RemoveGridItemByItemID(p,id,n) _L('BRemove',id,n)
  ITEMS[id]=(ITEMS[id] or 0)-n; return true end
function Backpack:CreateItem(p,id,n) _L('BCreate',id,n) ITEMS[id]=(ITEMS[id] or 0)+n; return true end
function Backpack:EnoughSpaceForItem(p,id,n) return true end
CustomUI = {}
function CustomUI:ShowElement(p,u,e) _L('UIShow',tostring(e)) end
function CustomUI:HideElement(p,u,e) _L('UIHide',tostring(e)) end
function CustomUI:SetText(p,u,e,t) _L('UIText',tostring(e),tostring(t)) end
function CustomUI:SetSize(p,u,e,w,h) _L('UISize',tostring(e),tostring(w)) end
function CustomUI:SetPosition(p,u,e,x,y) _L('UIPos',tostring(e),x,y) end
function CustomUI:SetTexture(p,u,e,t) _L('UITex',tostring(e)) end
function CustomUI:GetItemIcon(id) return 'icon' end
Item = {}
function Item:GetItemName(id) return 'item_'..id end
os = { time=function() return 1700000000 end,
       date=function(f,t) return '2023-11-15 00:00:00 ' end,
       timeMs=function() return 1700000000000 end }
ALLP = {1001,1002}
PDATA = {}
function getsj(p) PDATA[p] = PDATA[p] or {}; return PDATA[p] end
DB = {}
ITEMS = {}
LOG = {}
"""

def run(path, script_path):
    lua = LuaRuntime(unpack_returned_tuples=True)
    lua.execute(STUB)
    # 注入 bit 模块（脚本若用到）
    q = lua.execute(open(script_path, encoding='utf-8').read())
    lua.execute("_G.Q = ...", q)
    lua.execute("""
      local self = _G.Q
      self.AllP = ALLP
      -- 模拟 self:AddCustomEvent / AddTriggerEvent / DoPeriodicTask
      function self:AddCustomEvent(n,f) _L('AddCustomEvent',n) end
      function self:AddTriggerEvent(e,f,id) _L('AddTriggerEvent',tostring(e),tostring(id)) end
      function self:DoPeriodicTask(f,t) _L('DoPeriodicTask',tostring(t)) end
      local ok,err = pcall(function() self:OnStart() end)
      LOG[#LOG+1] = 'OnStart:'..tostring(ok)..(ok and '' or ('|'..tostring(err)))
    """)
    # 触发若干交互（都用同一玩家 1001）
    lua.execute("""
      local self = _G.Q
      local function ev(elm, content) return {eventobjid=1001, uielement=elm, content=content} end
      local steps = {
        function() self.createzm(self, ev('x')) end,                  -- 未取名
        function() self.setname(self, ev('x','我的宗门')) end,
        function() ITEMS['r2_7512983178513983120_23324']=1
                   self.createzm(self, ev('x')) end,                   -- 创建
        function() self.xs(self, ev('x')) end,                          -- 显示
        function() self.xszmx(self, ev('x')) end,                       -- 宗门详情
        function() self.contribution(self, ev('x')) end,                -- 无贡献石
        function() ITEMS['r2_7513156596408493712_23311']=3
                   self.contribution(self, ev('x')) end,                -- 捐献
        function() self.appoit(self, ev('_70')) end,                    -- 任命
        function() self.xssd(self, ev('x')) end,                        -- 商店
        function() self.sdgm(self, ev('_145')) end,                     -- 购买
        function() self.tczm_(self, ev('x')) end,                       -- 退出/解散
      }
      for i,f in ipairs(steps) do
        local ok,err = pcall(f)
        LOG[#LOG+1] = ('step%d:'):format(i)..tostring(ok)..(ok and '' or ('|'..tostring(err)))
      end
    """)
    logs = list(lua.eval("LOG").values())
    out = [x.decode('utf-8','replace') if isinstance(x,bytes) else str(x) for x in logs]
    import re
    # lupa 报错信息里带源码行号，混淆后行号会平移，比对前剥离
    return [re.sub(r'\[string "<python>"\]:\d+:', '', x) for x in out]

if __name__ == "__main__":
    a = run("orig", sys.argv[1])
    b = run("obf", sys.argv[2])
    print("原始脚本日志条数:", len(a))
    print("混淆脚本日志条数:", len(b))
    if a == b:
        print("✅ 行为完全一致（%d 条调用日志逐条相同）" % len(a))
    else:
        print("❌ 存在差异")
        n = max(len(a), len(b))
        diff = 0
        for i in range(n):
            x = a[i] if i < len(a) else "<缺失>"
            y = b[i] if i < len(b) else "<缺失>"
            if x != y:
                diff += 1
                if diff <= 12:
                    print("  #%d\n    原: %s\n    混: %s" % (i, x[:110], y[:110]))
        print("  共 %d 处不同" % diff)
        sys.exit(1)
