---
name: ugc3-obfuscator
description: 迷你世界 UGC 3.0 Lua 脚本混淆加密。当用户说「加密生成」「混淆生成」「加混淆」「加我的签名」「防止被抄」时使用；也用于给已有脚本加归属签名与变体指纹（泄露后可反查是哪个分发版本）。产出保留原语义、可直接贴回编辑器的 Lua。
---

# 迷你世界 UGC 3.0 脚本混淆器

## 触发
- 用户说 **「加密生成」** → 做完脚本后必须再跑一次混淆再交付
- 明确要求混淆 / 加签名 / 防止剽窃时

## 核心命令

```bash
python3 /data/skills/ugc3-obfuscator/scripts/ugc3_obfuscator.py <输入.lua> -o <输出.lua> \
  --seed 7 --variant <变体名> [--strings] [--manifest m.json] [--no-wrap]
```

| 参数 | 说明 |
|---|---|
| `--seed` | 命名种子，决定变量名集合 |
| `--variant` | 变体名（给谁分发就叫什么，泄露可反查） |
| `--strings` | 额外加密字符串字面量（实验性，已验证通过） |
| `--manifest` | 输出 变体→指纹 对照表 |
| `--no-wrap` | 关闭开放函数转发 |

## 四层保护

1. **开放函数转发**（核心）：`function Script:Chat(...)` 的函数体搬到 `local _xN(...)`，原处只留 `return _xN(...)`。触发器照常工作，逻辑被藏进 local。
2. **标识符重命名**：只改被 `local` 声明过的名字（含函数参数、for 变量），双射且避开保留名。
3. **字符串加密**：字面量 → `_DEC("...")`，运行时解密（纯 Lua，不用 loadstring）。
4. **签名 + 变体指纹**：注入 `[签名]` 块，含签名串与指纹哈希。

## 绝不改动（改了就崩）

- 引擎全局：`World` / `Player` / `CloudSever` / `Backpack` / `CustomUI` / `Data` / `Mini` 等
- 开放函数名（`q.xxx`、`Script:Chat` 的键）—— 用转发层隐藏，不改名
- 表键名（`.x` / `:x` 后的标识符）
- 字符串内容（除非开了 `--strings`）

## 验证（改完必跑）

```bash
python3 /data/skills/ugc3-obfuscator/scripts/verify.py <原脚本.lua> <混淆后.lua>
```
用 stub 环境跑两遍，比对调用日志。输出 `✅ 行为完全一致` 才可交付。

## 追踪泄露
`--manifest` 记录 变体名 → 指纹。别人抄走后，从脚本里的 `_SIGN` 串反解出变体名。

## 已踩过的坑（改代码前先看）

- `for i,v in ipairs(x) do` 只对应一个 `end`：`for` 和 `do` 都 +1 会多算一层，块匹配永不收敛
- `in` 不能更新 prev，否则 `do` 又被当独立块
- 转发时 body 已含匹配到的 `end`，不能再加一个
- 解密器整个包在 `do...end` 里会让 `_DEC` 变成块内 local，外部调用为 nil
- `string.byte(s,i,i+4)` 不足 5 个返回 nil，`BV[nil]` 报 arithmetic on nil
- 多处字符串替换漏拼 `src[m.end():]` 会截断整份脚本

## 防篡改（默认开启）

签名块是**加载即校验**，不是注释。删或改任何一处，脚本直接崩：

```
local _SIGN = "..."      ← 删这行：#_SIGN 取长度报 nil，崩
_GSIGN = _SIGN           ← 删这行：_DEC 比对不通过，崩
local _CK = 486886350    ← 改数字：校验失败，崩
do ... if _c ~= _CK then error(...) end end
```

实测六种篡改全部崩溃（正常脚本加载成功）：
①原样✅ ②签名改1字符❌ ③删签名行❌ ④只改校验值❌ ⑤删_GSIGN❌ ⑥删整个签名块❌

`--strings` 的字符串密钥由签名派生，改签名后即便绕过校验，内容也是乱码。

## 开放函数名混淆（--rename-open）

`GetPrimes → _dr`、`OnStart → _dv`。触发器要填混淆后的名字，映射记在 `--manifest` 里。

## 签名分析器

`/data/workspace/签名分析器.html` —— 纯前端单文件，粘贴脚本即识别签名者、变体、校验状态、混淆特征。

## HTML 混淆工具（首选交付方式）

`/data/skills/ugc3-obfuscator/混淆工具.html` —— 纯前端单文件，双击浏览器打开即用，**不需要 Python**。

界面参数：签名（默认 黎明破晓180792317，可任意改）、变体、seed、keep（不改名，逗号分隔）、
三个开关（加密字符串 / 函数体入 local / 混淆开放函数名）。
输出带统计、开放函数名映射表、复制、下载、就地校验（重算 cksum 比对）。

命令行版 `scripts/ugc3_obfuscator.py` 仍在，两者算法一致：
JS 与 Python 对同一源码产出的 _DEC 密文 60/60 完全相同。

## v2 加固（三项新要求）

UI 新增三个默认勾选开关：
- **去掉注释**：`stripComments` 清掉全部 `--` 注释，保留换行（行号不变便于对照）
- **定义表移入 OnStart**：`moveDefsToOnStart` 把 `X.propertys` / `X.openFunctions` 整块搬进 OnStart 内部赋值，
  满足「定义的表中不能有非函数字段，初始化数据在 OnStart 执行」；没有 OnStart 时自动创建
- **末尾结构断言**：`injectAssertions` 在 return 前检查每个开放函数槽位，改函数名即崩

签名块 v2：
- **无注释**（注释会被一眼认出并删掉）
- `_SIGN` 拆 5 段用 `..` 拼接（避免整串被一键替换）
- **双校验** `_CK`(cksum: c*31+b %2147483647) + `_CK2`(cksum2: d*33+b+i %2147483629)
- 报错消息也走 `_DEC` 加密 —— **脚本里没有任何明文签名**
- 插入点在 `_DEC` 块之后（`local _SIGN` 必须在 `_DEC` 定义之后才能被引用）

实测（v2.lua）：注释 0 行、明文签名 false、`_DEC` 61 处、propertys 在 OnStart 内。
防篡改九项：改签名字符/删签名行/改_CK/改_CK2/删_GSIGN/删签名块/改函数名 → 全崩；
删断言块 → 不崩（断言是附加加固，不是主校验）。

## 分析器避坑

提取 `_SIGN` 反转义必须**两步**：先 `\"` → `"`，再 `\\` → `\`（顺序不能反、不能只做一步）。
只反转义引号会让 cksum 对不上，误判成"已损坏"。

## 生命周期函数永不改名（用户实测：返回 nil 的真凶）

**现象**：脚本能导入、触发器能看到开放函数，但一调用就返回 nil。

**根因**：引擎是按**名字**调用生命周期函数的（OnStart / OnDestroy / OnUpdate…），
不是通过 openFunctions / openFnArgs 表。改名后引擎找不到 OnStart → 组件不初始化 →
属性没赋值、状态没建立 → 开放函数被调用时读到空值。

修复：`isLifecycle(n)` = `/^On[A-Z]/`，`renameOpenFunctions` 收集阶段整类跳过，
`info.lifecycle_kept` 记录被保护的名字。宁可保守——生命周期几乎都以 On 开头。
业务开放函数（GetHP / ObjName）照常改名。

## 定义表默认留在顶层

`moveDefs` 默认 **false**（UI 默认不勾选）。
propertys / openFunctions / openFnArgs 都是引擎在**脚本加载期**读的元数据，
搬进 OnStart 后加载期读到 nil → 属性丢失、开放函数全丢。
「非函数字段放 OnStart」只是规范检查的 WARN，不值得为满足它破坏引擎功能。

## 排障顺序（返回值 nil 时）

1. 先关掉「混淆开放函数名」再导入一次 —— 若恢复，说明引擎绑定依赖原名
2. 确认 OnStart / OnDestroy 仍是原名（产物里搜 `function xxx:OnStart`）
3. 确认 openFunctions / openFnArgs 在顶层（行首，不在函数体内）
4. 确认登记表里的键与真实函数名一致（结果页「开放函数完整性」卡片会直接报）

## 元方法（__index 等）绝不能被改名 —— 数组返回值错误的真因

**现象**：一切正常，但返回值错误 / 数组元素类型识别失败。
与"arrayWrapper 必须放在开放函数前面"是同类问题：**结构元信息被破坏**。

**根因**：`renameOpenFunctions` 用 `function X.Y(` 扫描开放函数，
会把 `function meta.__index(_, key)` 也匹配上，改名成 `meta._xb`。
于是 `setmetatable(newArray, meta)` 的 `__index` 槽位变 nil，
引擎读 `returnType.__className_` 永远拿不到元素类型名 → 数组返回值错误。

修复：新增 `isMetamethod(n)` = `/^__/`，与生命周期合并成 `isReservedName`。
`renameOpenFunctions` / `wrapOpenFunctions` / 断言的 fns 收集，
**三处都只处理"组件表上的非保留名"**，组件表名由 `componentTableName(src)` 从 `return XXX` 提取。
元方法原样保留（不改名、不移入 local）。

## collectTopKeys：定义表一级键的可靠取法

三处都要用它（`checkOpenFunctions` / `injectAssertions` / 键改名兜底），踩过三个坑：
1. **不能按缩进判** —— 嵌套的 `params` / `returnType` 常与一级键同缩进，会误报
2. **深度只数 `{}`** —— 把 `()` / `[]` 算进去，`Mini.Array(...)` 会让 depth 永远回不到 1
3. **键在 `=` 之前** —— 写成"prev 是 =" 永远匹配不到；且 tokenize 把空白也当 op token，
   向前看必须跳过空白再判断

正解：tokenize → 花括号深度 == 1 → name 后跟（跳空白）`=` 再跟 `{`。

## 返回值 nil 的定位方法（沙盒无法复现时）

沙盒里四个递进版本（仅签名 / +去注释改名 / +字符串加密 / +函数体入local）
**全部正常返回**，说明 Lua 语义层面没问题 —— 真因在引擎侧。
已排除：注释、开放函数改名、字符串加密、函数体入 local、生命周期改名、元方法改名、
数组元表 __className_（三轮 Array/Array/Number 正确）。

**递进诊断法**：生成 A/B/C/D 四版，每版带一个 `Diag()` 开放函数返回自诊断串
（self 类型 / bit.bxor / string.char(255) / _DEC 类型与解密输出 / 调用业务函数结果 /
impl 函数类型与调用 / Lua 版本）。逐个导入，看哪版开始返回 nil，即可定位到具体开关。
生成脚本 /data/workspace/diag/gen.js，产物在 /data/workspace/diag/。

**当前最强假设（沙盒无法证实）**：引擎调用开放函数时，函数体依赖的 upvalue
（`local` 解密器 `_DEC`、`local` impl 函数）可能不可见。
文档一证实：引擎内置组件的开放函数体**直接内联**，无转发。
所以默认已改为保守模式：字符串加密、函数体入 local 默认**关闭**，
只保留去注释 + 开放函数名改名 + 内部变量改名 + 签名。

**待确认**：`_GSIGN` 目前是全局变量（多组件同时加载时会互相覆盖），
应改为 chunk 顶层 local 并在 `_DEC` 之前声明 —— 尚未改（未定位到模板字面量位置）。

## 返回值 nil 定位器（成品脚本）

`/data/workspace/返回值nil定位器.lua` —— 导入即自动诊断，无需触发器。
OnStart 跑 5 个阶段并 print（前缀 `[DIAG]`）：
1. openFnArgs 是否注册 / self 类型
2. OnStart 内逐个自调用 T01..T13，打印 ok 与返回值
3. chunk 顶层 local（字符串/数字/表/函数/深层嵌套）直接可见性
4. 解密链（base85 + bit.bxor + string.char）往返是否匹配
5. self 属性是否注入

另提供 13 个开放函数，每个**第一行就 print("[DIAG] ENTER Txx")**，供触发器逐个调用。

**判据表**：
- 日志有 ENTER Txx 但触发器拿 nil → 函数执行了，**返回值通道坏了**
- 日志无 ENTER Txx → 函数**根本没被调用**（绑定/注册问题）
- OnStart 自调用成功、触发器调用失败 → **引擎调用开放函数时 upvalue 不可见**
- T02（纯常量）成功但 T03（local 字符串）nil → 确认 upvalue 不可见，关掉字符串加密
- T03 成功但 T06（解密器）失败 → bit / string.char 在该路径不可用
- T06 成功但 T11（转发式）nil → 转发结构有问题，关掉「函数体移入 local」

沙盒实测 13 项全绿，Lua 语义层面无问题。

## 【已证伪】upvalue 不可见假设 —— 用户实机实测反馈

定位器 v1 在迷你世界实机跑完，**13 项全部 ok=true，无一失败**：
T03（chunk-local 字符串）✅、T04（chunk-local 函数）✅、T05（三层嵌套 local）✅、
T06（解密器 base85+bit.bxor+string.char）✅、T11（转发式 impl）✅、
T13（多层嵌套函数体）✅、T07 属性✅、T10 全局✅。

**结论：混淆器的四个开关在此环境全部安全，upvalue 可见，嵌套无影响。**
之前"关掉字符串加密/函数体入local"的保守默认可以放宽（保留默认关闭亦无害）。

**关键区分**：以上是 OnStart 内**自调用**，不等于**触发器调用**路径。
剩余问题必须用 v2 定位：
- A 有 ENTER + 有 RET，触发器拿 nil → 引擎返回值通道坏了（与混淆无关）
- B 只有 ENTER 无 RET → 函数执行中断
- C 连 ENTER 都没有 → 根本没被调用，查函数名与 openFnArgs 键是否一致
- D 全正常 → 问题在具体脚本其它地方

定位器 v2：/data/workspace/返回值nil定位器v2.lua（每函数 print ENTER + RET 两行）。

## 改名必须同步替换内部调用点（真 bug）

改名后，脚本内部 `self:OldName()` / `_xh:OldName()` 这类调用点仍指向旧名，
运行时直接 "attempt to call a nil value"。
实测：OnStart 里 `self:SayHello()` 在改名后崩溃（混淆版 OnStart 报 ERR）。

修复：`renameOpenFunctions` 末尾遍历 mapping，用
`/\b([A-Za-z_]\w*)\s*([.:])\s*OldName\s*\(/g` 替换，
且**只在接收者是组件表名或 self 时替换**（其他表同名方法不动）。

## 两个会静默产出坏脚本的 bug（本轮修复）

### 1. 紧凑单行格式：登记表键不改名 -> 返回 nil

正则要求键前有 `\n`。写成紧凑单行时键前是 `{ `：
`_xh.openFnArgs = { F = { returnType = ..., params = {} } }`
结果：**键一个都没改名**，而函数定义已改名 -> 引擎按键(旧名)找函数 -> **返回 nil**。
这与"触发器能看到函数名、一调用就 nil"的现象完全吻合。
修复：`(^|[{\\,])([ \t]*)(alt)([ \t]*=[ \t]*\{)` 多行模式，换行不再是必需。

### 2. 字符串转义只处理了 `\"`，没处理 `\\`

`raw.split('\\"').join('"')` 导致源码里的每个反斜杠**翻倍**：
实测 `"转义 \\\" 和 \\"` 混淆后变成 `\\\\"`。
修复：新增 `luaUnescape()` 完整解析（\\n/\\t/\\r/\\a/\\b/\\f/\\v/\\\\/\\'/\\"/\\ddd/续行）。

### 3. esc() 漏了换行与控制符

含真换行的字符串会写成**真换行**的字面量 -> "unfinished string" 语法错误。
修复：esc 补 `\n` `\r` `\t`，控制符用 `\ddd`。

## HTML 转换器的能力边界（已实测）

**能正常处理**：长字符串 `[[...]]`、长注释 `--[[...]]`、紧凑单行表、
多层嵌套表、含分号/引号/反斜杠/ddd转义的字符串。

**不能处理 / 会出错**：
- `Script["DynName"] = function` 这种**动态注册**——扫不到，键不改、函数不改，
  且 open_check 会报"缺少顶层定义"（这是真报警，需手动加入 keep 或改写为字面量）
- 依赖 `loadstring` / 动态生成代码的脚本（Lua 5.1 环境本就无保证）
- `goto` / 标签（Lua 5.1 无此语法）

## 性能：tokenize 的 O(n^2) 陷阱（本轮修复，提速 367 倍）

**现象**：126KB 脚本（MiniMind 对话引擎）混淆时**卡死**，分段计时：
```
stripComments 5.9s | renameOpen 5.7s | wrapOpen 69.1s | encryptStrings 6.7s | rename 8.4s
```

**根因**：`tokenize` 里对**每个** name / number 都执行 `ch.slice(i).join('')`
取剩余串再跑正则 —— 每次拷贝剩余 12 万字符，整体 O(n^2)。
而 `matchBrace` / `matchBlockEnd` / `wrapOpenFunctions` 等内部又反复调 `tokenize`，
叠加后 wrapOpen 阶段单独就 69 秒。

**修复**：改为逐字符向前扫（新增 `isDigit` / `isHex` / `isNameChar`），O(n)。
```
tokenize: 6614ms → 18ms（367x）
完整混淆 120KB 脚本: 卡死 → 228ms
```

**教训**：任何「取剩余子串再匹配」的写法在大文件上都是 O(n^2)。
新增大脚本混淆需求时，先 `console.time` 各阶段，别盲目整体优化。

## 元数据区的字符串绝不能加密（本轮修复）

**现象**：混淆 MiniMind 对话引擎后，**组件属性全部丢失**。

**根因**：`propertys` / `openFnArgs` 里的字符串被加密成 `_DEC("...")`。
Lua 执行后拿到的值是**正确的**（实测 displayName 能解出原文），
但**引擎读不到** —— 说明引擎是**静态解析源码**或**受限环境部分求值**，
和文档一"arrayWrapper 必须在开放函数前面"是同一类**位置敏感性**。

**修复**：新增 `metaRanges()`，encryptStrings 时整块跳过
`propertys` / `openFunctions` / `openFnArgs` 范围内的字符串（含 lstring）。
这些字符串本来就是给编辑器看的明文，加密毫无收益，只有风险。

**推论**：引擎读的一切元数据都不要动 —— 键名、displayName、params 描述、
default 值、returnType。只加密函数体里的字符串。

## 混淆的还原难度（用户问"能不能还原"）

**能还原，混淆只增加成本，不是加密。** 但脚本里的哈希/加解密逻辑本身（SHA256、MD5、
PBKDF2）依然安全 —— 因为安全性来自密钥，不是来自代码不可读。
混淆器自身也对这一点有清醒认知：产物里能看到 `_DEC` 的实现。

## 密钥版工具（哈希工具_密钥版，本轮产出）

给哈希工具加了"必须有密钥才能用"，设计：
- **PBKDF2-HMAC-SHA256** 派生（慢哈希抗暴力），迭代默认 1000，可配 100-20000
- 只存 `VERIFY = SHA256(DK_hex .. "|verify|")`，**不存密钥也不存 DK**
- 用 DK 做 **CTR 模式流加密**（`keystream(i) = SHA256_bytes(DK .. ":" .. i)`）
  加密工作常量：SHA256 的 K 表 + H 初值、MD5 的 T 表 + 初值（共 560 字节），base85 存储
- **引导常量**（BOOT_K/BOOT_H）明文专用于派生与校验；工作用常量解密后才可用
- 双重保护：未激活直接返回提示；即便绕过激活检查，工作常量解不开 -> 哈希结果错误
- 常数时间比较防时序攻击

配钥流程：`配钥工具.html` 输入密钥 → 生成 SALT/ITERS/VERIFY/ENC → 粘进脚本常量。
实测两组不同密钥/盐/迭代均正确，7 个测试向量 SHA256+MD5 全对。

**注意**：激活耗时与迭代数成正比，沙盒 Lua 5.5 下 1000 次约 2.9 秒。
迷你世界 Lua 5.1 可能更慢，卡就把 `keyIterations` 调到 300-500（需重新配钥）。

文件：/data/workspace/hashkey/ 下 tmpl.lua / 配钥工具.html / genlock.mjs；
成品 /data/workspace/哈希工具_密钥版_混淆.lua（20KB）。
