-- ============================================================
--  返回值 nil 定位器 v2（触发器路径专用）
--  签名：黎明破晓180792317
--
--  v1 已证明：OnStart 内自调用 13 项全绿，Lua 层面没问题。
--  v2 解决剩下的问题：区分「函数执行了但引擎拿不到」和「函数根本没被调用」。
--
--  用法：
--    1) 导入后看 OnStart 日志（和 v1 一样全绿则应无红）
--    2) 在触发器里逐个调用 T01..T13，然后看日志：
--
--       [DIAG] ENTER T02_Const
--       [DIAG] RET  T02_Const = CONST_OK      <- 有这两行
--
--  判据（这一次能定死）：
--    A. 有 ENTER + 有 RET，但触发器拿到 nil
--       -> 函数正确执行并返回了值，是**引擎的返回值通道坏了**
--          （跟混淆无关，原版脚本也该是这个结果）
--    B. 只有 ENTER，没有 RET
--       -> 函数执行到一半就中断了（看有没有报错）
--    C. 连 ENTER 都没有
--       -> **函数根本没被调用**，是触发器绑定/函数名注册的问题
--          （重点查：函数名是否与 openFnArgs 里的键一致）
--    D. 全部正常，触发器也拿到值
--       -> 本脚本一切正常，问题在你那个具体脚本的其它地方
-- ============================================================

local Script = {}

Script.propertys = {
    testStr = { type = Mini.String, default = "DEFAULT_STR", displayName = "测试字符串" },
    testNum = { type = Mini.Number, default = 42, displayName = "测试数字" },
}

local UP_STR = "UPVALUE_STR_OK"
local UP_NUM = 12345
local UP_TAB = { 10, 20, 30 }
local function UP_FUNC(x) return "UP_FUNC(" .. tostring(x) .. ")" end
local function UP_FUNC_DEEP(x) return UP_FUNC(x) .. "+DEEP+" .. UP_STR end
local function UP_FUNC_DEEPER(x) return UP_FUNC_DEEP(x) .. "+DEEPER+" .. tostring(UP_NUM) end

local _DEC
do
    local BV = {}
    for i = 0, 84 do BV[0x21 + i] = i end
    local function dec(s)
        if type(s) ~= "string" or #s < 2 then return "" end
        local n, i = #s, 1
        local buf, nb = {}, 0
        while i + 4 <= n do
            local a, b, c, d, e = string.byte(s, i, i + 4)
            local v = ((((BV[a] * 85 + BV[b]) * 85 + BV[c]) * 85 + BV[d]) * 85 + BV[e])
            nb = nb + 1
            buf[nb] = string.char(math.floor(v / 16777216) % 256,
                                  math.floor(v / 65536) % 256,
                                  math.floor(v / 256) % 256,
                                  v % 256)
            i = i + 5
        end
        local dd = table.concat(buf, "", 1, nb)
        local o = {}
        for k = 1, #dd do o[k] = string.char(bit.bxor(string.byte(dd, k), (k * 7) % 256)) end
        return table.concat(o)
    end
    _DEC = dec
end

local ENC_SAMPLE = "0n1rY@i&uS(N4L=DFZ!=><hGe"
local ENC_EXPECT = "\054\113\039\073\064\061\092\114\040\041\058\074\053\037\076\049\044\065\110\049"
GLOBAL_MARK = "GLOBAL_OK"
local function impl_forward(self, x) return "FORWARD(" .. tostring(x) .. ")" end

-- 统一的收尾：打印返回值再返回。这样触发器调用也能在日志里看到真实返回值。
local function _emit(name, v)
    print("[DIAG] RET  " .. name .. " = " .. tostring(v))
    return v
end

Script.openFnArgs = {
    T01_Env       = { returnType = Mini.String, displayName = "01环境探测", params = {} },
    T02_Const     = { returnType = Mini.String, displayName = "02纯常量返回", params = {} },
    T03_LocalStr  = { returnType = Mini.String, displayName = "03读chunk-local字符串", params = {} },
    T04_LocalFunc = { returnType = Mini.String, displayName = "04调chunk-local函数", params = {} },
    T05_DeepLocal = { returnType = Mini.String, displayName = "05深层local嵌套", params = {} },
    T06_Decrypt   = { returnType = Mini.String, displayName = "06解密器全链路", params = {} },
    T07_SelfProp  = { returnType = Mini.String, displayName = "07读self属性", params = {} },
    T08_RetNumber = { returnType = Mini.Number, displayName = "08返回数字", params = {} },
    T09_RetBool   = { returnType = Mini.Bool,   displayName = "09返回布尔", params = {} },
    T10_GlobalVar = { returnType = Mini.String, displayName = "10读全局变量", params = {} },
    T11_Forward   = { returnType = Mini.String, displayName = "11转发式调用", params = { "输入", Mini.Number } },
    T12_CallOther = { returnType = Mini.String, displayName = "12self调另一开放函数", params = {} },
    T13_Nested    = { returnType = Mini.String, displayName = "13多层嵌套函数体", params = {} },
}

function Script:T01_Env()
    print("[DIAG] ENTER T01_Env")
    local r = {}
    local function a(s) r[#r + 1] = tostring(s) end
    a("VER=" .. tostring(_VERSION))
    a("Mini=" .. type(Mini))
    a("bit=" .. type(bit))
    a("bit.bxor=" .. type(bit and bit.bxor))
    a("os.timeMs=" .. type(os and os.timeMs))
    local ok1, v1 = pcall(function() return string.char(255) end)
    a("char255=" .. tostring(ok1))
    local ok2, v2 = pcall(function() return bit.bxor(0xFF, 0x0F) end)
    a("bxor=" .. tostring(ok2) .. "/" .. tostring(v2))
    a("self=" .. type(self))
    return _emit("T01_Env", table.concat(r, " | "))
end

function Script:T02_Const()
    print("[DIAG] ENTER T02_Const")
    return _emit("T02_Const", "CONST_OK")
end

function Script:T03_LocalStr()
    print("[DIAG] ENTER T03_LocalStr")
    return _emit("T03_LocalStr", UP_STR)
end

function Script:T04_LocalFunc()
    print("[DIAG] ENTER T04_LocalFunc")
    return _emit("T04_LocalFunc", UP_FUNC(7))
end

function Script:T05_DeepLocal()
    print("[DIAG] ENTER T05_DeepLocal")
    return _emit("T05_DeepLocal", UP_FUNC_DEEPER(9))
end

function Script:T06_Decrypt()
    print("[DIAG] ENTER T06_Decrypt")
    local _r
    local ok, out = pcall(function() return _DEC(ENC_SAMPLE) end)
    if not ok then _r = "DEC_FAIL:" .. tostring(out)
    elseif out == ENC_EXPECT then _r = "DEC_OK"
    else _r = "DEC_MISMATCH got=[" .. tostring(out) .. "]" end
    return _emit("T06_Decrypt", _r)
end

function Script:T07_SelfProp()
    print("[DIAG] ENTER T07_SelfProp")
    return _emit("T07_SelfProp", "str=" .. tostring(self and self.testStr) .. " num=" .. tostring(self and self.testNum))
end

function Script:T08_RetNumber()
    print("[DIAG] ENTER T08_RetNumber")
    return _emit("T08_RetNumber", 123.5)
end

function Script:T09_RetBool()
    print("[DIAG] ENTER T09_RetBool")
    return _emit("T09_RetBool", true)
end

function Script:T10_GlobalVar()
    print("[DIAG] ENTER T10_GlobalVar")
    return _emit("T10_GlobalVar", tostring(GLOBAL_MARK))
end

function Script:T11_Forward(x)
    print("[DIAG] ENTER T11_Forward x=" .. tostring(x))
    return _emit("T11_Forward", impl_forward(self, x))
end

function Script:T12_CallOther()
    print("[DIAG] ENTER T12_CallOther")
    local ok, r = pcall(function() return self:T02_Const() end)
    return _emit("T12_CallOther", "ok=" .. tostring(ok) .. " ret=" .. tostring(r))
end

function Script:T13_Nested()
    print("[DIAG] ENTER T13_Nested")
    local function f1(v)
        local function f2(w)
            local function f3(u) return "NEST(" .. tostring(u) .. ")+" .. UP_STR end
            return f3(w)
        end
        return f2(v)
    end
    return _emit("T13_Nested", f1(5))
end

function Script:OnStart()
    print("[DIAG] ===== OnStart v2 开始 =====")
    print("[DIAG] 签名者：黎明破晓180792317")
    local names = { "T01_Env","T02_Const","T03_LocalStr","T04_LocalFunc","T05_DeepLocal",
                    "T06_Decrypt","T07_SelfProp","T08_RetNumber","T09_RetBool",
                    "T10_GlobalVar","T11_Forward","T12_CallOther","T13_Nested" }
    print("[DIAG] --- 阶段1：注册检查 ---")
    print("[DIAG] openFnArgs=" .. type(self.openFnArgs) .. " self=" .. type(self))
    print("[DIAG] --- 阶段2：OnStart 内自调用 ---")
    for i = 1, #names do
        local nm = names[i]
        local fn = self and self[nm]
        if type(fn) ~= "function" then
            print("[DIAG] " .. nm .. " -> NO_FUNC(" .. type(fn) .. ")")
        else
            local ok, ret = pcall(function() return fn(self) end)
            print("[DIAG] " .. nm .. " -> ok=" .. tostring(ok) .. " ret=" .. tostring(ret))
        end
    end
    print("[DIAG] --- 阶段3：upvalue ---")
    print("[DIAG] UP_STR=" .. tostring(UP_STR) .. " UP_FUNC_DEEPER=" .. tostring(UP_FUNC_DEEPER(0)))
    print("[DIAG] _DEC=" .. type(_DEC) .. " impl_forward=" .. type(impl_forward))
    print("[DIAG] --- 阶段4：解密链 ---")
    local okd, dv = pcall(function() return _DEC(ENC_SAMPLE) end)
    print("[DIAG] dec_ok=" .. tostring(okd) .. " match=" .. tostring(dv == ENC_EXPECT))
    print("[DIAG] --- 阶段5：属性 ---")
    print("[DIAG] self.testStr=" .. tostring(self.testStr) .. " self.testNum=" .. tostring(self.testNum))
    print("[DIAG] ===== OnStart 结束，现在请用触发器逐个调用 T01..T13 =====")
    return true
end

return Script
