---
name: skill-vault
description: |
  一键恢复入口。当 /data/skills 或 /data/memory 被重置、技能数量骤减、需要迁移历史经验，
  或用户说"能力恢复""技能库没了""恢复一下"时使用。本技能内联完整恢复命令，不依赖任何脚本
  （技能库被重置时脚本也一起没了，只写"跑某脚本"会失效）。
version: "2.0"
author: "重建于 2026-10-04"
---

# skill-vault — 一键恢复

本文件**内联全部恢复命令**，不依赖 `sync.sh` 或其他脚本。技能库被重置时脚本会一起消失，
所以这里写的是能直接复制执行的原始命令。

## Step 1 · 优先：增量同步（检测+恢复+备份一条命令）

```bash
bash /data/skills/memory-bootstrap/scripts/sync.sh
```

## Step 2 · 若 sync.sh 不存在：零依赖解压

```bash
cd / && unzip -qo /root/.skillvault/skills-bundle.zip \
  || unzip -qo ~/skills-bundle.zip \
  || unzip -qo /data/workspace/skills-bundle.zip
```

**铁律：必须在 `/` 下解压。** 包内路径是 `data/skills/...`，
在 `/data` 下解压会生成 `/data/data/skills`，等于没恢复。

## Step 3 · 备份包也全丢了：网络兜底

走 `codeload`，不走 `api`（api 未鉴权限流 60 次/小时，拉十几个技能必撞墙）：

```bash
cd /tmp && curl -sSL -m 180 -o r.tgz \
  "https://codeload.github.com/<owner>/<repo>/tar.gz/refs/heads/main" \
  && mkdir -p x && tar xzf r.tgz -C x && ls x
```

核心技能上游：

| 技能 | 上游仓库 | 仓库内子目录 |
|---|---|---|
| dev-expert | ebandao777-oss/dev-expert | `.` |
| skill-creator / frontend-design / canvas-design / webapp-testing / brand-guidelines | anthropics/skills | `skills/<名>` |
| crawl4ai | brettdavies/crawl4ai-skill | `.` |
| game-developer | Jeffallan/claude-skills | `skills/game-developer` |
| agent-browser | vercel-labs/agent-browser | `skill-data/core` |
| web-reverse-engineering | kings0527/web-reverse-engineering-skill（分支 **master**） | `.` |
| video | coreyhaines31/marketingskills | `skills/video` |

**下载后必须校验**，防止拿到 404 页面：

```bash
gzip -t r.tgz                            # 先校验再解压（部分仓库默认分支非 main）
head -12 /data/skills/<name>/SKILL.md    # frontmatter 必须有 name + description
wc -c  /data/skills/<name>/SKILL.md      # <500B 大概率是错误页
```

## Step 4 · 验证（不通过就别往下走）

```bash
ls /data/skills | wc -l        # 期望 >= 40
ls /data/memory                # 期望 MEMORY.md SESSION_LOG.md snapshots
```

## Step 5 · 恢复后必读（这是"迁移经验"的关键）

```bash
cat /data/memory/MEMORY.md                    # 环境事实、已建能力、铁律
cat /data/memory/SESSION_LOG.md               # 任务进度表
cat /data/memory/.ai-memory/DECISIONS.md      # 架构决策（含被否决方案与原因）
cat /data/memory/.ai-memory/CONVENTIONS.md    # 目录约定、标准命令集
cat /data/memory/.ai-memory/ERROR_LEDGER.md   # 踩过的坑与解法
```

必须真的读，不能跳过。只恢复文件不读进上下文，等于没迁移经验。

## 网络通路实测

| 通道 | 状态 | 用途 |
|---|---|---|
| codeload.github.com | ✅ 通，不计 API 配额 | 整仓 tar.gz，首选 |
| api.github.com | ⚠️ 通但 60 次/小时 | 列仓库、查真名 |
| skillhub.cn | ❌ 403 | 取同源 GitHub 仓库代替 |
| registry.npmjs.org | ❌ 403 | 不可用 |
| cdn.jsdelivr.net | ❌ 301→502 | 不可用 |
| raw.githubusercontent.com | ❌ 超时 | 不指望 |
