---
name: skills-keeper
description: |
  技能库保活与健康巡检。/data/skills 每次会话都可能被重置，本技能负责检测技能是否还在、
  缺失就触发恢复、并做一次体检（frontmatter 完整、脚本可执行、符号链接有效、体积异常）。
  当用户问"我的技能还在吗""技能是不是丢了""做个技能体检""技能库状态"时使用；
  每次会话开场也可先跑一次。触发词：技能还在吗、技能体检、保活、技能库状态、检查技能。
version: "2.0"
author: "重建于 2026-10-04（原版仅存在于已丢失备份包，按规格重建）"
---

# skills-keeper — 技能库保活

## 铁律

技能库重置是既定事实，**不能靠"记得自己有什么技能"**，必须每次跑检测。

## 一键体检

```bash
bash /data/skills/memory-bootstrap/scripts/sync.sh   # 检测 + 自动还原 + 增量备份
```

体检报告（自己拼）：

```bash
echo "技能总数: $(ls /data/skills | wc -l)"        # 期望 >= 40
ls /data/skills                                     # 看有无明显缺项
# frontmatter 校验：每个自建技能必须有 name + description
for d in /data/skills/*/; do
  f="$d/SKILL.md"
  [ -f "$f" ] || { echo "缺 SKILL.md: $d"; continue; }
  head -1 "$f" | grep -q '^---' || echo "非标准(多为平台内置符号链接，正常): $d"
  [ "$(wc -c < "$f")" -lt 500 ] && echo "体积异常小(<500B，可能是错误页): $f"
done
# 脚本可执行性
find /data/skills -name '*.sh' -o -name '*.py' | while read -r s; do
  [ -x "$s" ] || echo "不可执行: $s"
done
# 符号链接有效性（平台内置技能指向 /mnt/official_skills）
find /data/skills -maxdepth 1 -type l ! -e -print
```

## 判定标准

| 检查项 | 正常 | 处理 |
|---|---|---|
| 技能总数 | ≥40 | <20 说明被重置，走恢复 |
| SKILL.md 体积 | ≥500B | <500B 大概率是 404 页面，重下 |
| frontmatter | 有 name + description | 缺失则该技能不会被路由命中 |
| 现脚本 | 可执行 | `chmod +x` |
| 死符号链接 | 无 | 平台内置技能失效需报告，不自行修 |

## 平台内置 vs 自建

- 平台内置（docx/pdf/pptx/xlsx/task_schedule/tdocs-cli/file-format-converter 等）是
  指向 `/mnt/official_skills/` 的符号链接，frontmatter 校验会报 "no frontmatter"，**属正常，不要修**
- 自建/第三方技能必须能通过上述体检

## 纪律

- 体检完要**如实报缺失项**，不要把"应该有"说成"已装上"
- 发现缺失先走 sync.sh 自动还原；还原不了再走网络兜底（codeload，非 api）
- 不要为了凑数写空壳 SKILL.md；每个技能必须有真实可执行的步骤
