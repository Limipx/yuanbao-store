# -*- coding: utf-8 -*-
"""
Lua 5.1 词法分析器（专为迷你世界 UGC 3.0 混淆器设计）

与通用 parser 的差异：保留全部原文位置信息，支持"按下标替换"，
这样重命名不会破坏注释、长字符串、转义序列等任何原始文本。

支持：
  - 短注释 -- 到行尾；长注释 --[[ ]] / --[==[ ]==]
  - 长字符串 [[ ]] / [=[ ]=]
  - 短字符串 "..." '...' 含全部 Lua 转义
  - 数字：十进制、十六进制、指数、小数点
  - 标识符、运算符、长运算符（.. ... == ~= <= >= // 等）
"""
import re

# Lua 5.1 保留字
KEYWORDS = {
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
    'function', 'if', 'in', 'local', 'nil', 'not', 'or', 'repeat',
    'return', 'then', 'true', 'until', 'while',
}

# 长运算符优先匹配（长度降序）
OPS = [
    '...', '..', '==', '~=', '<=', '>=', '//',
    '+', '-', '*', '/', '%', '^', '#',
    '<', '>', '=', '(', ')', '{', '}', '[', ']',
    ';', ':', ',', '.',
]

NUM_RE = re.compile(r'0[xX][0-9a-fA-F]+|[0-9]*\.?[0-9]+(?:[eE][+-]?[0-9]+)?')
IDENT_RE = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')


class Tok:
    __slots__ = ('kind', 'val', 's', 'e', 'line')

    def __init__(self, kind, val, s, e, line):
        self.kind = kind      # kw / name / num / str / op / comment / ws / other
        self.val = val        # 原文
        self.s = s            # 起始下标
        self.e = e            # 结束下标（不含）
        self.line = line

    def __repr__(self):
        return 'Tok(%s,%r,%d)' % (self.kind, self.val, self.s)


def _match_long_bracket(src, i):
    """i 指向 '['。返回 (content_start, content_end, after_end) 或 None。
    处理 [=[ ... ]=] 形式的等号层级。"""
    j = i + 1
    level = 0
    if j < len(src) and src[j] == '[':
        j += 1
    elif j < len(src) and src[j] == '=':
        while j < len(src) and src[j] == '=':
            level += 1
            j += 1
        if j >= len(src) or src[j] != '[':
            return None
        j += 1
    else:
        return None
    close = ']' + '=' * level + ']'
    k = src.find(close, j)
    if k < 0:
        return None
    return j, k, k + len(close)


def tokenize(src):
    """返回 token 列表（含空白与注释，保证 s..e 覆盖全文、可无损还原）。"""
    toks = []
    i = 0
    n = len(src)
    line = 1
    while i < n:
        c = src[i]

        # 空白（含换行）
        if c in ' \t\r\n\f\v':
            j = i
            while j < n and src[j] in ' \t\r\n\f\v':
                if src[j] == '\n':
                    line += 1
                j += 1
            toks.append(Tok('ws', src[i:j], i, j, line))
            i = j
            continue

        # 注释
        if c == '-' and i + 1 < n and src[i + 1] == '-':
            lb = _match_long_bracket(src, i + 1)
            if lb is not None:
                cs, ce, ae = lb
                text = src[i:ae]
                toks.append(Tok('comment', text, i, ae, line))
                line += text.count('\n')
                i = ae
                continue
            j = src.find('\n', i)
            if j < 0:
                j = n
            toks.append(Tok('comment', src[i:j], i, j, line))
            i = j
            continue

        # 长字符串
        if c == '[':
            lb = _match_long_bracket(src, i)
            if lb is not None:
                cs, ce, ae = lb
                text = src[i:ae]
                toks.append(Tok('str', text, i, ae, line))
                line += text.count('\n')
                i = ae
                continue

        # 短字符串
        if c in '"\'':
            q = c
            j = i + 1
            while j < n:
                if src[j] == '\\':
                    j += 2
                    continue
                if src[j] == q:
                    j += 1
                    break
                if src[j] == '\n':
                    break
                j += 1
            text = src[i:j]
            toks.append(Tok('str', text, i, j, line))
            line += text.count('\n')
            i = j
            continue

        # 数字（含 .5 这种以点开头）
        m = NUM_RE.match(src, i)
        if m and (c.isdigit() or (c == '.' and i + 1 < n and src[i + 1].isdigit())):
            toks.append(Tok('num', m.group(0), i, m.end(), line))
            i = m.end()
            continue

        # 标识符 / 关键字
        m = IDENT_RE.match(src, i)
        if m:
            w = m.group(0)
            toks.append(Tok('kw' if w in KEYWORDS else 'name', w, i, m.end(), line))
            i = m.end()
            continue

        # 运算符
        for op in OPS:
            if src.startswith(op, i):
                toks.append(Tok('op', op, i, i + len(op), line))
                i += len(op)
                break
        else:
            toks.append(Tok('other', c, i, i + 1, line))
            i += 1
    return toks


def significant(toks):
    """去掉空白与注释后的 token 列表（保留原对象引用）。"""
    return [t for t in toks if t.kind not in ('ws', 'comment')]
