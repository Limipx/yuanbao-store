# -*- coding: utf-8 -*-
"""
Lua 5.1 作用域分析：找出所有"可安全重命名"的局部标识符出现点。

安全策略（保守优先，宁可少改名也不能改错）：
  1. 只处理词法作用域内的 local 绑定：local 声明、函数参数、for 循环变量
  2. 绝不碰全局名（World / Player / CloudSever / TriggerEvent ... 引擎 API）
  3. 绝不碰表字段名：q.OnStart / v["宗主"] / b.eventobjid —— 这些是引擎约定键
  4. 遇到任何语法结构不确定的地方，整体放弃该文件块的改名（fail-safe）

对文档1那种真实玩家脚本（大量 q.xxx / b.eventobjid / v.list[sz][3]）尤其重要：
字段名一旦被改，脚本立刻失效。
"""
from lualex import tokenize, significant, KEYWORDS


class Scope:
    __slots__ = ('names', 'parent')

    def __init__(self, parent=None):
        self.names = {}   # name(原) -> slot_id(int)
        self.parent = parent

    def lookup(self, name):
        s = self
        while s is not None:
            if name in s.names:
                return s.names[name]
            s = s.parent
        return None

    def declare(self, name, slot):
        self.names[name] = slot


class RenamePoint:
    __slots__ = ('tok', 'slot')

    def __init__(self, tok, slot):
        self.tok = tok
        self.slot = slot


# 块级开始/结束关键字
BLOCK_OPEN = {'do', 'then', 'else', 'function', 'repeat'}
BLOCK_KEEP = {'elseif', 'else'}   # 不新建作用域，复用当前层


def analyze(src):
    """返回 (points, slots_count, warns)
    points: RenamePoint 列表，每个含 token 与其所属 slot
    """
    toks = tokenize(src)
    ts = significant(toks)
    points = []
    warns = []
    slot_seq = [0]

    def new_slot():
        slot_seq[0] += 1
        return slot_seq[0]

    root = Scope(None)
    cur = root
    i = 0
    n = len(ts)
    # 表构造器深度：>0 时 `X = expr` 里的 X 是**字段键名**，绝不能改名。
    # 踩过的坑：{name=..., lv=1} 里的 name/lv 被当变量改名，脚本直接失效。
    # 区分方法就看"标识符后是否紧跟单个 '='"，数组元素后面是 ',' 或 '}'，不受影响。
    brace_depth = 0

    def is_op(t, v):
        return t is not None and t.kind == 'op' and t.val == v

    def is_kw(t, v):
        return t is not None and t.kind == 'kw' and t.val == v

    while i < n:
        t = ts[i]

        # ---------- local 声明 ----------
        if t.kind == 'kw' and t.val == 'local':
            j = i + 1
            # local function NAME
            if j < n and is_kw(ts[j], 'function'):
                j += 1
                if j < n and ts[j].kind == 'name':
                    slot = new_slot()
                    cur.declare(ts[j].val, slot)
                    points.append(RenamePoint(ts[j], slot))
                    # 函数参数
                    j = _scan_params(ts, j + 1, cur, lambda: new_slot(), points, warns)
                continue_after = j
                i = continue_after
                continue
            # local a, b, c [= ...]
            names = []
            while j < n and ts[j].kind == 'name':
                names.append(ts[j])
                j += 1
                if j < n and is_op(ts[j], ','):
                    j += 1
                    continue
                break
            for nt in names:
                slot = new_slot()
                cur.declare(nt.val, slot)
                points.append(RenamePoint(nt, slot))
            i = j
            continue

        # ---------- function 定义 ----------
        if t.kind == 'kw' and t.val == 'function':
            j = i + 1
            # 函数名：可能是 Name（全局或局部）或 a.b.c / a:b
            if j < n and ts[j].kind == 'name':
                base = ts[j]
                j += 1
                # 跳过 .field / :field（字段绝不改名）
                while j + 1 < n and is_op(ts[j], '.') or is_op(ts[j], ':'):
                    if is_op(ts[j], '.') or is_op(ts[j], ':'):
                        j += 1
                        if j < n and ts[j].kind == 'name':
                            j += 1   # 字段名：跳过，不改名
                        else:
                            break
                    else:
                        break
                # base 本身：若已声明为 local，则这是一次"赋值"，也是一个引用点
                slot = cur.lookup(base.val)
                if slot is not None:
                    points.append(RenamePoint(base, slot))
            # 参数
            j = _scan_params(ts, j, cur, lambda: new_slot(), points, warns)
            i = j
            continue

        # ---------- for ----------
        if t.kind == 'kw' and t.val == 'for':
            j = i + 1
            # 收集 for 和 (in 或 =) 之间的 name
            while j < n and ts[j].kind == 'name':
                slot = new_slot()
                cur.declare(ts[j].val, slot)
                points.append(RenamePoint(ts[j], slot))
                j += 1
                if j < n and is_op(ts[j], ','):
                    j += 1
                    continue
                break
            i = j
            continue

        # ---------- 作用域进出 ----------
        if t.kind == 'kw' and t.val in ('do', 'then', 'repeat'):
            cur = Scope(cur)
            i += 1
            continue
        if t.kind == 'kw' and t.val == 'function':
            pass
        if t.kind == 'kw' and t.val in ('end', 'until'):
            if cur.parent is not None:
                cur = cur.parent
            i += 1
            continue
        if t.kind == 'op' and t.val == '{':
            brace_depth += 1
            cur = Scope(cur)
            i += 1
            continue
        if t.kind == 'op' and t.val == '}':
            brace_depth -= 1
            if brace_depth < 0:
                brace_depth = 0
            if cur.parent is not None:
                cur = cur.parent
            i += 1
            continue

        # ---------- 普通标识符引用 ----------
        if t.kind == 'name':
            # 前面是 . 或 : → 字段访问，跳过
            if i > 0 and (is_op(ts[i - 1], '.') or is_op(ts[i - 1], ':')):
                i += 1
                continue
            # 表构造器里的键名 { k = v } → 跳过（不是 == 比较）
            if brace_depth > 0 and i + 1 < n and is_op(ts[i + 1], '='):
                i += 1
                continue
            slot = cur.lookup(t.val)
            if slot is not None:
                points.append(RenamePoint(t, slot))
            i += 1
            continue

        i += 1

    return points, slot_seq[0], warns


def _scan_params(ts, i, outer, new_slot, points, warns):
    """i 指向 '(' 或参数列表起点。返回参数列表结束后的下标。
    参数属于函数体作用域，这里新建一层。"""
    n = len(ts)
    while i < n and not (ts[i].kind == 'op' and ts[i].val == '('):
        if ts[i].kind == 'kw' or (ts[i].kind == 'op' and ts[i].val in (')', '}')):
            return i
        i += 1
    if i >= n:
        return i
    i += 1   # 跳过 '('
    body = Scope(outer)
    while i < n and not (ts[i].kind == 'op' and ts[i].val == ')'):
        if ts[i].kind == 'name':
            if ts[i].val == '...':
                i += 1
                continue
            slot = new_slot()
            body.declare(ts[i].val, slot)
            points.append(RenamePoint(ts[i], slot))
        i += 1
    i += 1   # 跳过 ')'
    return i
