---
name: mini-world-ugc3-lua
description: |
  迷你世界 UGC 3.0 的 Lua 5.1 组件脚本开发专家。当用户要写、改、审查、调试"迷你世界"UGC 3.0 /
  迷你世界创作者 / Mini World 的 .lua 组件脚本时使用；负责生成符合规范的组件脚本（Script 表、
  propertys、openFnArgs、OnStart、return Script）、触发器事件与组件事件注册、房间/云服广播消息、
  组件互调与跨对象操作、Mini.Array 数组与类型系统、协程与 ThreadWork 并发、Lua 5.1 语法与陷阱排查、
  以及用 UGCLua.txt / UGCLuaMgr.lua 运行时 dump 核对 API 与枚举是否存在。
  触发词：迷你世界、UGC 3.0、UGC3、Mini World、组件脚本、Script:OnStart、propertys、openFnArgs、
  Mini.Number、Mini.Array、TriggerEvent、ObjectEvent、AddTriggerEvent、AddCustomEvent、
  PushCustomEvent、AddCloudSeverEvent、CurEventParam、ThreadWork、coroutine、GetComponent、
  FindObject、GetWorld、ObjType、ComponentUIStyle、积木触发器、开放函数。
  只要出现"迷你世界/UGC/组件脚本/lua 组件"任一信号就应加载本技能，不要等用户把 API 名说全。
version: "1.0"
author: "基于用户提供的 9 份官方知识文档 + 运行时 dump 构建"
---

# 迷你世界 UGC 3.0 · Lua 5.1 开发专家

## 铁律（先于一切）

1. **Lua 5.1，不是 5.4**。禁止 `goto` / `::label::` / `//` 整除 / `bit32` / `table.unpack` /
   `\z` 转义 / `#...` 变长参数取长。用 `unpack(...)`、`...` 手动计数。
   **位运算直接用引擎自带的 `bit` 模块**（`bit.band/bor/bxor/bnot/lshift/rshift/rol/tobit/tohex`），
   不要自己写逐位循环，更不要用 `bit32`（那是 Lua 5.2 的，这里没有）。见 `10`。
2. **组件脚本必须是表封装 + `return Script`**。`local Script = {}` … `return Script`，
   函数名/表名可自取，但结尾必须返回。
3. **非函数字段必须初始化在 `OnStart()` 里**。自定义表中不能有非函数字段（编辑器规范硬约束），
   数据初始化一律放进 `OnStart`。
4. **事件监听只在 `OnStart()` 注册**，`OnDestroy()` 里移除。
5. **"数组"有三套，别混用**（见 `13`）：编辑器配置用组件属性 `Mini.Array`（`self.xxx` 访问）；
   触发器传值用 `arrayWrapper()` 包装（不能直接写 `Mini.Array`）；运行时存取用 `Data.Array`
   （按 `varId` + `playerId`）。
6. **所有变量 ID 格式统一**：`v` + 数字串（如 `v755795669086467993342623`），
   数组、二维表都一样。照抄即可，不要猜格式、不要做前缀以外的结构校验。
7. **不编造 API**。不确定某个类/枚举/方法是否存在时，先查 `references/09-api-index.md`，
   查不到就查运行时 dump（见 §7），再查不到就明说"未确认"，不要用其他游戏的 API 脑补。

## 目录

| 文件 | 何时读 |
|---|---|
| `references/01-component-spec.md` | 写组件骨架、定义属性、开放函数 |
| `references/02-event-system.md` | 注册事件、取事件参数、做事件过滤 |
| `references/03-broadcast.md` | 房间广播 / 云服广播收发 |
| `references/04-component-interop.md` | 组件互调、跨对象、读写属性 |
| `references/05-coroutine-thread.md` | 协程、ThreadWork、性能取舍 |
| `references/06-array-types.md` | Mini 类型系统、Array 包装、枚举 |
| `references/07-lua51-constraints.md` | Lua 5.1 陷阱、常见报错 |
| `references/08-debug.md` | 打印、遍历接口、定位问题 |
| `references/09-api-index.md` | 核对类/枚举是否存在及其方法面（含 CustomUI/ElementType） |
| `references/10-stdlib-ext.md` | bit 模块、table/string 引擎扩展 |
| `references/11-ui-element-recipes.md` | UI 元件绘制：坐标规则、元件池、矩形合并、降采样、批处理 |
| `references/11-ui-block-patterns.md` | 批量画元件/图片：官方 CreateBlock 范式、threadpool 让出、RLE 与消缝 |
| `references/12-mini-llm.md` | 检索式对话模型：二维表存语料、CSV 导入格式、诊断体系 |
| `references/13-mini-array.md` | **数组的三种体系**（属性数组 / arrayWrapper / Data.Array）、变量 ID 格式统一规则 |

## 最小可用骨架

```lua
local Script = {}

Script.propertys = {
    -- 属性定义，见 01
}

Script.openFnArgs = {
    -- 开放函数定义，见 01
}

function Script:OnStart()
    -- 数据初始化 + 事件注册
end

function Script:OnDestroy()
    -- 移除监听
end

return Script
```

## 标准工作流

1. **确认需求**：是组件脚本（挂在对象上）还是独立模块？要开放给触发器吗？
2. **查 API**：涉及的类/枚举先查 `09-api-index.md`；不确定就查 dump
3. **写脚本**：按 `01` 骨架写，`OnStart` 放初始化与注册
4. **语法与规范自检**：
   ```bash
   python3 /data/skills/mini-world-ugc3-lua/scripts/ugc_lua_check.py 你的脚本.lua
   ```
   检查 Lua 5.1 语法（luaparser）+ 5.2+ 特性误用 + 组件规范（return Script / OnStart /
   openFnArgs 结构 / 中文标点 / 非函数字段写在表外）
5. **交付**：给出完整脚本 + 说明"哪些地方要替换成你自己的 ID（组件 id / 对象 id 需从编辑器
   【ID库】插入）"

## 三个高频坑

- **组件 id / 对象 id 不能手写**：`self:GetComponent("组件id")` 与 `GameObject:FindObject("对象id")`
  的 id 必须由编辑器顶部【ID库】→【组件】/【对象】插入，手敲字符串会取不到。交付时把这一点标出来。
- **数组返回类型要用包装函数**：`openFnArgs` 的 `returnType` 直接写 `Mini.Array` 不行，
  参考 `06-array-types.md` 的 `arrayWrapper`（完整版在 `13`）。
- **数组属性可能是 nil**：关键配置别只押在 `Mini.Array` 属性上，要有
  字符串属性 / 内置默认 / 运行时覆盖三层兜底。见 `13.1`。
- **纯 Lua 计算别用 ThreadWork**：Lua 有 GIL，纯计算并行加速比实测 1.00x；只有 I/O / 休眠
  这类阻塞才用线程池（约 3.5x）。见 `05`。
- **批量创建元件要主动让出主线程**：每 50~500 个 `threadpool:wait(0)` 一次，否则大图生成会卡死。
  `threadpool` 只有 `work/wait/Work/Wait` 四个成员，**没有 `default`**；
  别在 `threadpool.work` 的闭包里 `coroutine.yield()`（那不是协程，会报错）。见 `11`。

## 语法校验脚本

```bash
python3 /data/skills/mini-world-ugc3-lua/scripts/ugc_lua_check.py <file.lua> [--no-spec]
```

- 依赖 `luaparser`（已装 4.2.0；沙盒重置后重装：`pip install luaparser`，pypi 直连 403 需走内部镜像）。
  缺失时自动降级为纯正则检查，并明确提示"语法未校验"。
- `--no-spec` 只查语法与 Lua 5.1 合规，不查组件规范。
- 注意：`luaparser` 能解析部分 5.2+ 语法，**5.1 合规以 B 段（Lua 5.2+ 特性检测）为准**，A 段只保证"能被解析"。
- **结果不修饰**：语法报错就把行列报出来；规范告警就列出具体项。

## 纪律

- 交付前跑一遍校验脚本，不写"应该没问题"
- 涉及触发器/编辑器里才能验证的行为（如属性面板显示、积木块显示），脚本层面无法验证的部分要说清
- 用户给的两份 dump（`UGCLua.txt` 13.3MB JSON、`UGCLuaMgr.lua` 17.4MB 纯文本）是运行时对象树，
  不是可执行代码，**不要试图 require 或执行它们**
