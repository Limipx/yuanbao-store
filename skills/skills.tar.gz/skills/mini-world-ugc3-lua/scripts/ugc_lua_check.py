#!/usr/bin/env python3
"""
ugc_lua_check.py — 迷你世界 UGC 3.0 Lua 5.1 脚本静态检查

用法:
  python3 ugc_lua_check.py <file.lua> [<file2.lua> ...]
  python3 ugc_lua_check.py --dir <目录>

检查三类问题:
  A. 语法      —— luaparser 解析（Lua 5.1）；缺失 luaparser 时降级为纯正则并明确提示
  B. Lua 5.1   —— 检测 5.2/5.3/5.4 才有的语法与库函数
  C. UGC 3.0   —— 组件表封装/return、表体非函数字段、事件注册位置、数组返回类型、
                  组件 id 是否手写等规范

退出码: 0 = 无 ERROR；1 = 有 ERROR
不编造：luaparser 不可用就明确说"语法未校验"，不假装通过。
"""
import argparse
import os
import re
import sys

def strip_comments(src: str) -> str:
    """去掉 Lua 注释，保留行数与行内非注释部分（粗略但够用：
    -  --[[ ... ]] 块注释
    -  -- 行注释
    字符串里的 -- 不做精确判定，宁可少报不误报）"""
    out = []
    i = 0
    n = len(src)
    in_block = False
    while i < n:
        if in_block:
            j = src.find("]]", i)
            if j < 0:
                out.append("\n" * src.count("\n", i))
                break
            out.append("\n" * src.count("\n", i, j + 2))
            i = j + 2
            in_block = False
            continue
        if src.startswith("--[[", i):
            in_block = True
            i += 4
            continue
        if src.startswith("--", i):
            j = src.find("\n", i)
            if j < 0:
                break
            i = j
            continue
        out.append(src[i])
        i += 1
    return "".join(out)


def mask_strings(src: str) -> str:
    """把字符串字面量内容替换成等长空白，保留引号与换行（行号不变）。
    数据脚本里 '"LLM1|"'、'[，。！？、,.!?~～]' 这类字符串含 | ~，
    不遮罩会被位运算符规则误报成 5.3 语法。"""
    out = []
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        m = re.match(r"\[(=*)\[", src[i:])
        if m:
            eq = m.group(1)
            close = "]" + eq + "]"
            j = src.find(close, i + len(m.group(0)))
            if j < 0:
                out.append(src[i:])
                break
            seg = src[i:j + len(close)]
            out.append(re.sub(r"[^\n]", " ", seg))
            i = j + len(close)
            continue
        if c in ('"', "'"):
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == c or src[j] == "\n":
                    break
                j += 1
            seg = src[i:min(j + 1, n)]
            out.append(re.sub(r"[^\n]", " ", seg))
            i = min(j + 1, n)
            continue
        out.append(c)
        i += 1
    return "".join(out)


LEVEL_ORDER = {"ERROR": 0, "WARN": 1, "INFO": 2}

# ---------- B. Lua 5.2+ 特性检测 ----------
LUA52_PATTERNS = [
    (r"\bgoto\s+[A-Za-z_]\w*", "ERROR", "goto 是 Lua 5.2 语法，5.1 不支持"),
    (r"::[A-Za-z_]\w*::", "ERROR", "::label:: 是 Lua 5.2 语法，5.1 不支持"),
    (r"\bbit32\s*\.", "ERROR", "bit32 库是 Lua 5.2 引入，5.1 无此库"),
    (r"\btable\.unpack\b", "ERROR", "table.unpack 是 5.2 写法，5.1 用全局 unpack()"),
    (r"\btable\.pack\b", "ERROR", "table.pack 是 5.2 写法，5.1 无此函数"),
    (r"//", "ERROR", "// 整数除法是 Lua 5.3 语法，5.1 用 math.floor(a/b)"),
    (r"\\z", "ERROR", "\\z 转义是 Lua 5.2 引入"),
    (r"<<|>>", "ERROR", "位移运算符是 Lua 5.3 语法，5.1 无位运算符"),
    (r"(?<![~=<>])[&|](?![&|=])", "INFO", "疑似 5.3 位运算符 & |，确认是否误写"),
    # 二元 ~（按位异或）：5.1 里 ~ 只出现在 ~= 中，单独出现必是 5.3 语法。
    # 实测：引擎报 "')' expected near '~'"，而 luaparser 能解析，测不出来。
    (r"(?<![~=<>])~(?![=])", "ERROR", "二元 ~ 是 Lua 5.3 按位异或，5.1 不支持（用 bit.bxor）"),
    (r"<\s*(const|close)\s*>", "ERROR", "<const>/<close> 是 Lua 5.4 语法"),
]

# ---------- C. UGC 3.0 规范检测 ----------
def check_ugc(src: str, path: str, out: list):
    fname = os.path.basename(path)

    # C1 表封装 + return
    has_table = re.search(r"^\s*local\s+(\w+)\s*=\s*\{\s*\}", src, re.M)
    # 顶层 return 判定：取文件最后一条非空、非注释语句
    tail_lines = [l for l in src.splitlines() if l.strip() and not l.strip().startswith("--")]
    has_return = bool(tail_lines) and re.match(r"^\s*return\s+\w+\s*(--.*)?$", tail_lines[-1])
    if not has_table:
        out.append(("ERROR", "C1", "未找到组件表定义（应为 local Script = {}）"))
    if not has_return:
        out.append(("ERROR", "C1", "文件末尾缺少 return <组件表名>"))
    comp = has_table.group(1) if has_table else None
    if comp and has_return:
        ret = re.match(r"^\s*return\s+(\w+)", tail_lines[-1])
        if ret and ret.group(1) != comp:
            out.append(("WARN", "C1", f"return 的是 {ret.group(1)}，而表定义名是 {comp}"))

    # C2 表体非函数字段（只允许 propertys / openFnArgs / Enum*）
    if comp:
        for m in re.finditer(rf"^\s*{re.escape(comp)}\.(\w+)\s*=", src, re.M):
            field = m.group(1)
            if field in ("propertys", "openFnArgs"):
                continue
            if "Enum" in field or field.isupper():
                continue
            # 判断赋的是不是函数
            tail = src[m.end():m.end() + 40].lstrip()
            is_func = tail.startswith("function") or re.match(r"^[A-Za-z_]\w*\s*(--|\n|$)", tail)
            if not is_func:
                out.append(("WARN", "C2",
                            f"{comp}.{field} 是非函数字段，初始化数据应放进 OnStart"))

    # C3 事件注册位置
    for m in re.finditer(r"\b(AddTriggerEvent|AddEvent|AddCustomEvent|AddCloudSeverEvent)\s*\(", src):
        line_no = src[:m.start()].count("\n") + 1
        # 找该函数所在的最近 function 定义
        before = src[:m.start()]
        fdef = None
        for fd in re.finditer(r"function\s+[\w:.]+", before):
            fdef = fd.group(0)
        if fdef and "OnStart" not in fdef:
            out.append(("WARN", "C3",
                        f"第 {line_no} 行 {m.group(1)} 不在 OnStart 内（最近的函数是 {fdef}）"))

    # C4 数组返回类型
    if re.search(r"returnType\s*=\s*Mini\.Array\s*\(", src):
        out.append(("ERROR", "C4",
                    "数组返回类型不能直接写 Mini.Array(...)，需用 arrayWrapper(...) 包装（见 06）"))

    # C5 手写组件 id / 对象 id
    for m in re.finditer(r"GetComponent\s*\(\s*[\"']([^\"']+)[\"']\s*\)", src):
        val = m.group(1)
        if val in ("组件id", "对象id") or re.fullmatch(r"[一-龥]+", val):
            out.append(("WARN", "C5",
                        f"GetComponent(\"{val}\") 疑似手写占位 id，应从编辑器【ID库】插入"))
    for m in re.finditer(r"FindObject\s*\(\s*[\"']([^\"']+)[\"']\s*\)", src):
        val = m.group(1)
        if val in ("组件id", "对象id") or re.fullmatch(r"[一-龥]+", val):
            out.append(("WARN", "C5",
                        f"FindObject(\"{val}\") 疑似手写占位 id，应从编辑器【ID库】插入"))

    # C6 ThreadWork 用于纯计算
    if "ThreadWork" in src and not re.search(r"ThreadWait\s*\(", src):
        out.append(("WARN", "C6",
                    "用了 ThreadWork 但没有 ThreadWait 等待/轮询"))

    # C7 unpack vs table.unpack 已在 B 段；这里补 select('#', ...)
    if re.search(r"#\s*\{\s*\.\.\.", src) or re.search(r"#\s*\(\s*\.\.\.", src):
        out.append(("ERROR", "C7", "对 vararg 用 # 取长度，5.1 不支持，请用 select('#', ...)"))

    # C8 广播回调参数个数
    for m in re.finditer(r"AddCustomEvent\s*\(\s*[\"'][^\"']+[\"']\s*,\s*function\s*\(([^)]*)\)", src):
        args = [a.strip() for a in m.group(1).split(",") if a.strip()]
        if len(args) == 4:
            out.append(("INFO", "C8",
                        "匿名广播回调应为 5 参 (cmp, eventId, p1, p2, p3)，当前 4 参"))


def check_file(path: str, out: list, spec: bool = True):
    try:
        src = open(path, "r", encoding="utf-8", errors="replace").read()
    except Exception as e:
        out.append(("ERROR", "IO", f"读取失败: {e}"))
        return

    # A. 语法
    try:
        from luaparser import ast  # type: ignore
        try:
            ast.parse(src)
            out.append(("INFO", "A", "luaparser 语法解析通过"))
        except Exception as e:
            msg = str(e).strip()
            n_ret = len(re.findall(r"^\s*return\s+\w+\s*(--.*)?$", src, re.M))
            if n_ret > 1:
                out.append(("WARN", "A",
                            f"解析失败：文件里有 {n_ret} 处顶层 return，"
                            "疑似多个组件拼在一个文件里（一个 .lua 只应有一个组件表）"))
            elif not msg or msg == "None":
                out.append(("ERROR", "A", f"luaparser 解析失败（无详细信息）：{type(e).__name__}"))
            else:
                out.append(("ERROR", "A", f"语法错误: {msg[:200]}"))
    except ImportError:
        out.append(("WARN", "A",
                    "luaparser 未安装，语法未校验（pip install luaparser）"))
        # 降级：括号/end 粗配平
        if src.count("function") > 0:
            n_func = len(re.findall(r"\bfunction\b", src))
            n_end = len(re.findall(r"\bend\b", src))
            if n_end < n_func:
                out.append(("WARN", "A", f"end({n_end}) 少于 function({n_func})，可能缺 end"))

    # B. Lua 5.2+ 特性（注意：luaparser 能解析部分 5.2+ 语法，
    #     所以 5.1 合规以本段为准，A 段只保证"能被解析"）
    #     先剥注释，避免把注释里的 // 之类当成代码
    code = mask_strings(strip_comments(src))
    for pat, lvl, msg in LUA52_PATTERNS:
        for m in re.finditer(pat, code):
            line_no = code[:m.start()].count("\n") + 1
            out.append((lvl, "B", f"第 {line_no} 行: {msg}  ->  {m.group(0)!r}"))

    # C. UGC 规范
    if spec:
        check_ugc(src, path, out)


def main():
    ap = argparse.ArgumentParser(description="迷你世界 UGC 3.0 Lua 5.1 脚本静态检查")
    ap.add_argument("files", nargs="*")
    ap.add_argument("--dir")
    ap.add_argument("--no-spec", action="store_true", help="只查语法与 Lua 5.1 合规，不查组件规范")
    a = ap.parse_args()

    files = list(a.files)
    if a.dir:
        for root, _, names in os.walk(a.dir):
            for n in names:
                if n.endswith((".lua", ".txt")):
                    files.append(os.path.join(root, n))
    if not files:
        sys.exit("未指定文件（用 <file.lua> 或 --dir <目录>）")

    has_error = False
    for f in files:
        out = []
        check_file(f, out, spec=not a.no_spec)
        out.sort(key=lambda x: LEVEL_ORDER.get(x[0], 9))
        print(f"\n===== {f} =====")
        if not out:
            print("  无问题")
        for lvl, cat, msg in out:
            print(f"  [{lvl:5}] {cat}: {msg}")
            if lvl == "ERROR":
                has_error = True
    sys.exit(1 if has_error else 0)


if __name__ == "__main__":
    main()
