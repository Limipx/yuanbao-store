# 13 · 迷你世界「数组」完全指南

> 来源：组件知识大汇总.txt、组件属性.txt、1.53.1数组实现.txt、Data.Array数组知识2.txt、
> 道具搜索3.lua、权重脚本（有/无属性）.lua —— 官方文档 + 实测组件双源

## 13.0 先分清：迷你世界里"数组"是三套完全不同的东西

这是最大的认知陷阱。它们名字都带 Array，但**所属层、写法、生命周期完全不同**，
混用会直接写出跑不通的代码。

| # | 名称 | 属于哪一层 | 写在哪 | 本质 | 典型用途 |
|---|---|---|---|---|---|
| 1 | **组件属性数组** `Mini.Array` | 编辑器属性面板 | `Script.propertys` | 配置数据，玩家在面板里填 | 搜索范围组、权重池配置 |
| 2 | **开放函数数组** `arrayWrapper()` | 触发器 ↔ 脚本 | `Script.openFnArgs` | 函数入参/返回值的**类型声明** | 返回一批结果给触发器 |
| 3 | **运行时数组** `Data.Array` | 游戏内存数据 | 任意函数体内 | 按 `varId` 存取的动态数组 | 背包标签、动态列表 |

还有第 4 个常被一起说的：**二维表 `Data.Table`**（行列结构，不是数组，见 13.5）。

一句话记：
> **属性数组给策划配，`arrayWrapper` 给触发器传，`Data.Array` 给运行时存。**

---

## 13.1 组件属性数组（Mini.Array）

### 完整结构

```lua
Script.propertys = {
    searchRangeGroup = {
        type = Mini.Array,              -- 必需
        itemType = Mini.String,         -- 必需：元素类型
        default = Mini.Array(Mini.String, "0-2000", "9995-17019", "20000-28000"),
        displayName = "搜索范围组",      -- 面板显示名
        customDisplayName = "范围",     -- 单个元素的显示名（可省）
        maxNum = 20,                    -- 最大容量（可省）
        sort = 4,                       -- 面板排序，数字越小越靠前
        tips = "每项填写ID范围",         -- 悬停提示
    },
}
```

**`itemType` 可选值**：`Mini.String` / `Mini.Number` / `Mini.Bool` / `Mini.Item` /
`Mini.Vec3` / `Mini.CustomData` …… 任何基础或资源类型。

### 读写方式（关键）

用 `self.xxx`（**不是** `Script.xxx`）：

```lua
function Script:OnStart()
    local arr = self.searchRangeGroup
    print("长度:", #arr)
    print("容量上限:", self.propertys.searchRangeGroup.maxNum)  -- 上限从 propertys 读

    for i = 1, #arr do
        print(i, arr[i])
    end

    arr[1] = "改后的值"          -- 改
    if #arr < self.propertys.searchRangeGroup.maxNum then
        arr[#arr + 1] = "新元素"  -- 增
    end
    arr[2] = nil                 -- 删（置 nil）
end
```

要点：
- 读数组长度 `#arr`；读**最大容量**要绕到 `self.propertys.<名>.maxNum`
- 数组属性就是普通 Lua 表，`#` / `[i]` / `table.insert` / `pairs` 都能用
- 增删改都要先判边界，超 `maxNum` 会被拒

### 嵌套结构（Mini.CustomData 数组）

数组里放自定义结构，用 `customDef` 描述字段：

```lua
weightPoolsData = {
    type = Mini.Array,
    itemType = Mini.CustomData,
    displayName = "权重池数据",
    customDisplayName = "权重池",
    customDef = {
        poolId = { type = Mini.String, displayName = "权重池ID" },
        keyValues = {
            type = Mini.Array,
            itemType = Mini.CustomData,
            displayName = "键值对列表",
            customDef = {
                key    = { type = Mini.String, displayName = "键名" },
                weight = { type = Mini.Number, displayName = "权重值", minValue = 0 },
            },
        },
    },
}
```

访问：`self.weightPoolsData[1].keyValues[2].weight`

### ⚠️ 实测坑（根因已定位）：属性要读 `self`，不是 `Script`

报错原文：
```
attempt to index field 'tableIds' (a nil value)
```

**根因**：`Script` 是**模板表**（写 `propertys` / 方法定义的地方），
组件**属性值实例化后写在组件实例 `self` 上**，不在 `Script` 上。
所以 `Script.tableIds` 是 nil，但 `self.tableIds` 有值 —— 官方文档一律用 `self.xxx` 访问属性。

**正确做法**：
1. 在 `Script:OnStart()` 第一行保存实例：`COMPONENT_SELF = self`
2. 取值函数优先读 `COMPONENT_SELF.xxx`
3. `self` 通常带元表指向 `Script`，所以读 `self` **同时覆盖**
   "属性在实例上"和"属性在模板上"两种情况，是最优解
4. 其他 `Script:` 方法（Chat / Diagnose 等）开头也 `bindSelf(self)` 一次，
   保证即使 `OnStart` 没跑也能绑上

```lua
local COMPONENT_SELF = nil
local function bindSelf(s) if s ~= nil then COMPONENT_SELF = s end end

function Script:OnStart()
    COMPONENT_SELF = self        -- 必须第一行
    ...
end

local function getIds()
    local self_ = COMPONENT_SELF
    if self_ ~= nil then
        local ok, arr = pcall(function() return self_.tableIds end)
        if ok and arr ~= nil then
            local t = unwrapArray(arr)   -- 可能是 userdata 包装
            if t and #t > 0 then return t end
        end
    end
    return DEFAULT_IDS             -- 兜底，永不返回 nil
end
```

**仍然保留三层兜底**（关键配置别只押在数组属性上）：
运行时覆盖 > 实例属性 > 模板属性 > 内置默认。

**验证方法（必须做，否则测不出来）**：
内置默认与实例属性设成**不同的 ID**，对比修复版与回退版。
若两版都命中说明验证无效（因为走默认也能成功）。
实测：内置默认换成假 ID 后，修复版命中、回退版兜底 —— 证明读 `self` 这一步必需。

### 数组属性可能是 userdata 包装

`Mini.Array` 构造出的对象常是 userdata / 带 `__index` 的代理，
`#arr` 可能取不到长度，但 `arr[1]`、`arr[2]` 能取到值。
`unwrapArray` 要覆盖三种形态：普通表 / `{values=...}` 包装 / userdata 逐个索引。

---

## 13.2 开放函数数组（arrayWrapper）

### 为什么需要包装

`openFnArgs` 的 `returnType` / `params` **不能直接写 `Mini.Array` 或 `Mini.Array(Mini.Number)`**，
引擎识别不了。必须用官方给的 `arrayWrapper` 包装函数。

### 包装函数（照抄，别简化）

```lua
local function arrayWrapper(propertytype)
    local arrayUserData = Mini.Array(propertytype)
    local newArray = {}
    local meta = {}
    local getcount = 0
    function meta.__index(_, key)
        if key == '__className_' then
            getcount = getcount + 1
            if getcount == 3 then
                -- 第 3 次查询才返回具体元素类型名
                if propertytype == Mini.String then return "String"
                elseif propertytype == Mini.Number then return "Number"
                elseif propertytype == Mini.Bool   then return "Bool"
                elseif propertytype == Mini.Item   then return "Item"
                else return "Unknown" end
            else
                return "Array"
            end
        else
            return arrayUserData[key]
        end
    end
    return setmetatable(newArray, meta)
end
```

**两个硬性要求**：
- `__className_` 的**计数逻辑必须完整保留**（前两次返回 `"Array"`，第 3 次才返回元素类型名）——
  这是引擎探测类型的方式，简化掉会导致类型识别失败
- `arrayWrapper` 的**定义必须写在 `openFnArgs` 之前**

### 用法

```lua
Script.openFnArgs = {
    getNumberArray = {
        returnType = arrayWrapper(Mini.Number),
        displayName = "获取数字数组",
        params = { "起始值", Mini.Number, "元素数量", Mini.Number },
    },
    processArray = {
        returnType = arrayWrapper(Mini.Number),
        displayName = "处理数组参数",
        params = { "输入数组", arrayWrapper(Mini.Number), "倍数", Mini.Number },
    },
}
```

### 函数体内就是普通 Lua 表

```lua
function Script:processArray(inputArray, multiplier)
    if not inputArray or type(multiplier) ~= "number" then return {} end
    local result = {}
    for i = 1, #inputArray do
        local v = tonumber(inputArray[i]) or 0
        result[#result + 1] = v * multiplier
    end
    return result
end
```

规范：**入参先判空判类型；返回值必须是表，空结果返回 `{}` 而不是 `nil`**。

### 常见元素类型对照

| propertytype | 第 3 次返回 |
|---|---|
| `Mini.String` | `"String"` |
| `Mini.Number` | `"Number"` |
| `Mini.Bool` | `"Bool"` |
| `Mini.Item` | `"Item"` |
| 其他 | `"Unknown"` |

---

## 13.3 运行时数组（Data.Array 模块）

这是**按 ID 存取的动态数组**，数据存在游戏里，跨函数、跨事件可访问。
每个数组由 `varId` + `playerId` 唯一标识。

### 核心概念

- **`varId`**：数组编号，**字符串**。格式就是 `v` + 一长串数字，例如
  `"v755795669086467993342623"`。**所有变量的 ID（数组、二维表等）都是这个 `v` + 数字串的格式，
  格式统一，不要按业务去猜格式差异。**
- **`playerId`**：玩家 ID。若 `varId` 传的是数组对象而非字符串 ID，则 `playerId` 应为 `nil`
- **索引从 1 开始**

### 26 个函数（按功能）

**创建与转换（4）**
| 函数 | 说明 |
|---|---|
| `CreateTmpArray(varType, data)` | 创建临时数组，`varType` 用 `VarType.StringGroup`/`NumberGroup`/`BoolGroup` |
| `ConvertNomalArray(array)` | 转成普通 Lua 表（**转换后失去 Data.Array 特性**） |
| `DealArrayData(data, itemType)` | 按 itemType 处理数据 |
| `DealTagToArrayData(tags, isToC, varType, outval)` | 标签串 ↔ 数组互转 |

**元素操作（4）**：`InsertValue(varId, playerId, value, index)`、
`InsertValues(varId1, pid1, index, varId2, pid2)`、`SetValue(varId, pid, value, index)`、
`GetValue(varId, pid, index)`

**删除（5）**：`Remove(varId, pid, index)`、`RemoveByValue(varId, pid, value)`、
`RemoveByValues(varId1, pid1, varId2, pid2)`、`Clear(varId, pid)`、
`ClearNilValue(varId, pid)`

**查询（6）**：`GetSize`、`GetAllValue`、`GetIndexByValue`、`HasValue`、
`HasValueByNo`、`GetCountByValue`

**数值（3）**：`GetMin`、`GetMax`、`IncreasesValue(varId, pid, value, index?)`
（不传 index 则所有值都加）

**排序与随机（2）**：`Sort(varId, pid, isUp)`、`RandomValue(varId, pid)`

**高级（2）**：`ReplaceValue(varId, pid, newValue, oldValue)`、
`HasIntersectionByTags(strsA, matchmode, strsB, bexactmatch)`

### 标准用法：临时数组 + 转普通表

```lua
-- 造一个临时字符串数组，塞值，再转成 Lua 表返回
local tmp = Data.Array:CreateTmpArray(VarType.StringGroup, {})
local n = Data.Array:GetSize(tmp)
Data.Array:InsertValue(tmp, nil, "苹果", n + 1)
Data.Array:InsertValue(tmp, nil, "香蕉", n + 2)
local tbl = Data.Array:ConvertNomalArray(tmp)   --> {"苹果","香蕉"}
```

注意：`CreateTmpArray` 返回的临时数组，`playerId` 传 `nil`。

### 标签串 ↔ 数组（很实用）

```lua
-- "weapon,rare,fire" -> 数组
local arr = Data.Array:DealTagToArrayData("weapon,rare,fire", true, VarType.StringGroup)
-- 数组 -> "armor,epic,ice"
local s = Data.Array:DealTagToArrayData({"armor","epic","ice"}, false, VarType.StringGroup)
```

### 判交集

```lua
local isWeapon = Data.Array:HasIntersectionByTags(
    {"weapon","sword","rare"}, "exact", {"weapon","sword","axe"}, true
)
```
`matchmode`：`"contains"` / `"startswith"` / `"endswith"` / `"exact"` 等。

### 注意事项

1. 索引从 1 开始
2. 数据类型要和数组类型匹配，不匹配可能被静默转换或报错
3. 不存在的索引可能返回 `nil` 或抛错 —— **取值前先 `GetSize` 或判空**
4. `ConvertNomalArray` 后就是普通表，不再有 Array 的方法
5. 批量操作优先用临时数组处理完再一次性写回

---

## 13.4 三套数组的选型

| 需求 | 用哪套 |
|---|---|
| 让策划/自己在编辑器面板里配一组初始值 | 组件属性数组 `Mini.Array` |
| 从触发器拿一组值 / 返回一组值给触发器 | 开放函数 `arrayWrapper` |
| 运行时动态增删、按玩家隔离、要持久化 | `Data.Array` |
| 行列结构（如模型分片、配置表） | 二维表 `Data.Table` |

---

## 13.5 变量 ID 格式（统一规则）

**所有变量的 ID 都是同一种格式：`v` + 数字串**，例如：

```
v755795669086467993342623     -- Data.Array 的 varId
v7692856137548737533110822    -- Data.Table 的 tableId
```

**不要按业务去猜格式差异，也不要校验前缀以外的结构。** 拿到什么就用什么，
长度可能不同，数字串本身无语义。

`Data.Table` 常用接口（与 Array 不冲突，按需取用）：
`Clear` / `InsertValue` / `InsertValueByRow` / `GetValue` / `GetAllValue` / `SetValue` /
`RemoveRow` / `GetValuesByCol` / `GetRows` / `GetCols` / `GetColIndex` / `GetRowIndex` /
`GetRowIndexs` / `GetTableColKeys`

`GetAllValue(tid, nil)` 返回行数组，每行是一列值的数组（如 `row[1]`、`row[2]`）。
**行有几列取决于导入方式**：单列导入 `row[1]` 就是内容；CSV 多列导入时
`row[1]` 可能是行号、`row[2]` 才是内容 —— 取值要做通用适配，别写死 `row[1]`。

---

## 13.6 自检清单

- [ ] 分清用的是三套里的哪一套，没混用
- [ ] 属性数组用 `self.xxx` 访问，容量上限从 `self.propertys.<名>.maxNum` 读
- [ ] 关键配置有兜底（字符串属性 / 内置默认 / 运行时覆盖），不因属性 nil 崩溃
- [ ] 开放函数数组用了 `arrayWrapper`，且 `__className_` 计数逻辑完整
- [ ] `arrayWrapper` 定义位置在 `openFnArgs` 之前
- [ ] 数组函数入参判空 + 判类型，空结果返回 `{}`
- [ ] `Data.Array` 用 `varId` 字符串 + `playerId`，临时数组 `playerId` 传 `nil`
- [ ] `Data.Array` 取值前判 `GetSize` / 判空，索引从 1 开始
- [ ] 变量 ID 直接照抄，不猜格式
