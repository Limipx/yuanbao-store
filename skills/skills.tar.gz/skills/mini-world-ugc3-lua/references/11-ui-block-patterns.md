# 11 · UI 批量绘图范式（元件/图片生成）

> 来源：创建元件.txt（官方元件创建范式）、图片生成器.lua / 图片生成器多线程.lua（大批量实战）
> 相关：`09-api-index.md` §A.3（CustomUI 66 个方法、ElementType 6 个枚举）

## 11.1 官方元件创建范式（照抄结构，别自创参数顺序）

```lua
-- 创建图片
self:CreateBlock(playerId, uiId, startpos, gamepos, measure, ElementType.Texture, picturetype, alpha, color, txt)
-- 创建按钮 / 文本：只换 ElementType.Button / ElementType.Text

function Script:CreateBlock(playerId, uiId, startpos, gamepos, measure, elementtype, picturetype, alpha, color, txt)
    return self:_CreateBlock(playerId, uiId, startpos, gamepos, measure, elementtype, picturetype, alpha, color, txt)
end

function Script:_CreateBlock(playerId, uiId, startpos, gamepos, measure, elementtype, picturetype, alpha, color, txt)
    local startX, startY = startpos.x, startpos.y
    local gameX, gameY   = gamepos.x,  gamepos.y
    local width, height  = measure.x,  measure.y

    local elementId = CustomUI:CreateElement(playerId, uiId, elementtype)
    if not elementId then return end
    CustomUI:SetTexture(playerId, uiId, elementId, picturetype)
    CustomUI:SetSize(playerId, uiId, elementId, width, height)
    if color then CustomUI:SetColor(playerId, uiId, elementId, color) end
    if txt or txt ~= "" then CustomUI:SetText(playerId, uiId, elementId, txt) end
    local tx = startX + gameX * width
    local ty = startY - gameY * height          -- 注意这里是减
    CustomUI:SetPosition(playerId, uiId, elementId, tx, ty)
    CustomUI:SetAlpha(playerId, uiId, elementId, alpha)
    return elementId
end

-- 子元件：创建后改挂到父元件下
function Script:CreateChildBlock(playerId, uiId, father, startpos, gamepos, measure, elementtype, picturetype, alpha, color, txt)
    local elementId = self:CreateBlock(playerId, uiId, startpos, gamepos, measure, elementtype, picturetype, alpha, color, txt)
    local isSuccess = CustomUI:ChangeParent(playerId, uiId, elementId, father)
    return isSuccess
end
```

**三组坐标的含义（容易混）**：

| 参数 | 含义 | 例 |
|---|---|---|
| `startpos` | 界面锚点（像素），整幅图的左上角 | `{x=50, y=60}` |
| `gamepos` | 格子坐标（第几列第几行，0-based） | `{x=3, y=7}` |
| `measure` | 单个元件的像素尺寸 | `{x=5, y=5}` |

实际像素坐标 = `tx = startX + gameX*width`，`ty = startY - gameY*height`。

**Y 轴方向**：官方写法是 `startY - gameY*height`（行号增大往上）。
画二维码/图片时如果按"行号增大往下"更符合直觉，两种都要试——
**判定标准是扫码器能不能扫出来**，不是代码漂不漂亮。建议做成可配置开关（如 `yDirection = "down"/"up"`）。

## 11.2 大批量创建必须让出主线程

```lua
local BATCH_SIZE = 50
local made = 0
for 每个元件 do
    CustomUI:CreateElement(...)  -- 及后续设置
    made = made + 1
    if made % BATCH_SIZE == 0 then
        threadpool:wait(0)       -- 让出主线程，防止卡死
    end
end
```

- `threadpool` 是**全局表**，运行时 dump 确认只有 4 个成员：`work` `wait` `Work` `Wait`
  （大小写两种写法）。**没有** `default` 成员——网上流传的 `threadpool.default` 是错的，取到 nil。
- `threadpool:wait(0)` 是图片生成器.lua 的实战写法，用它让出主线程。
- 组件内另有一套 `self:ThreadWork(fn)` / `self:ThreadWait(秒)`（见 `05`）。
  两者**不要混用**：`threadpool:wait` 是让出主线程；`ThreadWork` 是提交线程池任务。
  纯 Lua 计算用线程池无加速（GIL），只有 I/O / 休眠才有。
- **CustomUI 元件创建属于主线程操作**，放进 `threadpool.work` 的闭包里再 `coroutine.yield()`
  会直接报错——那个闭包不是协程。

## 11.3 消缝：尺寸 +2

```lua
CustomUI:SetSize(playerId, uiId, elementId, width + 2, height + 2)
```

相邻同色元件之间会出现 1px 缝隙，官方实战做法是给尺寸各加 2。
做属性开关（`gapFix`，默认 2）比写死更稳妥，遇到对像素精度敏感的图可以调 0。

## 11.4 数据组织：RLE 压缩

图片生成器.lua 用「颜色分组 → 行 → 行内游程」的三级结构：

```lua
local colorGroups = {
    [0xFFFFFF] = {                        -- 一级：颜色
        [0] = { {0,4}, {16,3}, {33,4} },  -- 二级：行号 -> 三级：{起始列, 长度} 或单点列号
        [1] = { {0,4}, 17, 35 },
    },
}
for color, yGroups in pairs(colorGroups) do
  for gameY, encodedArray in pairs(yGroups) do
    for _, item in ipairs(encodedArray) do
      if type(item) == 'number' then
        -- 单点
      else
        -- 连续段：item[1] 起始, item[2] 长度
        for offset = 0, item[2] - 1 do ... end
      end
    end
  end
end
```

要点：
- 先按颜色分组，能把 `SetColor` 的重复调用降到最少
- 行内游程编码（RLE）直接决定元件数量，比逐格创建少一个量级
- 生成二维码/程序化图形时，用同样的思路做**二维矩形合并**（先行内合并，再向下扩展同宽连续黑行），
  比纯行内 RLE 再省 30%+ 元件

## 11.5 原参考脚本里的坑（已确认，别再踩）

| 位置 | 问题 | 正确做法 |
|---|---|---|
| 图片生成器.lua `self.CreateCustomElement(0, player, ...)` | 用 `.` 调用却传了 10 个参数给 `:` 定义的 7 参函数，靠多塞的 `0` 歪打正着对齐 | 统一用 `:` 调用，参数严格按定义传 |
| 同上 `totalBlocks = totalBlocks + 100` | 计数放大 100 倍，且实际是每 5 个元件让出一次（与 BATCH_SIZE=500 的意图不符） | 计数按真实元件数 +1 |
| 同上 `local ty = startY` | 声明后没用（Y 被写死），行方向不可控 | 走 `startpos/gamepos` 范式，方向做成开关 |
| 图片生成器多线程.lua `threadpool.default` | dump 中不存在此成员，值为 nil | 用 `threadpool:wait(0)` |
| 同上 `BATCH_SIZE = 900000000` 配 `+1000` | 永远触发不了让出，等于从未让出主线程 | 设成有意义的阈值（50~500） |
| 同上 `threadpool.work` 闭包里 `coroutine.yield()` | 该闭包不是协程，调用会报错 | 让出用 `threadpool:wait(0)` |

## 11.6 自检清单

- [ ] 用 `startpos / gamepos / measure` 三段式，`tx/ty` 按官方公式算
- [ ] Y 轴方向以"扫得出来 / 看得对"为准，做成可配置
- [ ] 尺寸 +gapFix 消缝
- [ ] 大批量每 50~500 个 `threadpool:wait(0)` 让出一次
- [ ] 没有用 `threadpool.default`、没在 work 闭包里 `coroutine.yield()`
- [ ] 数据走 RLE / 矩形合并，元件数是关键性能指标
- [ ] 删除时逐个 `DeleteElement` 保底，不赌引擎的级联删除
