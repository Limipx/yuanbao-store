# 01 · 组件脚本规范

> 来源：脚本规范.txt（官方组件标准格式）、1.53.1数组实现.txt

## 1.1 骨架（3.0 模组脚本硬要求）

```lua
local Script = {}          -- 表默认名 Script，也可叫 A / b / MyFolder，随意

Script.Enum1 = Mini.Enum({
    ADD    = { value = 1, displayName = "添加标记" },
    REMOVE = { value = 2, displayName = "移除标记" },
    CHECK  = { value = 3, displayName = "检查标记" },
    CLEAR  = { value = 4, displayName = "清空列表" },
})

Script.propertys = { ... }    -- 自定义属性

Script.openFnArgs = { ... }   -- 开放函数（积木触发器可用）

function Script:OnStart()
    -- 初始化 + 事件注册，组件加载时执行
end

return Script                -- 必须有
```

**硬约束**：
- 3.0 模组脚本**必须封装为一个表**，结尾 `return Script`
- 自定义表中**不能有非函数字段**——数据初始化必须在 `OnStart()` 中执行
  （`Script.Enum1` / `propertys` / `openFnArgs` 是框架约定的配置字段，不在此列）
- 每个函数结束时的"后缀返回"就是文件末尾的 `return Script`

## 1.2 propertys · 自定义属性

```lua
Script.propertys = {
    name1 = {
        type = Mini.Number,        -- 属性类型
        default = 1.0,             -- 默认值
        displayName = "数值属性名称",
        -- minValue = 0.1,         -- 最小值
        -- maxValue = 5.0,         -- 最大值
        -- stride = 1,             -- 跨度
        -- format = "%.1f米",      -- 精度+单位
        -- style = ComponentUIStyle.NumberSlider,  -- 面板风格
        -- sort = 1,               -- 主属性顺序
        -- tips = "属性描述"
    },
    name2 = {
        type = Mini.String,
        default = "默认值",
        displayName = "字符串属性名称",
        -- maxLength = 64,
        -- multiLine = false,
        -- sort = 2,
        -- tips = "属性描述"
    },
    name3 = {
        type = Mini.Bool,
        default = false,
        displayName = "布尔属性名称",
        -- sort = 2,
        -- children = { "name4", "name2" },  -- 布尔为真时显示的子属性
    },
    name4 = {
        type = Script.Enum1,                 -- 枚举属性
        default = Script.Enum1.ADD,
        displayName = "枚举属性名称",
        -- style = ComponentUIStyle.EnumController
        -- sort = 1,
    },
    name5 = {
        type = Mini.Array,
        itemType = Mini.Item,                -- 数组元素类型（如道具）
        displayName = "道具组属性名称",
        customDisplayName = "单个属性名称",
        -- maxNum = 99,                      -- 数组最大容量
        -- sort = 3,
        -- tips = "初始拥有的物品列表"
    },
}
```

要点：
- `Mini.Array` 属性必须带 `itemType`；`customDisplayName` 是数组内单个元素的显示名
- `children` 只有 `Mini.Bool = true` 时才展开显示
- `sort` 分主属性/子属性两套顺序

## 1.3 openFnArgs · 开放函数

```lua
Script.openFnArgs = {
    f1 = {
        returnType = Mini.Number,   -- 不填 = 无返回值
        displayName = "函数别名",   -- 积木块上显示的名字，不填缺省显示函数名
        params = {
            "参数描述1", Mini.Number,
            "参数描述2", Mini.Vec3,
            "参数描述3", Script.Enum1,
            "参数描述4", Mini.Array(Mini.String),
        },                          -- 不填 = 无参数
    },
}
```

**两种写法**：
- 完整写法：上面这种（要支持触发器时必须这么写，带描述文本）
- 简写：`Add = true` —— 只想让**其他脚本组件**访问、不需要触发器支持时用

## 1.4 函数实现

```lua
function Script:f1(a, event, b, c)
    -- 复杂结构参数（如位置）取字段
    local X, Y, Z = event.x, event.y, event.z

    -- 引用自定义属性
    local A = self.name1

    -- 引用本组件其他函数
    local B = self:f2()

    -- 枚举 / 普通参数直接用
    if b.value == 1 then
    elseif b == "ADD" then
    elseif a == 1 then
    end

    -- 数组参数当数组用
    local ListNum = #c
    local C = c[1]

    -- return A   -- 开放函数返回值
end

-- 自定义函数（不开放，不写进 openFnArgs）
local function f2(a, b)
    return a
end
```

**注意**：调用本组件的函数**不需要任何 openFnArgs 配置**；
只有"别的组件调用"或"触发器调用"才需要配置。

## 1.5 完整示例（带数组）

见用户提供的 `1.53.1数组实现.txt`：含 `Mini.Enum` 定义、4 个返回数组的开放函数、
`arrayWrapper` 包装、自定义函数、事件回调里测试数组。

## 1.6 自检清单

- [ ] `return Script` 存在
- [ ] 有 `OnStart`，数据初始化都在里面
- [ ] `propertys` 的 `Mini.Array` 带 `itemType`
- [ ] `openFnArgs` 的 `params` 是"描述字符串, 类型"成对出现，不是奇数个
- [ ] `displayName` 用了中文引号会出事——检查中文标点：`“ ” ‘ ’ ， ； （ ）`
- [ ] 开放函数返回数组时用了 `arrayWrapper`（见 06）
