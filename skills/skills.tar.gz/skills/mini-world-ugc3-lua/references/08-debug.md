# 08 · 调试与打印

> 来源：打印指定函数接口.lua（官方）+ 引擎调试实践

## 8.1 打印模块的函数清单

在运行时不确定某个全局模块有哪些函数时，直接遍历打印：

```lua
local Script = {}

function Script:PrintFunc(targetModule, name)
    print("==========" .. name .. "==========")
    local index = 1
    for funcName, func in pairs(targetModule) do
        if type(func) == "function" then
            print(string.format("函数名：%d. %s", index, funcName))
            index = index + 1
        end
    end
end

function Script:OnStart()
    self:PrintFunc(World, "World")
end

return Script
```

要点：
- `pairs` 遍历 + `type(func) == "function"` 过滤
- Lua 5.1 下 `string.format` 可用，`%d` `%s`
- 模块传的是**表本身**（`World`），不是字符串
- 想看别的模块就把 `World` 换成 `Block` / `Actor` / `GameObject` 等

## 8.2 打印规范

| 场景 | 写法 |
|---|---|
| 多值 | `print("结果", a, b, c)` —— print 支持多参数，比拼接快 |
| 表内容 | 数组用 `table.concat(t, ", ")`；非数组要自写遍历 |
| 调试开关 | 加一个 `local DEBUG = true`，`if DEBUG then print(...) end` |
| 错误 | `print("执行出错:", err)` |

```lua
-- 数组快速打印
print("生成的数字数组: " .. table.concat(numberArray, ", "))
```

## 8.3 定位问题三步

1. **先确认有没有进来**：函数第一行 `print("enter xxx")`
2. **再确认参数对不对**：`print(type(a), tostring(a))`
3. **最后确认分支**：每个分支打不同标记

## 8.4 高频排查点

| 症状 | 先查什么 |
|---|---|
| 组件取不到（nil） | 组件 id 是不是从编辑器 ID 库插入的（见 04） |
| 事件不触发 | 监听是不是注册在 `OnStart`；过滤参数是否匹配 |
| 广播收不到 | eventId 是否对上；成员回调 4 参 vs 匿名回调 5 参（见 03） |
| 数组返回报错 | `returnType` 是否用了 `arrayWrapper`（见 06） |
| 报语法错 | 是否用了 Lua 5.2+ 语法（见 07） |
| 卡帧 | 是否用 ThreadWork 做纯 Lua 计算（见 05） |

## 8.5 自检清单

- [ ] 关键路径有 print 打点
- [ ] 数组用 `table.concat` 打印，不是直接 `print(t)`
- [ ] 上线前把调试 print 关掉或降到最低（云服尤其）
- [ ] 不确定 API 时先用 `PrintFunc` 探一遍，别猜
