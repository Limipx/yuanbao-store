# 06 · 数组与类型系统

> 来源：1.53.1数组实现.txt（官方）+ UGCLua.txt 提取的 Mini 51 个类型子表

## 6.1 Mini 类型

`Mini.Number` / `Mini.String` / `Mini.Bool` / `Mini.Item` / `Mini.Vec3` / `Mini.Array`
共 51 个类型子表，完整清单见 `09-api-index.md` 附录 B.5。

## 6.2 数组属性

```lua
TestComponent.propertys = {
    testArray = {
        type = Mini.Array,
        itemType = Mini.Number,          -- 元素类型
        displayName = "测试数字数组",
        customDisplayName = "数字元素",
        -- maxNum = 99,                  -- 数组最大容量
        -- sort = 3,
        -- tips = "初始拥有的物品列表"
    },
}
```

道具数组：`itemType = Mini.Item`。

## 6.3 数组作为开放函数的返回类型（高频坑）

**不能直接写 `returnType = Mini.Array(Mini.Number)`**，需要用包装函数：

```lua
local function arrayWrapper(propertytype)
    local arrayUserData = Mini.Array(propertytype)
    local newArray = {}
    local meta = {}
    local getcount = 0

    function meta.__index(_, key)
        if key == '__className_' then
            getcount = getcount + 1
            if getcount == 3 then
                -- 第 3 次查询返回具体元素类型名
                if propertytype == Mini.String then return "String"
                elseif propertytype == Mini.Number then return "Number"
                elseif propertytype == Mini.Bool   then return "Bool"
                elseif propertytype == Mini.Item   then return "Item"
                else return "Unknown" end
            else
                return "Array"
            end
        else
            return arrayUserData[key]
        end
    end

    return setmetatable(newArray, meta)
end
```

用法：

```lua
TestComponent.openFnArgs = {
    getNumberArray = {
        returnType = arrayWrapper(Mini.Number),
        displayName = "获取数字数组",
        params = { "起始值", Mini.Number, "元素数量", Mini.Number },
    },
    processArray = {
        returnType = arrayWrapper(Mini.Number),
        displayName = "处理数组参数",
        params = { "输入数组", arrayWrapper(Mini.Number), "倍数", Mini.Number },
    },
}
```

要点：
- `__className_` 前两次返回 `"Array"`，**第 3 次才返回元素类型名** —— 这个计数逻辑是必需的，别简化掉
- 数组参数同样用 `arrayWrapper(...)` 包一层
- 数组在函数体内就是普通 Lua 表，`#arr` / `arr[1]` / `table.insert` 都能用

## 6.4 数组操作范式

```lua
function TestComponent:processArray(inputArray, multiplier)
    if not inputArray or not multiplier or type(multiplier) ~= "number" then
        return {}
    end
    local result = {}
    for i = 1, #inputArray do
        local value = inputArray[i]
        if type(value) == "number" then
            result[#result + 1] = value * multiplier
        else
            local numValue = tonumber(value)
            result[#result + 1] = numValue and (numValue * multiplier) or 0
        end
    end
    return result
end
```

规范：
- 入参先判空 + 判类型，非法直接返回 `{}`
- **返回值必须是表**，即使为空也返回 `{}` 而不是 `nil`
- Lua 5.1 下 `table.insert(result, v)` 可用，但 `result[#result+1] = v` 更快

## 6.5 Mini.Enum 自定义枚举

```lua
TestComponent.TestEnum = Mini.Enum({
    ITEM_ARRAY   = {value = 1, displayName = "道具数组"},
    NUMBER_ARRAY = {value = 2, displayName = "数字数组"},
    STRING_ARRAY = {value = 3, displayName = "字符串数组"},
})
```

作为属性类型：`type = Script.Enum1`
作为默认值：`default = Script.Enum1.ADD`
**枚举值有两种形态，判断方式不同（高频坑）**：

| 来源 | 类型 | 判断方式 |
|---|---|---|
| 组件属性读出来 `self.enumProp` | **数值**（number） | `if self.enumProp == 1 then` |
| 开放函数参数传入的枚举 | table（有 `.value`） | `if param.value == Enum.X.value then` |

```lua
-- 组件属性：直接比数值，不要写 .value
print(type(self.optionType))    --> number
if self.optionType == 1 then    -- 正确
-- if self.optionType.value == 1 then  -- 错误！属性里没有 .value

-- 开放函数参数：用 .value（见 1.53.1数组实现.txt）
if arrayType.value == TestComponent.TestEnum.NUMBER_ARRAY.value then
```

需要显示名称时，从枚举定义里反查：

```lua
local function enumDisplayName(enumDef, value)
    for _, d in pairs(enumDef) do
        if type(d) == "table" and d.value == value then return d.displayName end
    end
    return "未知"
end
```

## 6.6 自检清单

- [ ] 数组返回/参数类型用了 `arrayWrapper(...)` 包装
- [ ] `arrayWrapper` 的 `__className_` 计数逻辑完整保留
- [ ] 数组函数入参判空 + 判类型
- [ ] 空结果返回 `{}` 不是 `nil`
- [ ] 枚举比较用 `.value`，不直接比枚举表
