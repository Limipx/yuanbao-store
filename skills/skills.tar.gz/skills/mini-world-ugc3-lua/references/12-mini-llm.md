# 迷你中文对话模型（检索式）实现要点

产物：`/data/workspace/迷你中文对话模型.lua` + 数据包 `迷你对话模型_数据包.zip`

## 架构
不是生成式大模型，是**检索式对话**：25 万条真实中文问答存二维表，
回答时用「字符 bigram + 单字 IDF 加权余弦」找最像的问句，返回它的答案。

## 数据流水线
1. 语料：小黄鸡 45 万对话（candlewill/Dialog_Corpus）+ 白鹭问答 + chatterbot
2. 清洗：丢弃无信息量答案（"说啥"/"听不清"/"嗯……"这类真实但没内容的回复，
   又短又通用，打分时极易冒到第一，必须整条剔除）
3. 归并：按问句聚合，每句留质量最高的 3 条答案，打包成 `a1\3a2\3a3`
4. 种子：手写 353 组高频寒暄，af=9999 置顶，单独放桶 255，查询时**必扫**
5. 分桶：Q 中 IDF 最高的字的 hash → 256 桶
6. 压缩：zlib(level 9) + Base85（Base85 而非 Base64：字符集 0x21-0x75 全可打印）
7. 装箱：桶不跨表，每表 ≤2000 行、≤460KB（512KB 留余量）

## 关键坑
- **分片必须带自描述表头** `LLM1|tid|行数`，Lua 侧自动识别偏移。
  没有表头时 loadBucket 会整体错位，b85Decode 返回 nil，现象是所有查询都兜底、耗时 0ms
- **纯 Lua inflate 速度**：27KB → 40ms（约 1.7MB/s）。一次对话解压 5-6 个桶约 200ms，可接受
- **测试 stub 构造**：lupa 里 `lua.table_from([[s]])` 转过来 row[1] 类型是 userdata 不是 string。
  必须用 `fillDB(tid, ...)` 在 Lua 侧包一层 `{...}` → `{{v}}`
- **NO_HAN 拒答**：整句无汉字（纯数字/字母/符号）时 sc<0.9 一律置 0，
  否则 "123456" 会撞上语料里的脏句子
- **得分门槛**：minScore=0.16 + minCoverage=0.25（查询字在命中问句里的覆盖率）。
  只有 Score 没有 Coverage 时，长句会因为偶然撞上几个字而误命中
- **hedge 不能套在兜底文案上**：会出现"我不太确定，不过——我没理解你的意思"这种自我矛盾输出

## 参数（组件属性）
tableIds / topBuckets(6) / minScore(0.16) / minCoverage(0.25) / contextTurns(2)
enableContext / replyMaxLen(60) / fallbackMode / enableHedge / hedgeScore(0.35)
preloadBuckets / debugMode

## 实测
- 质量：109 条真实输入 107 命中（98.2%，2 条为评判关键词过窄，实际合格）
- 垃圾输入 18 条全部兜底，0 条带出脏答案
- 上下文接话 6/6（"我饿了"→"那吃什么好"能接住）
- 热缓存 44ms/次，冷启动首轮 219ms

## 二维表 CSV 导入格式（重要，踩过坑）

迷你世界二维表导出的 CSV **是标准横向 CSV，不是纵向的**。文档渲染时把逗号换行了，
直接看会误判成"一行一个字段"。必须先用 `csv.reader` 解析参考文件确认结构。

真实结构（UTF-8 无 BOM，LF 换行，**每行 3 列、末列为空**，即行尾有一个逗号）：
```
字段备注,建筑数据,
字段名,建筑数据,
字段类型,string,
1,"<第1行内容>",
2,"<第2行内容>",
```
- 前 3 行是 schema：列1=标签名，列2=值（字段名=建筑数据，类型=string）
- 之后是数据行：列1=行号，列2=内容，列3=空
- 内容单元格必须双引号包裹，内部 `"` 转义为 `""`
  （Base85 字符集 0x21-0x75 含 `"` 0x22 和 `,` 0x2C，不转义必坏）

写脚本生成时用 `csv` 模块或手动 `'"' + s.replace('"','""') + '"'`，
再用 `csv.reader` 反解校验往返一致 —— 这一步不能省。

导入后 `Data.Table:GetAllValue(tid, nil)` 返回行数组，每行 `row[1]` 是字符串，
**没有系统自动加的表头**，第 1 行就是 CSV 数据区的第 1 行。

## 迷你环境前提（已确认，不要写冗余降级）

- **`bit` 模块一定存在**，直接用 `bit.band/bor/bxor/bnot/lshift/rshift`。
  不要再写 `rawget(_G,"bit")` 判断 + 纯算术兜底两套实现。
- **`os` 只有 `date` / `time` / `timeMs`，其中 `timeMs` 返回毫秒**。
  计时直接 `os.timeMs()`；`os.clock` 不存在，**用了必崩**
  （报 `attempt to call field 'clock' (a nil value)`）。
- Lua 5.1 **没有位运算符**。`x ~ y` 会编译失败，报 `')' expected near '~'`。
  必须用 `bit.bxor(x, y)`。

对照参考实现（哈夫曼_不可打印.lua / MD5生成器.lua）的写法：
```lua
local bit = bit
local band, bor, bxor, bnot = bit.band, bit.bor, bit.bxor, bit.bnot
local lshift, rshift, rol, tobit = bit.lshift, bit.rshift, bit.rol, bit.tobit
```

## 开放函数必须永不返回 nil

引擎里开放函数一旦抛错，调用方拿到的就是 nil（日志里表现为"标红 nil"）。
所以对外入口一律 pcall 包壳，内部逻辑单独放 Impl：

```lua
function Script:ChatImpl(...) return ... end
function Script:Chat(...)
    local ok, res = pcall(Script.ChatImpl, self, ...)
    if not ok or type(res) ~= "string" or res == "" then return "兜底文案" end
    return res
end
```

**测试方法**：不能只用完整 Lua 环境测（os.clock 在那里存在、bit 也可能存在）。
必须注入迷你的 os 表（无 clock）+ bit 模块再跑一遍；
再跑"错误注入"：手动把内部状态置 nil（如 `BUCKETS = nil`），
确认 Chat 仍返回字符串而不是 nil。

## 开放函数必须永不返回 nil

引擎里开放函数一旦抛错，调用方拿到的就是 nil（日志里表现为"标红 nil"）。
所以对外入口一律 pcall 包壳，内部逻辑单独放 Impl：

```lua
function Script:ChatImpl(...)   -- 真正的逻辑
    ...
end
function Script:Chat(...)       -- 对外壳
    local ok, res = pcall(Script.ChatImpl, self, ...)
    if not ok or type(res) ~= "string" or res == "" then
        return "兜底文案"
    end
    return res
end
```

**测试方法**：不能只用完整 Lua 环境测（os.clock 在那里是存在的，测不出问题）。
必须注入迷你世界的 os 表再跑一遍：
```python
lua.execute("os = { date=..., time=..., timeMs=... }")   # 没有 clock
```
另外要跑"错误注入"：手动把内部状态置 nil（如 `BUCKETS = nil`、`Script = nil`），
确认 Chat 仍然返回字符串而不是 nil。

## 随机数
不依赖 `math.randomseed(os.time())`。自建 xorshift32，避免环境差异。

## 二维表行结构：不要只取 row[1]（实测踩坑，会全兜底）

真实二维表导入后**每行是多列**。我们 CSV 是 `(行号, 内容, 空)`，
所以 `row[1]` 是行号 `"1"`，`row[2]` 才是内容。只取 `row[1]` 会拿到一堆
行号去 Base85 解码 → inflate 失败 → 所有桶加载失败 → **每句话都走兜底**，
日志上看起来就是"二维表没加载"。

（建筑文件生成器用 `row[1]` 是对的，因为它写入时是单列表，
而我们从 CSV 导入的是多列表——两者结构不同，不要照抄。）

通用取值：
```lua
local function pickField(row)
    local n = #row
    if n == 1 then return row[1] end
    local best, bestLen = nil, -1
    for i = 1, n do
        local v = row[i]
        if type(v) == "string" then
            local isNum = string.match(v, "^%s*%-?%d+%s*$") and #v <= 12
            if not isNum and #v > bestLen then best, bestLen = v, #v end
        end
    end
    return best or row[1]
end
```

**测试教训**：stub 必须按真实结构造（多列），
只造单列 `{内容}` 会让这个 bug 100% 测不出来。两种结构都要跑。

**给用户的诊断入口**：`ProbeTable(tableId)` 输出 行数/列数/第1行各列预览/取值结果，
一眼就能看出哪一列才是数据。

## 诊断体系（用户看不到内部状态时的唯一抓手）

迷你世界里 print 进日志是唯一调试手段，所以模型脚本内置三层诊断，
**不依赖 debugMode 也会自动跑**，保证用户截图就能定位：

1. **OnStart 启动自检**：表可读数、行数是否够、抽样 3 个桶
2. **Chat 首次扫到 0 条**：自动跑一次快检（只跑一次，不刷屏）
3. **手动开放函数**：`Diagnose`(全量) / `QuickCheck`(快) / `DiagBucket(桶号)` /
   `FailedBuckets` / `ProbeTable(表ID)`

关键诊断点：**期望数据行数 vs 实际行数比对**。
manifest 里每表的最大结束行就是期望行数，实测值来自 `readTable`。
行数不足 = 导入被截断或数据版本不对。

四种典型故障的输出特征（实测）：
| 故障 | 输出 |
|---|---|
| 表 ID 错 | `【读不到】期望1820行` + `读表失败 id=xxx` |
| 行数截断 | `【行数不足】14 个表数据被截断: 表[1] 只有1091行/期望1820` |
| 取列错 | `首行: [1]1 [2]LLM1|1|1820 [3]  取值=1` ← 取值成了行号 |
| inflate 失败 | `inflate返回空(取到185字符, 首20=12345678910111213141)` ← 全是行号拼接 |

**测试教训**：诊断必须按"故障场景"跑，不能只跑正常路径。
用 stub 模拟 ID错 / 截断 / 行号列 / 正常 四种，确认每种都能输出可读的原因。

## 组件属性 Mini.Array 可能为 nil（实测报错）

报错原文：`attempt to index field 'tableIds' (a nil value)`
（Lua 5.1 里 `Script.tableIds[i]` 且 tableIds 为 nil 就是这个措辞）

原因：`type = Mini.Array` 的属性在部分版本里**不会写进 Script**，
`Script.tableIds` 就是 nil，一索引就抛，整个对话链崩。

**对策：不要把关键配置押在数组属性上。**
改用 `Mini.String`（一定支持）存逗号分隔的 ID，并在脚本里内置一份默认 ID 兜底：

```lua
local DEFAULT_IDS = {"llm_data_1", ..., "llm_data_14"}
local function getIds()
    local raw = rawget(Script, "tableIdsText")
    if type(raw) == "string" and raw ~= "" then
        local t = splitIds(raw)          -- 支持中英文逗号/分号/空格
        if #t > 0 then return t end
    end
    local t = unwrapArray(rawget(Script, "tableIds"))  -- 兼容包装对象
    if t and #t > 0 then return t end
    return DEFAULT_IDS                    -- 兜底，保证一定能跑
end
```

再加开放函数 `SetTableIds("id1,id2,...")`，运行时覆盖，排障时不用改属性面板。

**优先级**：运行时覆盖 > 字符串属性 > 数组属性 > 内置默认。
无论走哪条都返回可用数组，绝不返回 nil。
`OnStart` 打印 `【启动】二维表ID来源=xxx 共N个`，一眼看出走的哪一路。
