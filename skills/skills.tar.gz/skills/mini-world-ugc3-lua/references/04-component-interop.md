# 04 · 组件互调（开放函数与跨对象访问）

> 来源：组件调用知识.lua（官方）

## 4.1 开放函数配置 openFnArgs

```lua
Script.openFnArgs = {
    Add = {
        returnType = Mini.Number,                        -- 返回值类型（不填 = 无返回值）
        displayName = "函数别名",                         -- 触发器别名（不填 = 显示函数名 Add）
        params = {Mini.Number, Mini.Number},             -- 参数类型列表（不填 = 无参数）
    },
}
```

**简写**：只想给其他脚本组件访问、不需要触发器访问时：

```lua
Script.openFnArgs = {
    Add = true,
}
```

带参数描述（触发器里显示更友好）的写法：

```lua
Script.openFnArgs = {
    f1 = {
        returnType = Mini.Number,
        displayName = "函数别名",
        params = {
            "参数描述1", Mini.Number,
            "参数描述2", Mini.Vec3,
            "参数描述3", Script.Enum1,
            "参数描述4", Mini.Array(Mini.String),
        },
    },
}
```

规则：
- 调用**本组件自己**的函数**不需要任何配置**，直接 `self:Add(1, 2)`
- 需要被**其他组件**或**触发器**访问才配 `openFnArgs`

## 4.2 同对象下访问

```lua
function Script:OnStart()
    local cmpA = self:GetComponent("组件id")   -- 组件id 从编辑器【ID库】→【组件】插入
    local result = cmpA:Add(1, 2)
end
```

## 4.3 跨对象访问

```lua
local obj   = GameObject:FindObject("对象id")   -- 一般对象
local world = GetWorld()                        -- 世界对象
local cmpA  = world:GetComponent("组件id")

if cmpA then
    local result = cmpA:Add(1, 2)
    local age    = cmpA.age      -- 读属性
    cmpA.age     = 123           -- 写属性（官方和开发者写法一样）
end
```

## 4.4 高频坑（重点）

> **组件 id 和对象 id 必须从编辑器顶部【ID库】插入，不能手写字符串。**
> 手写 `"组件id"` / `"对象id"` 是最常见的运行时取不到组件的原因。

其他注意：
- 跨组件调用前**必须判空**（`if cmpA then`），对象销毁后组件会失效
- `GetWorld()` 是全局函数；`GameObject:FindObject` 用冒号
- 读属性用 `cmpA.age`，写属性用 `cmpA.age = 123`，**不是** `cmpA:setAge()`
- 组件 id 是编辑器生成的，**不要在代码里拼接或硬编码**

## 4.5 自检清单

- [ ] 被外部访问的函数都配了 `openFnArgs`（或 `= true` 简写）
- [ ] 组件 id / 对象 id 来自编辑器 ID 库，不是手写
- [ ] 跨组件调用前判空
- [ ] `GameObject:FindObject` 用冒号，`GetWorld()` 是全局函数
- [ ] 属性读写用点号，不用 setter
