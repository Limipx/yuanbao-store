# 05 · 协程与线程

> 来源：协程线程知识2.txt（官方，含云服实测数据）

## 5.1 选型原则

| 场景 | 用谁 | 实测依据 |
|---|---|---|
| 高频、轻量、协作式 | **协程 coroutine** | 10 万次切换 13.00 ms，单次 0.13 μs，约 769 万次/秒 |
| 低频、重量、阻塞（I/O、休眠） | **ThreadWork** | 10 次休眠串行 1078 ms → 并行 302 ms，加速 3.5x |
| **纯 Lua 计算密集型** | **协程分片，绝不用线程池** | 200 个计算任务：串行 8 ms，ThreadWork 8 ms，**加速比 1.00x** |

核心原因：Lua 虚拟机有全局锁（GIL），同一时刻只有一个线程执行 Lua 字节码。
纯 Lua 计算无法真正并行；但**阻塞操作**（休眠、I/O、文件加载）时线程池能释放主线程。

## 5.2 coroutine 函数

| 函数 | 作用 | 返回 |
|---|---|---|
| `coroutine.create(func)` | 创建协程 | 协程对象 |
| `coroutine.wrap(func)` | 创建并包装 | 可直接调用的函数 |
| `coroutine.resume(co, ...)` | 启动/恢复 | `ok, ...` |
| `coroutine.yield(...)` | 挂起 | resume 传入的参数 |
| `coroutine.status(co)` | 状态 | `running`/`suspended`/`dead`/`normal` |
| `coroutine.running()` | 当前协程 | `co, isMain` |
| `coroutine.isyieldable()` | 能否挂起 | bool |

## 5.3 安全恢复模式

```lua
local function safe_resume(co, ...)
    if coroutine.status(co) == "dead" then
        return false, "协程已结束"
    end
    return coroutine.resume(co, ...)
end
```

协程执行完变 `dead`，**无法再次恢复**；内部错误通过 `resume` 的返回值带出，必须检查。

## 5.4 生成器模式

```lua
local function number_generator(max)
    return coroutine.wrap(function()
        for i = 1, max do
            coroutine.yield(i)
        end
    end)
end

local gen = number_generator(3)
print(gen())  -- 1
print(gen())  -- 2
print(gen())  -- 3
```

## 5.5 ThreadWork 用法

```lua
-- 提交任务
self:ThreadWork(function()
    -- 任务体
end)

-- 轮询等待（配合计数器）
local finishedCount = 0
local totalTasks = 200
for i = 1, totalTasks do
    self:ThreadWork(function()
        -- ...
        finishedCount = finishedCount + 1
    end)
end
while finishedCount < totalTasks do
    self:ThreadWait(0.01)     -- 轮询等待，不要空转
end
```

`ThreadWait(time)`：等待线程池任务完成或休眠，单位秒。

## 5.6 注意事项

1. 线程池有大小限制，别堆积任务
2. 任务间数据要隔离，避免竞态
3. 任务内异常要 `pcall` 兜住
4. 长任务设超时
5. 等待用 `ThreadWait(0.01)` + 回调计数器轮询
6. **编辑器规范**：自定义表中不能有非函数字段，初始化数据必须在 `OnStart` 里执行
7. Lua 双引号字符串**不支持跨行**，跨行用 `[[]]` 长括号

## 5.7 自检清单

- [ ] 纯 Lua 密集计算用了协程分片，没用 ThreadWork
- [ ] `coroutine.resume` 的返回值有检查
- [ ] 协程 dead 后不再 resume
- [ ] ThreadWork 任务里没写共享状态自增之外的竞态操作
- [ ] 等待用 ThreadWait(0.01) 轮询，不是死循环空转
