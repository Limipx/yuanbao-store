# 03 · 广播消息（房间广播 / 云服广播）

> 来源：广播知识.txt（官方）

## 3.1 四组 API

| 动作 | 房间广播 | 云服广播 |
|---|---|---|
| 添加监听 | `self:AddCustomEvent(eventId, handler)` | `self:AddCloudSeverEvent(...)` |
| 移除监听 | `self:RemoveCustomEvent(eventId)` | `self:RemoveCloudSeverEvent(...)` |
| 发送 | `self:PushCustomEvent(eventId, p1, p2, p3)` | `self:PushCloudServerMsg(...)` |

**参数上限 3 个**（`param1, param2, param3`）。

## 3.2 完整示例

```lua
local Script = {}

function Script:OnStart()
    -- 写法一：传成员函数
    self:AddCustomEvent("消息id", self.OnCustomEvent)

    -- 写法二：传匿名闭包（注意 Lua 5.1，别在闭包里用 5.2+ 语法）
    self:AddCustomEvent("消息id", function(cmp, eventId, param1, param2, param3)
        print("收到自定义消息", eventId, param1, param2, param3)
    end)
end

function Script:OnCustomEvent(eventId, param1, param2, param3)
    -- 假如发送时发了 3 个参数 1、2、3
    -- 则 param1, param2, param3 分别为 1, 2, 3
    print("收到自定义消息", eventId, param1, param2, param3)
end

return Script
```

要点：
- 匿名回调的第一个参数是 **cmp（组件自身）**，之后才是 `eventId, param1, param2, param3`
- 成员回调的签名是 `OnCustomEvent(eventId, param1, param2, param3)` —— **没有 cmp**
- 两种写法的参数位置不同，很容易写错。用成员函数写法时别多接一个 cmp

## 3.3 eventId 从哪来

自定义消息 id 若使用**触发器的广播 id**，则触发器发送的消息会触发该回调。
即：编辑器里配的广播 id 与脚本里 `AddCustomEvent("消息id", ...)` 的字符串要对上。

## 3.4 发送

```lua
self:PushCustomEvent(eventId, param1, param2, param3)   -- 房间广播
-- self:PushCloudServerMsg(...)                          -- 云服广播
```

## 3.5 自检清单

- [ ] 监听写在 `OnStart`，移除写在 `OnDestroy`
- [ ] 成员回调 4 参 / 匿名回调 5 参，别接错
- [ ] 超过 3 个参数要打包成表或拆成多次发送
- [ ] 房间广播与云服广播别混用
