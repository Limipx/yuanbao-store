# 02 · 事件系统

> 来源：事件知识.txt（官方）+ UGCLua.txt 运行时 dump 提取的枚举

## 2.1 两大体系

| 体系 | 注册函数 | 监听对象 | 事件常量 |
|---|---|---|---|
| 触发器事件 | `self:AddTriggerEvent(TriggerEvent.X, handler, filterParam)` | 游戏内交互行为 | `TriggerEvent.*`（256 个） |
| 组件/对象事件 | `self:AddEvent(ObjectEvent.X, handler)` | 组件或对象自身状态变化 | `ObjectEvent.*`（183 个） |

```lua
function Script:OnStart()
    -- 触发器事件：监听玩家点击方块
    self:AddTriggerEvent(TriggerEvent.PlayerClickBlock, self.OnPlayerClickBlock)
    -- 组件事件：监听对象死亡
    self:AddEvent(ObjectEvent.ObjectDie, self.OnObjectDie)
end
```

**注册位置**：所有事件监听必须在 `OnStart()` 中注册。

## 2.2 事件参数

回调通常接收一个 `event` 参数：

```lua
function Script:OnPlayerClickBlock(event)
    local blockId = event.blockid          -- 方块ID
    local x, y, z = event.x, event.y, event.z
end
```

**参数为 nil 时用 `CurEventParam` 全局表兜底**：

| 字段 | 说明 |
|---|---|
| `CurEventParam.EventTargetPos` | 事件中的位置 |
| `CurEventParam.EventBuff` | 事件中的状态效果 |
| `CurEventParam.EventTargetEffect` | 事件中的特效 |
| `CurEventParam.EventTargetBlock` | 事件中的方块类型 |
| `CurEventParam.EventShortCutIdx` | 事件中的快捷栏 |
| `CurEventParam.EquipItemPos` | 事件中的装备栏 |
| `CurEventParam.EventElementID` | 事件中的元件 |
| `CurEventParam.EventUIID` | 事件中的界面 |
| `CurEventParam.EventString` | 事件中的字符串 |
| `CurEventParam.SelectUIID` | 当前编辑的界面 |
| `CurEventParam.EventAreaid` | 事件中的区域 |
| `CurEventParam.Hurtlv` | 事件中伤害值 |
| `CurEventParam.TriggerByPlayer` | 触发事件的玩家 |
| `CurEventParam.EventTargetPlayer` | 事件中的目标玩家 |
| `CurEventParam.TriggerByCreature` | 触发事件的生物 |
| `CurEventParam.EventTargetCreature` | 事件中的目标生物 |
| `CurEventParam.Actorid` | 触发事件的生物类型 |
| `CurEventParam.targetactorid` | 事件中的目标生物类型 |
| `CurEventParam.EventTargetItemID` | 事件中的道具类型 |
| `CurEventParam.TriggerByMissile` | 触发事件的投射物 |
| `CurEventParam.EventTargetDropItem` | 事件中的掉落物 |
| `CurEventParam.Itemnum` | 事件中的道具数量 |

## 2.3 事件过滤（第三参数）

```lua
self:AddTriggerEvent(TriggerEvent.PlayerGunAction, self.OnGunAction, GunAction.Equip)  -- 只监听装备动作
self:AddTriggerEvent(TriggerEvent.PlayerGunAction, self.OnGunAction, nil)              -- 监听全部
self:AddTriggerEvent(TriggerEvent.PlayerGunAction, self.OnGunAction, "")               -- 同上
```

- 过滤参数必须与事件类型匹配（枚举值 / ID）
- **云服房间尤其要加过滤**，可显著提升帧率

## 2.4 事件回调范式

```lua
function Script:OnPlayerClickBlock(event)
    if event.blockid == 100 then                      -- 草块
        Block:ReplaceBlock(452, event.x, event.y, event.z)  -- 换成钛合金
    end
end

function Script:OnObjectDie(event)
    GameObject:CreatePrefab(
        ObjType.DropItem,
        self.varItem,                                  -- 从属性读道具类型
        event.x, event.y + 1, event.z,
        self.varNum
    )
end
```

## 2.5 资源清理

```lua
function Script:OnDestroy()
    -- 移除不需要的监听
end
```

## 2.6 枚举清单

见 `09-api-index.md` 附录 B.1 / B.2（256 个 TriggerEvent + 183 个 ObjectEvent 全量）。
常用速查：

**玩家**：`PlayerClickBlock` `PlayerInputKeyDown` `PlayerShortcutAddItem`
`PlayerBackPackAddItem` `PlayerShortcutRemItem` `PlayerBackPackRemItem`
`PlayerEquipAddItem` `PlayerEquipRemItem` `PlayerAttack` `PlayerAttackHit`
`PlayerBeHurt` `PlayerDie` `PlayerRevive` `PlayerChangeAttr` `PlayerMoveOneBlockSize`

**方块**：`BlockRemove` `BlockDigBegin` `BlockDigEnd` `BlockDigCancel` `BlockBeTouched`
`PlayerTouchBlock` `BuildPlace` `BlockContainerPutIn` `BlockContainerTakeOut`

**游戏**：`GameStart` `GameAnyPlayerEnterGame` `GameAnyPlayerLeaveGame` `MinitimerChange`

**特效**：`ParticlePosOnCreate` `ParticlePlayerOnCreate` `ParticleMobOnCreate`

**UI**：`UIButtonClick` `UIButtonLongPress` `UIButtonTouchBegin` `UIButtonTouchEnd`
`UIShow` `UIHide` `UIGridClick` `UIScrollPaneScrollEnd`

## 2.7 自检清单

- [ ] 监听都注册在 `OnStart`
- [ ] 高频事件带了过滤参数（尤其云服）
- [ ] 回调里先验证参数有效性（`if not event then return end`）
- [ ] 可能出错的逻辑用 `pcall` 包一层
- [ ] `OnDestroy` 里移除监听
- [ ] 事件参数为 nil 时改走 `CurEventParam`
