# 10 · 标准库扩展（bit / table / string）

> 来源：bit位运算知识.txt、Table表知识.txt、String字符串知识.txt（官方）
> **重要**：迷你世界 UGC 3.0 自带 `bit` 模块，位运算**直接用 `bit.*`**，不要自己写逐位实现。

## 10.1 bit 模块（12 个函数）

| 函数 | 作用 |
|---|---|
| `bit.tobit(x)` | 转为适合位操作的整数（浮点转整） |
| `bit.bnot(x)` | 按位取反 |
| `bit.bswap(x)` | 字节序交换 |
| `bit.lshift(x, n)` | 左移 |
| `bit.rshift(x, n)` | 逻辑右移（高位补 0） |
| `bit.arshift(x, n)` | 算术右移（高位补符号位） |
| `bit.rol(x, n)` / `bit.ror(x, n)` | 循环左移 / 右移 |
| `bit.band(x1, x2, ...)` | 按位与（可多参） |
| `bit.bor(x1, x2, ...)` | 按位或（可多参） |
| `bit.bxor(x1, x2, ...)` | 按位异或（可多参） |
| `bit.tohex(x[, n])` | 转十六进制字符串，`n` 为长度 |

**注意**：
- 针对 32 位整数，超出会被截断；负数用二进制补码
- 结果可能为负（最高位为 1 时），需要无符号时要自己转：
  ```lua
  local function toUint32(v) v = bit.tobit(v); return v < 0 and v + 0x100000000 or v end
  local function toUint8(v)  v = bit.tobit(v); return v < 0 and v + 0x100        or v end
  ```

常用范式：

```lua
local band, bor, bxor, bnot = bit.band, bit.bor, bit.bxor, bit.bnot
local lshift, rshift = bit.lshift, bit.rshift

-- 标志位：设置 / 清除 / 检查 / 切换
local function setFlag(f, flag)   return bor(f, flag) end
local function clearFlag(f, flag) return band(f, bnot(flag)) end
local function hasFlag(f, flag)   return band(f, flag) ~= 0 end
local function toggleFlag(f, f2)  return bxor(f, f2) end

-- 颜色：拆 / 装 RGB
local function getRGB(c)
    return band(rshift(c, 16), 0xFF), band(rshift(c, 8), 0xFF), band(c, 0xFF)
end
local function makeColor(r, g, b)
    return bor(lshift(r, 16), lshift(g, 8), b)
end
```

**兼容建议**：脚本开头可 `local bitmod = rawget(_G, "bit")`，有则用、没有再走纯 Lua 兜底，
这样同一份脚本在不同环境都能跑（纯 Lua 逐位实现正确性优先，性能次要）。

## 10.2 table 扩展（官方提供，非标准 Lua 5.1）

标准件（原生就有）：`insert` `remove` `concat` `sort`
**引擎扩展**：

| 函数 | 作用 |
|---|---|
| `table.clone(ori_tab)` | 深拷贝 |
| `table.merge(dest, src[, cb][, path])` | 合并两表，`src` 覆盖 `dest` |
| `table.equal(a, b)` | 深度比较 |
| `table.show(t[, name][, indent])` | 可读格式显示（调试） |
| `table.tostring(value[, indent][, vmap])` | 表转字符串 |
| `table.num_pairs(t)` | 按数字索引顺序遍历 |
| `table.move(a1, f, e, t[, a2])` | 移动/复制区间 |
| `table.maxn(t)` | 最大数字索引 |
| `table.foreachi(t, f)` | 按序遍历数组部分 |

**已过时，别用**：`table.foreach`、`table.getn`（用 `pairs` 和 `#`）。

调试时优先 `table.show` / `table.tostring`，比自己写递归打印省事。

## 10.3 string 扩展

标准件：`len` `sub` `char` `byte` `lower` `upper` `find` `match` `gmatch` `gsub` `format` `rep` `reverse` `dump`
**引擎扩展**：

| 函数 | 作用 |
|---|---|
| `string.split(input, delimiter)` | 分割为数组 |
| `string.startswith(str, prefix)` | 前缀判断 |
| `string.endswith(str, suffix)` | 后缀判断 |

模式匹配速查：
- 字符类：`.` 任意 / `%a` 字母 / `%d` 数字 / `%s` 空白 / `%w` 字母数字 / `%x` 十六进制
- 修饰符：`+` 1+次 / `*` 0+次 / `-` 最小匹配 / `?` 0或1次
- 捕获：`()` 建组，`%1` `%2` 引用

**注意**：Lua 字符串按**字节**处理，中文是 3 字节（UTF-8），
`#s` 得到的是字节数不是字符数；按字符遍历要用 `for c in s:gmatch("[%z\1-\127\194-\244][\128-\191]*")`。

## 10.4 自检清单

- [ ] 位运算用 `bit.*`，不是自己写逐位循环（除非要做兼容兜底）
- [ ] 用到无符号结果时做了 `v < 0 and v + 0x100000000 or v` 转换
- [ ] 深拷贝用 `table.clone`，比较用 `table.equal`
- [ ] 调试打印用 `table.show` / `table.tostring`
- [ ] 处理中文时记得 `#s` 是字节数
