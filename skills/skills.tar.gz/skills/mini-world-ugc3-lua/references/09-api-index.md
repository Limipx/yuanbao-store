# 附录 A · API 类目索引（从 UGCLua.txt 运行时 dump 提取）

> 来源：`UGCLua.txt`（13.3MB，真实类型 JSON，实际为 UGC 3.0 运行时对象树 dump）。
> 用途：确认某个类/枚举**是否存在**及其大致能力面。**签名以编辑器内代码提示为准**，本表只保证命名存在性。

## A.1 类名总表（299 个，来自 `__className_` 字段）

```
Action  ActionGroup  ActorCmp_Check  Aggro  ApplyBuffStatus  Area
AreaMgr  Array  AshenEmberEffect  AutoSprinklerBlock  AutoTestMgr  BTree
BackpackCmp_Check  BackpackComponent  BaseState  BiomeEdit  BiomeType  Block
BlockEatComp  BlockEatStatusComp  BlockEdit  BlockMaterial  BlockPlaceEffect  BlockStackingComp
BlockStackingStatusComp  BlockStateEdit  BlockSubMeshEdit  BlockTransformStatus  Blueprint  Bool
BowEdit  BoxRefresh  BroomFly  Buff  BurningHeartFinalEffect  ChainLightningStatus1
ChainLightningStatus2  ChainLightningStatus3  ChainLightningStatus4  ChangeSubMesh  ChatCmp_Check  CheckHelper
CheckList  Chest  CityGen  Collider  Color  ColorGrandient
CommonBlockPlace  ComponentType  ComponentsMgr  Container  ControlStoneBurn  ControlStoneDamageUp
ControlStoneExplosion  ControlStoneHit  ControlStoneKnockBack  ControlStoneKnockUp  CraftingEdit  Cropblock
CtrlPlayerInput  CustomData  CustomMsg  CustomUICmp_Check  DataStorage  DataSycMgr
DoExplodeStatus  DoHarmStatus  Door  DoorFence  DropItem  DropItemGroup
DurabilityEdit  Effect  ElectrifiedConductionEffect  ElectrifiedEffect  ElectrifiedEffect2  ElementReactionEffect
Emitter  EmitterEdit  EmitterMotionController  Entity  EntityType  Enum
EquipEdit  EquipGridContainer  Feed  Fight  FireArrowStatus1  FireArrowStatus2
FireArrowStatus4  FireArrowStatus5  FireArrowStatus6  FireArrowStatus7  FireArrowStatus8  FireBallStatus1
FireBallStatus2  FireBallStatus3  FireBallStatus4  FireBallStatus5  FlameSplashEffect  FlowerPot
FoodDisplayComp  FoodEdit  FrozenSoulStackDamageEffect  FurnaceEdit  GameObject  GameObjectMgr
GenerateBlock  GraphicsCmp_Check  GrassSpiritCountdownEffect  GridContainer  GroupView  Grow
GunEdit  HP  HandleEdit  HomingMissileStatus1  HomingMissileStatus2  HomingMissileStatus3
HomingMissileStatus4  HorizontalConnection  IceArrowStatus  IceArrowStatus2  IceArrowStatus3  IceArrowStatus4
IceArrowStatus5  IceBallStatus1  IceBallStatus2  IceBallStatus3  IceBallStatus4  IceBallStatus5
IceFieldRadiationEffect  IceSoulPurifyEffect  IgniteDetonateEffect  InscriptionTable  Interact  Item
ItemEdit  ItemEffect  LaunchProjectileStatus  LightingFurniture  LightningStatus1  LightningStatus2
LightningStatus3  LightningStatus4  LightningStatus5  LightningStatus6  LineAnimation  MagicBowStatus1
MagicBowStatus2  MagicBowStatus3  MagicBowStatus4  MagicBowStatus5  MagicGunStatus1  MagicGunStatus2
MagicGunStatus3  Material  Mob  MobDemo  MobOutfitGen  MobType
Model  ModelAction  MonsterEdit  MotionGroup  Move  MtAround
MtLine  MtParabola  MtScale  MtTrack  NPCShop  Number
Object  OldGunEdit  Oxygen  PackEdit  ParalyzeEffect  ParalyzeSpreadEffect
PathPoint  Physics  Picture  Plant  PlayEffectStatus  PlaySoundStatus
Player  PlayerCmp_Check  PlayerController  PlayerType  Position  PrairieFireBlastEffect
Prefab  Projectile  ProjectileEdit  RandOutfit  RandomAddStatus  RandomFetchItem
Rebound  RecoverStatus  ReduceGravityEffect  Reproduction  Ride  Roadblock
Role  Rotation  RuleMgr  RuneShieldEffect  SaveDataMgr  Scale
Scheduler  ScriptEnvMgr  ScriptLog  SitAndLie  SkeletonPoint  Skill
SkillDemo  SkyBox  SkyBoxFilter  Sleep  Sound  SplitArrowStatus1
SplitArrowStatus2  Status  StatusEdit  StayVersion  StoneWallStatus  StoneWallStatus1
StoneWallStatus2  StoneWallStatus3  StoneWallStatus4  StoneWallStatus7  StoneWallStatus8  String
SummonGrassSpirit  SurviveComponent  SwapPosition  Tag  Tame  Task
TextureSwitcher  ThrowItem  ThunderBallStatus1  ThunderBallStatus2  ThunderBallStatus3  ThunderBallStatus4
ThunderGodArrowEffect  ThunderWalkEffect  TimerCmp_Check  TimerMgr  ToolEdit  TrackingStatus1
TrackingStatus2  TrackingStatus3  TrackingStatus4  TrackingStatus5  Transform  TransformBlockStatus
TrellisBlock  UGCMapResource  UGCMapResourceMgr  UIObjectMgr  UIProjectSet  UiElement
UiState  UseEdit  VarBase  VarMap  VarMgr  Vec2
Vec3  VerticalConnection  Villager  WeaponDamageTest  Window  WorldCmp_Check
WorldContainerCmp_Check  WorldObject  WorldRuleBackPackPlatformTab  WorldRuleBaseSetting  WorldRuleBuildingGen  WorldRuleCameraSetting
WorldRuleCloudSetting  WorldRuleFightSetting  WorldRuleHUDUI  WorldRuleMgr  WorldRuleMobGen  WorldRuleModImportSetting
WorldRulePhysicalSetting  WorldRuleRebirth  WorldRuleResetMap  WorldRuleSaveData  WorldRuleSceneUI  WorldRuleSkybox
WorldRuleSound  WorldRuleSpecialSetting  WorldRuleStartMode  WorldTask  c765410939215979283268802
```

## A.2 重点类方法清单

- **Action**（1）：__call
- **Actor**（47）：ActorDoHurt、AddOrRemoveTags、AppendSpeed、ChangActorMoveType、ChangeCustomModel、CheckActorType、CheckPickupActionValid、CheckTargetActorType、ClearActorWithId、CompareMovementMode、CompareTeam、FindNearestBlock、GetBoundSzie、GetBtreeVarValue、GetPickupActorID、GetPosition、GetProjectileShootMob、GetProjectileShootPlayer、IncreasesAttr、KillSelf、ObjToAnyObj、PaseOrResumeSoundEffectById、PauseSoundEffectById、PlayAnimByObj、PlayBodyEffectById、PlayBodyParticleById、PlaySoundEffectById、RecoverinitialModel、RemoveImmuneAttackType、ResumeSoundEffectById、RoleToAnyObj、SetActorDir、SetAttr、SetBodyEffectScale、SetBodyParticleTransform、SetBtreeVarValue、SetCmpBaseState、SetFaceDir、SetFaceYaw、SetImmuneAttackType、SetNickName、SetPosition、SetTeam、StopBodyEffectById、StopSoundEffectById、TryInteractActor、TryMoveToPos
- **Array**（35）：AddEvent、Clear、ClearEvent、Copy、GetAllValue、GetCountByValue、GetIndexByValue、GetItemType、GetMax、GetMin、GetRefType、GetValue、HasValue、IncreasesValue、Init、InitData、Insert、InsertValues、IsInstance、IsValid、MoveTo、RandomValue、Remove、RemoveByValue、RemoveByValues、Replace、ReplaceValue、Serialize、SetIsTriggerEvent、SetValue、Size、Sort、ToTable、TreeJsonUnSerialize、UnSerialize
- **Backpack**（43）：ActDestructEquip、ActEquipOffByEquipID、ActEquipUpByResID、AddItem、CalcSpaceNumForItem、ClearAllPack、ClearGrids、ClearPack、CreateGunInBackpack、CreateItem、CreateItemInstInBackpack、DecodeGridInfo、DiscardItem、DiscardItemByID、EncodeTableGridInfo、EnoughSpaceForItem、GetAllBackPackInstanceIds、GetGridAttr、GetGridGunInfo、GetGridInfos、GetGridItemID、GetGridItemName、GetGunInstIdInBackpack、GetInstIdByGridIndex、GetItemNum、GetItemNumByBackpackBar、HasItemByBackpackBar、IsLock、LoadGridInfos、MoveGridItem、PlayShortCutItemEffect、PlayShortCutItemParticle、PlayShortCutIxEffect、PlayShortCutIxParticle、RemoveGridItem、RemoveGridItemByItemID、SetBackPackNum、SetGridAttr、SetGridItem、SetGridsLock、StopShortCutItemEffect、StopShortCutIxEffect、SwapGridItem
- **Blueprint**（1）：__call
- **Chat**（2）：SendChat、SendSystemMsg
- **Color**（2）：__call、__index
- **Component**（13）：AddComponent、AddEvent、CallComponentFunction、CallComponentFunctionVar、CheckCmpFunctionCallType、GetComponentProperty、GetIsHasCmp、IncreasesComponentProperty、IsEventEnable、RemoveComponent、RunCmpBaseFn、SetComponentProperty、SetEventIsEnable
- **Creature**（1）：__call
- **CustomData**（12）：AddEvent、ClearEvent、Copy、CopyToTable、GetKeys、GetRefType、Init、Serialize、SetIsTriggerEvent、ToTable、TreeJsonUnSerialize、UnSerialize
- **CustomMsg**（1）：__call
- **Emitter**（1）：__call
- **Enum**（1）：__call
- **GameObject**（6）：CreatePrefabInst、CreatePrefabInstEx、CreateSinglePrefabInst、GetObjectPrefab、GetPrefabDes、GetPrefabName
- **Graphics**（40）：CreateBrushByPos、CreateGraphicsArrowByActorToActor、CreateGraphicsArrowByActorToPos、CreateGraphicsArrowByPosToActor、CreateGraphicsArrowByPosToPos、CreateGraphicsImageByActor、CreateGraphicsImageByPos、CreateGraphicsLineByActorToActor、CreateGraphicsLineByActorToPos、CreateGraphicsLineByPosToActor、CreateGraphicsLineByPosToPos、CreateGraphicsNavPathByActorToPos、CreateGraphicsProgressByActor、CreateGraphicsProgressByPos、CreateGraphicsSurfaceByActorToActor、CreateGraphicsSurfaceByActorToPos、CreateGraphicsSurfaceByPosToActor、CreateGraphicsSurfaceByPosToPos、CreateGraphicsTxtByActor、CreateGraphicsTxtByPos、CreateflotageTextByActor、CreateflotageTextByPos、GetInnerGraphicsOffset、MakeGraphicsArrowToActor、MakeGraphicsArrowToPos、MakeGraphicsImage、MakeGraphicsLineToActor、MakeGraphicsLineToPos、MakeGraphicsNavPathToPos、MakeGraphicsProgress、MakeGraphicsSurfaceToActor、MakeGraphicsSurfaceToPos、MakeGraphicsText、MakeflotageText、RemoveGraphicsByGraphicsID、RemoveGraphicsByObjID、RemoveGraphicsByPos、ReplaceAllGraphics、UpdateGraphicsProgressById、UpdateGraphicsTextById
- **Material**（1）：__call
- **Math**（54）：Abs、Ceil、ColorTostring、CompareGreater、CompareGreaterEqual、CompareLess、CompareLessEqual、Concat、ContainStr、Cos、Deg、DivAndFloor、Equal、Exp、Floor、IsEven、IsNegative、IsOdd、IsPositive、IsPrime、Isinteger、Isnil、Ldexp、Log、Log10、LogicCompareTable、MathAdd、MathArithmetic、MathDivide、MathExtractOpt、MathMultiply、MathSub、MathUnFixedBaseLog、MathXor、Max、Min、Mod、ModEqualZero、Negate、NotEqual、Pow、Pow10、Rad、Random、Round、Sin、Sqrt、StrToBool、StrToColor、StrToV3、Tan、TanAngle2Rad、Tostring、V3Tostring
- **Picture**（1）：__call
- **Player**（1）：__call
- **Prefab**（1）：__call
- **SkyBox**（1）：__call
- **String**（1）：__call
- **Table**（15）：Clear、GetAllValue、GetColIndex、GetCols、GetRowIndex、GetRowIndexs、GetRows、GetTableColKeys、GetValue、GetValuesByCol、InsertValue、InsertValueByRow、RemoveRow、SetValue、UpdateAllValue
- **Timer**（12）：ChangeTimerTime、CreateTimer、DeleteTimer、GetTimerTime、HideTimerWnd、IsExist、PauseTimer、ResumeTimer、ShowTimerWnd、StartBackwardTimer、StartForwardTimer、StopTimer
- **Vec3**（1）：__call
# 附录 B · 枚举与常量（从运行时 dump 提取，命名保证存在）

## B.1 TriggerEvent · 触发器事件（256 项）
> `self:AddTriggerEvent(TriggerEvent.X, handler, filterParam)`

ActorAddBuff  ActorAreaIn  ActorAreaOut  ActorAttack
ActorAttackHit  ActorBeHurt  ActorBeat  ActorChangeAttr
ActorChangeMotion  ActorClickActor  ActorCollide  ActorCreate
ActorDamage  ActorDie  ActorPickupActor  ActorProjectileHit
ActorRemoveBuff  AreaObjAreaIn  AreaObjAreaOut  AreaObjCollideToAreaObj
AreaObjCollideToDropItem  AreaObjCollideToEntity  AreaObjCollideToMissile  AreaObjCollideToMob
AreaObjCollideToPlayer  AreaObjCreate  AtorPlayAnim  BackpackItemChange
BackpackItemPutIn  BackpackItemTakeOut  BiomeActorSpawn  BlockAdd
BlockBeTouched  BlockChangeColor  BlockChangeDir  BlockChunkExtraBuild
BlockContainerChange  BlockContainerPutIn  BlockContainerTakeOut  BlockDestroyBy
BlockDigBegin  BlockDigCancel  BlockDigEnd  BlockDropModReward
BlockPlaceBy  BlockRemove  BlockTrigger  BluePrintBuildBegin
BuildActorSpawn  BuildBaseActorSpawn  BuildBaseZombieSpawn  BuildPlace
BuildReport  BuildZombieSpawn  CaptureAndUploadScreenshot  CheckSummoner
CityReport  ComputerSendOrderEvent  CraftEnd  DeveloperBuyItem
DropItemAreaIn  DropItemAreaOut  DropItemCollideToAreaObj  DropItemCollideToDropItem
DropItemCollideToEntity  DropItemCollideToMissile  DropItemCollideToMob  DropItemCollideToPlayer
DropItemPickup  EntityAreaIn  EntityAreaOut  EntityCollideToAreaObj
EntityCollideToDropItem  EntityCollideToEntity  EntityCollideToMissile  EntityCollideToMob
EntityCollideToPlayer  EntityCreate  FurnaceBegin  FurnaceEnd
GameAnyPlayerDefeat  GameAnyPlayerEnterGame  GameAnyPlayerLeaveGame  GameAnyPlayerVictory
GameHour  GameStart  GroupWeatherChanged  ItemAddDuration
ItemCreate  ItemDamage  ItemDestroy  ItemDisappear
ItemDiscardItem  ItemExpend  ItemPickup  ItemTipsOpen
MainTaskCheck  MainTaskGain  MiniMapIconClick  MinitimerChange
MissileAreaIn  MissileAreaOut  MissileCollideToAreaObj  MissileCollideToDropItem
MissileCollideToEntity  MissileCollideToMissile  MissileCollideToMob  MissileCollideToPlayer
MissileCreate  MobAddBuff  MobAreaIn  MobAreaOut
MobAttack  MobAttackHit  MobAttrStateChange  MobBeClick
MobBeHurt  MobBeInteract  MobBeat  MobChangeAttr
MobChangeMotion  MobCollide  MobCollideToAreaObj  MobCollideToDropItem
MobCollideToEntity  MobCollideToMissile  MobCollideToMob  MobCollideToPlayer
MobCreate  MobDamage  MobDie  MobDismountActor
MobModelChange  MobMotionStateChange  MobMountActor  MobProjectileHit
MobRemoveBuff  ObjBeTouched  ObsBluePrintBuildBegin  ObsBluePrintBuildEnd
ObsBluePrintLoaded  ObsBluePrintUnLoaded  ParticleEntityOnCreate  ParticleItemOnCreate
ParticleMobOnCreate  ParticleObjectOnCreate  ParticlePlayerOnCreate  ParticlePosOnCreate
ParticleProjectileOnCreate  PayMapShopOrder  PlayerAddBuff  PlayerAddItem
PlayerAnimFinish  PlayerAreaIn  PlayerAreaOut  PlayerAttack
PlayerAttackHit  PlayerAttrStateChange  PlayerBackPackAddItem  PlayerBackPackChange
PlayerBackPackRemItem  PlayerBeHurt  PlayerChangeAttr  PlayerChangeCoin
PlayerChargeItemBegin  PlayerChargeItemEnd  PlayerClickActor  PlayerClickBlock
PlayerClickDropItem  PlayerClickEntity  PlayerClickMob  PlayerClickPlayer
PlayerClickProjectile  PlayerCloseInnerView  PlayerCollide  PlayerCollideToAreaObj
PlayerCollideToDropItem  PlayerCollideToEntity  PlayerCollideToMissile  PlayerCollideToMob
PlayerCollideToPlayer  PlayerConsumeItem  PlayerDamageActor  PlayerDefeatActor
PlayerDie  PlayerDiscardItem  PlayerDismountActor  PlayerEquipAddItem
PlayerEquipChange  PlayerEquipOff  PlayerEquipOn  PlayerEquipRemItem
PlayerGunAction  PlayerInputContent  PlayerInputKeyClick  PlayerInputKeyDown
PlayerInputKeyOnPress  PlayerInputKeyUp  PlayerInvateFriend  PlayerLevelModelUpgrade
PlayerModelChange  PlayerMotionStateChange  PlayerMotionStateChangeEnd  PlayerMountActor
PlayerMoveOneBlockSize  PlayerNewInputContent  PlayerOpenInnerView  PlayerPickUpItem
PlayerPlayAction  PlayerRemoveBuff  PlayerRevive  PlayerSaveSkinSeat
PlayerSelectShortcut  PlayerShortcutAddItem  PlayerShortcutChange  PlayerShortcutRemItem
PlayerTouchBlock  PlayerTouchObj  PlayerUseGiftPack  PlayerUseItem
PlotBegin  PlotEnd  ProjectileHitAreaObj  ProjectileHitBlock
ProjectileHitEntity  ProjectileHitItem  ProjectileHitMob  ProjectileHitPlayer
ProjectileHitProj  QQMusicPlayBegin  TLEventActorSpawn  TaskUpdate
TeleportMatchRsp  TimelineStart  TimelineStop  UIBtnClick
UIButtonClick  UIButtonLongPress  UIButtonTouchBegin  UIButtonTouchEnd
UIContainerActivity  UIContainerPress  UIContainerRelease  UIGLoader3DLongPress
UIGLoader3DTouchBegin  UIGLoader3DTouchClick  UIGLoader3DTouchEnd  UIGridClick
UIHide  UILostFocus  UIScrollPaneScrollEnd  UIScrollPaneTouchBegin
UIScrollPaneTouchEnd  UIShow  UISpineComplete  WeatherChanged

## B.2 ObjectEvent · 组件/对象事件（183 项）
> `self:AddEvent(ObjectEvent.X, handler)`

ActorAddBuff  ActorAreaIn  ActorAreaOut  ActorAttack
ActorAttackHit  ActorBeHurt  ActorBeat  ActorChangeAttr
ActorChangeMotion  ActorClickActor  ActorCollide  ActorCreate
ActorDamage  ActorDie  ActorEnterAOI  ActorPickupActor
ActorProjectileHit  ActorRClickUp  ActorRemoveBuff  BlockAdd
BlockBeTouched  BlockChangeColor  BlockChangeDir  BlockClicked
BlockContainerChange  BlockContainerPutIn  BlockContainerTakeOut  BlockDestroy
BlockDigBegin  BlockDigCancel  BlockDigEnd  BlockPlaceBy
BlockRemove  CanPlayerPickUpItem  CaptureAndUploadScreenshot  DeveloperBuyItem
EntityCreate  EquipItemEvent  InteractBlock2Place  ItemAddDuration
MobAddBuff  MobAreaIn  MobAreaOut  MobAttack
MobAttackHit  MobAttrStateChange  MobBeClick  MobBeHurt
MobBeInteract  MobBeat  MobChangeAttr  MobChangeMotion
MobCollide  MobCreate  MobDamage  MobDie
MobDismountActor  MobMotionStateChange  MobMountActor  MobProjectileHit
MobRClickUp  MobRemoveBuff  MobUseItem  MouseEvent
ObjBeTouched  ObjectAddBuff  ObjectAttack  ObjectAttackHit
ObjectAttrStateChange  ObjectBeClick  ObjectBeHurt  ObjectChangeAttr
ObjectCollide  ObjectCollideByAreaObj  ObjectCollideByDropItem  ObjectCollideByEntity
ObjectCollideByMissile  ObjectCollideByMob  ObjectCollideByPlayer  ObjectDamage
ObjectDefeat  ObjectDie  ObjectDismountActor  ObjectMotionStateChange
ObjectMotionStateChangeEnd  ObjectMountActor  ObjectPlayAnim  ObjectRemoveBuff
OnBeDeadlyHurt  OnBeforeLeaveWorld  OnBlockAdd  OnBlockDestroy
OnBlockPlaceBy  OnBlockRemove  OnCollide  OnCollideBegin
OnCollideEnd  OnEnterWorld  OnInteract  OnInteractLowPriority
OnLeaveWorld  OnModelChange  OnNotify  OnPropertyChange
OnSoundAction  OnTame  OnThrowActor  PayMapShopOrder
PlayerAddBuff  PlayerAddItem  PlayerAreaIn  PlayerAreaOut
PlayerArmEntryMsg  PlayerAttack  PlayerAttackHit  PlayerAttrStateChange
PlayerBackPackAddItem  PlayerBackPackChange  PlayerBackPackRemItem  PlayerBeHurt
PlayerChangeAttr  PlayerChangeCoin  PlayerChargeItemBegin  PlayerChargeItemEnd
PlayerClickActor  PlayerClickBlock  PlayerClickDropItem  PlayerClickEntity
PlayerClickMob  PlayerClickPlayer  PlayerClickProjectile  PlayerCollide
PlayerConsumeItem  PlayerDamageActor  PlayerDefeat  PlayerDefeatActor
PlayerDestroyBlock  PlayerDie  PlayerDiscardItem  PlayerDismountActor
PlayerDodge  PlayerEnterGame  PlayerEquipAddItem  PlayerEquipChange
PlayerEquipOff  PlayerEquipOn  PlayerEquipRemItem  PlayerFire
PlayerFireBefore  PlayerGunRecovering  PlayerGunRecoveryCD  PlayerHeadShot
PlayerInputContent  PlayerInputKeyClick  PlayerInputKeyDown  PlayerInputKeyOnPress
PlayerInputKeyUp  PlayerInvateFriend  PlayerLeaveGame  PlayerLevelModelUpgrade
PlayerMotionStateChange  PlayerMotionStateChangeEnd  PlayerMountActor  PlayerMoveOneBlockSize
PlayerNewInputContent  PlayerPickUpItem  PlayerPlayAction  PlayerReload
PlayerRemoveBuff  PlayerRevive  PlayerSelectShortcut  PlayerShortcutAddItem
PlayerShortcutChange  PlayerShortcutRemItem  PlayerSkillTriggerInput  PlayerTouchBlock
PlayerTouchObj  PlayerUseGiftPack  PlayerUseItem  PlayerVictory
UIEquitChange  UIGridChange  UseItemScriptEvent

## B.3 ObjType · 对象类型（含值）

- `Actor` = 0
- `Area` = 14
- `BiomeEdit` = 9
- `Block` = 5
- `BlockMaterial` = 12
- `Crafting` = 11
- `DropItem` = 17
- `Empty` = 4
- `Entity` = 0
- `Furnace` = 13
- `Item` = 7
- `Mob` = 1
- `Player` = 2
- `Pos` = 16
- `Projectile` = 15
- `Status` = 8
- `StatusEffect` = 1001
- `StatusEffectInst` = 1002
- `UI` = 6
- `World` = 3

## B.5 KeyCode · 按键（46 项）

A  Alt  B  C
Ctrl  D  Down  E
F  G  H  I
J  K  L  Left
LeftButton  M  N  Number0
Number1  Number2  Number3  Number4
Number5  Number6  Number7  Number8
Number9  O  P  Q
R  Right  RightButton  S
Shift  Space  T  U
Up  V  W  X
Y  Z

## B.6 Mini · 类型系统（51 项）

Action  Area  Array  BiomeType
Block  Blueprint  Bool  Buff
CheckList  Color  ColorGrandient  ComponentType
Creature  CreatureType  CustomData  CustomMsg
DropItem  Effect  Emitter  Entity
EntityType  Enum  GroupView  Item
LineAnimation  Material  Mob  MobType
Model  ModelAction  Number  Object
PathPoint  Picture  Player  PlayerType
Prefab  Role  Rotation  Scale
SkeletonPoint  SkyBox  SkyBoxFilter  Sound
String  Tag  ThrowItem  UiElement
UiState  Vec2  Vec3

## B.7 ComponentUIStyle · 属性面板风格（81 项）

AIModelArray  AIModelItem  ActionArray  ActionButton
ActionItem  AnchorMeshGroup  AnchorMeshGroupItem  ArrayAI
ArrayBiomeMonster  ArrayBlockMaterial  ArrayBuff  ArrayBurstItem
ArrayCommonItem  ArrayDropItem  ArrayEmitterId  ArrayFeedItem
ArrayForItems  ArrayForItemsOffsetPos  ArrayForTags  ArrayImportAnimation
ArrayItem  ArrayMonsterItem  ArrayParticleBrusts  ArraySkill
ArrayStatus  ArrayStatusEffect  ArrayStatusEffectInst  AvatarPart
BlockModel  BlockTemp  Bullet  ColorGradient
CommonItem  Curve  CustomCommonItem  CustomDropItem
CustomFeedItem  CustomItemAI  CustomItemStatus  CustomItemStatusEffect
CustomItemUseEdit  CustomMaterial  CustomRewardItem  CustomSkillItem
DropItem  EffectMaterial  EnumController  EnumControllerHideValue
EnumDrapdown  EnumList  FilterPicture  Icon
ItemEquip  ItemModel  Jump  MaterialGroup
MaterialGroupItem  MaterialGroupItemNew  ModelAttrArray  Number
NumberButton  NumberOnlyInput  NumberOnlyRandom  NumberSlider
OnlyCustomPicture  ParticleModuleItem  PathPoint  Paths
PreViewButton  Projectile  SinglePicture  SkyPicture
SkyTexture  SunMoonTexture  Switch  Tag
Title  TitleParticleEdit  Vector3AnchorPoint  Vector3Input
Vector3Selector

## A.3 UI 绘制常用（CustomUI / ElementType）

**`ElementType` 枚举（6 个）**：`Texture`、`Text`、`Button`、`InputText`、`Loader3D`、`SlidingContainer`

**`CustomUI` 66 个方法**（UI 元件绘制与交互，全部来自运行时 dump，命名保证存在）：

- **生命周期**：`CreateElement` `DeleteElement` `CloneElement` `ChangeParent`
- **几何**：`SetSize` `SetPosition` `SetScale` `SetRelationSize` `SetRelationPosition` `RotateElement`
- **外观**：`SetTexture` `SetColor` `SetAlpha` `SetText` `SetFontSize` `SetState`
- **显隐**：`ShowElement` `HideElement`
- **动画**：`PlayElementAnim` `StopAnim` `SmoothMoveTo/By` `SmoothScaleTo/By` `SmoothRotateTo/By` `SmoothIncreaseProgress` `SmoothChangeProgress`
- **绑定**：`SetPositionBindActor` `SetPositionBandBlock` `RemovePositionBindActor` `RemovePositionBandBlock`
- **取值**：`GetElementAttrValue` `GetUIViewAttrValue` `GetScreenSize` `GetProgressBarValue`
- **图标**：`GetItemIcon` `GetBlockIcon` `GetMonsterIcon` `GetRoleIcon` `GetRoleHeadIcon` `GetStatusIcon` `GetShortcutIcon` `GetMonsterObjIcon` `SetUrlIcon`
- **信标**：`SetBeaconObjId` `SetBeaconRadius` `SetBeaconOffset` `SetBeaconMapType` `SetBeaconClampType` `SetBeaconMargin` `SetBeaconBandPos`
- **其他**：`SetLoaderModel` 系列、`SetSliderBarImg` `SetSliderDir` `TurnSliderToPos` `SetSpineAnimID` `SetFloatDamageTxt` `SetProgressBarResId` `SetSysSettingBtnVisible`

绘制二维码/图形的最小集合：`CreateElement` + `SetTexture` + `SetSize` + `SetPosition` + `SetColor` + (`ShowElement`/`HideElement` 显隐) + `DeleteElement` 回收。
