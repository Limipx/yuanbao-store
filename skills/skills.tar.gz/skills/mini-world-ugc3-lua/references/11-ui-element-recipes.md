# 11 · UI 元件绘制套路（实测可用）

> 来源：`创建元件.txt`（坐标规则）、`图片生成器.lua` / `图片生成器多线程.lua`（染色与批处理）、
> 本目录下已验证的二维码工具与图片工具。

## 11.1 最小绘制五件套

```lua
local eid = CustomUI:CreateElement(pid, uiid, ElementType.Texture)
CustomUI:SetTexture(pid, uiid, eid, "0_10212")   -- 纯白纹理，靠染色出任意颜色
CustomUI:SetSize(pid, uiid, eid, w, h)
CustomUI:SetPosition(pid, uiid, eid, x, y)
CustomUI:SetColor(pid, uiid, eid, 0xRRGGBB)
```

**关键技巧**：用一张纯白纹理 + `SetColor` 染色，就能画出任意颜色，
不需要为每种颜色准备一张图。默认资源 ID `0_10212` 是白色方块。

## 11.2 坐标规则（易错）

界面坐标 Y 轴**向上为正**，所以：

- 第 0 行画在**顶部**：`y = startY`
- 第 `row` 行往下走：`y = startY - row * cellHeight`
- 第 `col` 列往右走：`x = startX + col * cellWidth`

写成一行就是 `ty = startY - gameY * height`（见 `创建元件.txt`）。
若你的素材是从上往下排的数组，记得取负号；反过来（Y 向下）改成 `+`。

## 11.3 元件池：不要反复 Create/Delete

创建/销毁元件是最贵的操作。**按"需要量"增减**，多余的销毁、不够的补建：

```lua
local pool = qr.fgIds or {}
while #pool < need do pool[#pool + 1] = newElement() end
while #pool > need do
    CustomUI:DeleteElement(pid, uiid, pool[#pool]); pool[#pool] = nil
end
for i = 1, need do applyStyle(pool[i], rects[i]) end
```

改内容时复用同一批元件，只改 Size/Position/Color，比全部删掉重建快得多。

## 11.4 矩形合并：把元件数压下来

逐像素画 = 元件数 ≈ 像素数，很容易几千个。合并同色连通区域能大幅下降：

1. **行内合并**：一行里连续同色合成一个矩形
2. **向下扩展**：下一行同列区间也同色，就并进去

实测：64×64 四色块图 → **4 个元件**（4096 像素压到 0.1%）。
但渐变图每个像素颜色都不同，合并率接近 0，只能靠降采样控制。

## 11.5 降采样：控制权宜

超过预算像素数时按整数倍抽点。**候选尺寸必须始终用「原图尺寸 / step」算**：

```lua
local ow, oh = img.width, img.height
local step = 1
while math.floor(ow / step) * math.floor(oh / step) > maxPixels and step < 32 do
    step = step + 1
end
```

**坑**：若把缩小后的宽高回填再除下一次，会变成几何级数衰减
（1000 → 500 → 166 → 41…），图被缩得远小于预期，且 `step` 和实际尺寸对不上。

## 11.6 批量创建的卡顿处理

一次性创建上千元件会卡住主线程。参考多线程版的做法：

```lua
local batch = 0
for i = 1, #items do
    createOne(items[i])
    batch = batch + 1
    if batch >= 500 then
        batch = 0
        coroutine.yield()      -- 或 threadpool:wait(0)
    end
end
```

`threadpool.default` + `threadpool.work(fn, arg)` + `threadpool.wait()` 可把
按颜色分组的批次丢到线程池。注意：定时唤醒的会话没有工具权限，
协程让出只在**当前有执行权限的会话**里有效。

## 11.7 生命周期

- `OnStart` 里初始化容器（如 `self.images = {}`）
- `OnDestroy` 里遍历销毁全部元件，**不留残留**
- 同名重建时先把旧的销毁再建新的，避免元件泄漏
- 所有对外接口都要防"找不到名字"的调用，打印原因后直接 return，不要崩

## 11.8 自检清单

- [ ] 坐标用了 `startY - row * h`（界面 Y 轴向上）
- [ ] 元件池复用，没有每次全删重建
- [ ] 做了矩形合并或降采样，元件数在预算内
- [ ] 降采样的候选尺寸用原图尺寸 / step，没有回填累积
- [ ] `OnDestroy` 清空所有元件
- [ ] 错误路径（空名/找不到/非法输入）不会崩也不产生残留元件
