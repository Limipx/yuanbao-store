---
name: code-resource-hunting
description: |
  开源库/代码片段的评估与取材。找到候选后按"是否真存在、许可能否用、是否还在维护、体积与依赖、
  有无硬编码密钥或可疑外连"打分，再决定抄思路还是直接用。当用户要"找个库做 X"
  "有没有现成的轮子""这个库靠谱吗""能用这个代码吗"时使用。触发词：找库、开源库、
  轮子、能不能用、许可、依赖评估。
version: "2.0"
author: "重建于 2026-10-04（原版仅存在于已丢失备份包，按规格重建）"
---

# code-resource-hunting — 开源资源评估

## 本环境通路

- `codeload.github.com` ✅ **首选**：整仓 tar.gz，不计 API 配额
  ```bash
  curl -sSL -m 180 -o r.tgz "https://codeload.github.com/<owner>/<repo>/tar.gz/refs/heads/main"
  gzip -t r.tgz && mkdir -p x && tar xzf r.tgz -C x && ls x
  ```
  默认分支非 main 时先换 `refs/heads/master`
- `api.github.com` ⚠️ 60 次/小时未鉴权限流 → 只用于查仓库真名/列目录，别批量
- npm registry ❌ 403 → `npm install` 走不通，依赖需随仓带上或改用 vendored 方式
- 拉完**必须校验**：`head -12 SKILL.md`（frontmatter 有 name+description）、`wc -c`（<500B 是错误页）

## 评估五维（每项 0-2 分，≥7 分才推荐直接用）

1. **存在性**：真拉到了？还是 404 页面？
2. **许可**：有 LICENSE 吗？
   - 无 LICENSE → 只可参考思路，**不可复制代码**
   - GPL/AGPL → 不能进闭源商业项目
   - MIT/Apache-2.0/BSD → 可商用，保留版权声明
3. **活跃度**：最近提交时间、Issue 响应、star 趋势。超过 2 年无更新要标注风险
4. **体积与依赖**：依赖树多深？会不会引入几十个传递依赖？
5. **安全性**：扫硬编码密钥与可疑外连
   ```bash
   grep -rnoE '(api[_-]?key|secret|token|password)\s*[:=]\s*["'"'"'][A-Za-z0-9_\-]{16,}' .
   grep -rnoE 'curl[^|]*\|\s*(ba)?sh|eval\(|base64\s+-d' .
   ```

## 输出格式

给一张小表（`| 候选 | 许可 | 活跃度 | 风险 | 结论 |`），最多 3-5 个候选，
最后一句话给推荐："用 X，理由是 Y；不要用 Z，因为 W。"

## 纪律

- **不编造仓库**。没找到就说没找到，不要凭印象写个 owner/repo
- 找到的仓库必须真拉下来看过，不能只看搜索摘要就下结论
- 取回的脚本先扫密钥与外连，再决定是否执行
- 模板/示例数据不能当真数据交付
