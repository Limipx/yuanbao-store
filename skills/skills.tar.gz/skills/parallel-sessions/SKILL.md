---
name: parallel-sessions
description: |
  用 git worktree 开多条独立线路并行改代码：每条线路一个 worktree、一个分支，
  互不覆盖，最后统一合并与回归。适用于"多个功能同时开发""大改动怕污染主分支"
  "同一批文件被多路修改"的场景。触发词：worktree、多线路、并行开发、
  开分支同时改、隔离改动。
version: "2.0"
author: "重建于 2026-10-04（原版仅存在于已丢失备份包，按规格重建）"
---

# parallel-sessions — worktree 多线路

## 何时用

- 多路任务会改到**同一批文件** → 必须 worktree 隔离，否则互相覆盖
- 大改动想留退路，不污染主分支
- 需要同时保留多个实验方案做对比

改的是**文档/产出物**而非代码 → 用 multi-line-office（目录隔离更轻）。

## 标准流程

1. **预检**
   ```bash
   git -C <repo> status --porcelain | head    # 工作区必须干净
   git -C <repo> rev-parse --is-inside-work-tree
   ```
   不干净 → 先 stash 或提交，不硬开
2. **建 worktree**
   ```bash
   git -C <repo> worktree add ../wt-<线路名> -b feat/<线路名>
   ```
3. **各线路独立推进**：每路在自己的 worktree 里跑测试、提交
4. **合并**
   ```bash
   git -C <repo> checkout main && git -C <repo> merge feat/<线路名>
   ```
   冲突 → 停下来报给用户，不自行拍板取舍
5. **回归**：合并后**整体跑一遍测试**，不是只跑改动部分
6. **清理**：`git worktree remove ../wt-<线路名>`（确认已合并后再删）

## 纪律

- **不跳过预检**：工作区脏着开 worktree，最后一定难收拾
- 每路提交信息要写清线路名，便于回溯
- 合并冲突必须让用户决策，尤其涉及业务逻辑取舍时
- 清理 worktree 前确认改动已合并，否则等于丢代码
- 本环境无常驻进程 → 长时间挂着的 worktree 会话会被回收，别依赖长期状态
