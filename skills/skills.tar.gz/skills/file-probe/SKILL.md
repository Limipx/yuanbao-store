---
name: file-probe
description: |
  文件魔数识别，不信后缀只看字节。用户上传的文件后缀常与实际内容不符（传 .txt 实为 base64 编码的
  视频/压缩包/图片/音频），必须先探测再解析。支持 base64 伪装自动解码、压缩包解压、视频抽帧。
  当用户上传/提供任何文件、需要判断文件真实类型、文件打不开或解析报错、怀疑文件是编码伪装时使用。
  触发词：这是什么文件、识别文件、魔数、文件类型、打不开、base64、探测、probe。
version: "2.0"
author: "重建于 2026-10-04"
---

# file-probe — 文件魔数识别

## 铁律

**识别上传文件先看魔数，不看后缀。** 用户常传 `.txt` 后缀但实际是 base64 编码的视频/压缩包/图片/音频。
不凭文件名猜。

## 用法

```bash
python3 /data/skills/file-probe/scripts/probe.py <file> --out ./_probe_out
python3 /data/skills/file-probe/scripts/probe.py <file> --out ./_probe_out --frames 8   # 视频抽帧
python3 /data/skills/file-probe/scripts/probe.py <file> --out ./_probe_out --extract    # 解压
python3 /data/skills/file-probe/scripts/probe.py <file> --out ./_probe_out --view       # 导出图片原图
python3 /data/skills/file-probe/scripts/probe.py <file> --json                          # 机器可读
```

## 判定顺序

1. 读前 4096 字节，匹配魔数表（jpeg/png/gif/webp/bmp/tiff/heic/pdf/zip/gzip/bz2/xz/7z/rar/
   tar/zstd/lz4/sqlite/mp3/ogg/flac/wav/mp4/mov/webm/avi/quicktime/OLE2 老 Office/postscript…）
2. `ftyp` 系按 brand 细分（isom/mp42/qt/M4A/heic…）
3. 可 UTF-8 解码 → 判为文本
4. 文本且 base64 特征 >95%（或 `data:` 开头）→ **自动解码后再识别一次**，解码结果写入 `--out/decoded*`
5. 后缀与真实类型不一致时明确告警

## 参数行为

| 参数 | 行为 |
|---|---|
| `--out DIR` | 产物目录，默认 `./_probe_out` |
| `--frames N` | 视频抽 N 帧（需 ffmpeg）；**ffmpeg 缺失就明确报错，不猜帧内容** |
| `--extract` | zip 用 `zipfile` 解；tar/gz/bz2/xz/zstd 调 `tar`；失败报具体错误 |
| `--view` | 图片复制原图到 `--out/view<ext>`，便于直接查看 |
| `--json` | 输出结构化结果 |

## 纪律

- **不编造**：ffmpeg 缺失就说缺失，不假装抽帧成功；解压失败报具体 stderr。
- 解压第三方压缩包前先看内容清单，可疑脚本不执行。
- 探测到可执行文件/脚本时，先扫硬编码密钥与可疑外连再决定是否运行。
