#!/usr/bin/env python3
"""
file-probe — 文件魔数识别。不信后缀，只信字节。

用法:
  probe.py <file> [--out DIR] [--frames N] [--extract] [--view] [--json]

能力:
  1. 读前 4096 字节，按魔数判定真实类型（图片/音视频/压缩包/文档/PDF/base64 文本等）
  2. 若内容是 base64 文本（用户常传 .txt 实际是编码后的视频/压缩包/图片），自动解码再识别
  3. --extract 解压压缩包到 --out
  4. --frames N 抽视频帧（需 ffmpeg，缺失时明确报错而不是假装成功）
  5. --view 复制/导出图片原图到 --out，便于直接查看
  6. --json 输出机器可读结果

不编造：ffmpeg 缺失就说缺失，不猜帧内容。
"""
import argparse
import base64
import binascii
import json
import mimetypes
import os
import shutil
import struct
import subprocess
import sys
import zipfile

# ---- 魔数表：(偏移, 字节签名, 类型, 扩展名) ----
SIGNATURES = [
    (0, b"\xff\xd8\xff",                   "image/jpeg",      ".jpg"),
    (0, b"\x89PNG\r\n\x1a\n",              "image/png",       ".png"),
    (0, b"GIF87a",                         "image/gif",       ".gif"),
    (0, b"GIF89a",                         "image/gif",       ".gif"),
    (0, b"RIFF",                           "container/riff",  ".riff"),
    (0, b"\x1a\x45\xdf\xa3",               "video/webm",      ".webm"),
    (0, b"BM",                             "image/bmp",       ".bmp"),
    (0, b"II*\x00",                        "image/tiff",      ".tif"),
    (0, b"MM\x00*",                        "image/tiff",      ".tif"),
    (0, b"%PDF",                           "application/pdf", ".pdf"),
    (0, b"PK\x03\x04",                     "application/zip", ".zip"),
    (0, b"PK\x05\x06",                     "application/zip", ".zip"),
    (0, b"PK\x07\x08",                     "application/zip", ".zip"),
    (0, b"\x1f\x8b",                       "application/gzip",".gz"),
    (0, b"BZh",                            "application/x-bzip2", ".bz2"),
    (0, b"\xfd7zXZ\x00",                   "application/x-xz",".xz"),
    (0, b"7z\xbc\xaf\x27\x1c",             "application/x-7z-compressed", ".7z"),
    (0, b"Rar!\x1a\x07",                   "application/x-rar",".rar"),
    (0, b"\x37\x7a\xbc\xaf\x27\x1c",       "application/x-7z-compressed", ".7z"),
    (0, b"\x04\x22\x4d\x18",               "application/x-lz4",".lz4"),
    (0, b"\x28\xb5\x2f\xfd",               "application/zstd",".zst"),
    (0, b"ustar",                          "application/x-tar",".tar"),
    (0, b"ID3",                            "audio/mpeg",      ".mp3"),
    (0, b"\xff\xfb",                       "audio/mpeg",      ".mp3"),
    (0, b"OggS",                           "audio/ogg",       ".ogg"),
    (0, b"fLaC",                           "audio/flac",      ".flac"),
    (0, b"SQLite format 3\x00",            "application/x-sqlite3", ".sqlite"),
    (0, b"<?xml",                          "text/xml",        ".xml"),
    (0, b"{",                              "application/json",".json"),
    (0, b"#!",                             "text/x-script",   ".sh"),
    (0, b"\xd0\xcf\x11\xe0",               "application/msoffice", ".doc"),  # OLE2
    (0, b"\x25\x21\x50\x53",               "application/postscript", ".ps"),
    (0, b"SQLite",                         "application/x-sqlite3", ".sqlite"),
]

# ftyp 系（mp4/mov/m4a/heic 等）：偏移 4 处是 ftyp
FTYP_BRANDS = {
    b"isom": "video/mp4", b"mp42": "video/mp4", b"mp41": "video/mp4",
    b"avc1": "video/mp4", b"M4V ": "video/mp4", b"M4A ": "audio/mp4",
    b"qt  ": "video/quicktime", b"heic": "image/heic", b"heix": "image/heic",
    b"hevc": "video/mp4", b"3gp4": "video/3gpp", b"MSNV": "video/mp4",
    b"dash": "video/mp4", b"iso2": "video/mp4", b"iso5": "video/mp4",
}


def sniff(head: bytes):
    for off, sig, mime, ext in SIGNATURES:
        if head[off:off + len(sig)] == sig:
            if mime == "container/riff":
                if head[8:12] == b"WEBP":
                    return "image/webp", ".webp"
                if head[8:12] == b"WAVE":
                    return "audio/wav", ".wav"
                if head[8:12] == b"AVI ":
                    return "video/avi", ".avi"
                return mime, ext
            if mime == "application/x-tar":  # ustar 实际在 257；这里兜底
                pass
            return mime, ext
    # ftyp
    if len(head) > 12 and head[4:8] == b"ftyp":
        brand = head[8:12]
        return FTYP_BRANDS.get(brand, ("video/mp4", ".mp4")) if brand in FTYP_BRANDS else ("video/mp4", ".mp4")
    # tar 老格式
    if len(head) > 262 and head[257:262] == b"ustar":
        return "application/x-tar", ".tar"
    # 文本？
    try:
        head.decode("utf-8")
        return "text/plain", ".txt"
    except UnicodeDecodeError:
        pass
    return "application/octet-stream", ".bin"


def looks_like_base64(text: str) -> bool:
    s = "".join(text.split())
    if len(s) < 40:
        return False
    if s.startswith("data:"):
        return True
    ok = sum(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" for c in s)
    return ok / len(s) > 0.95


def main():
    ap = argparse.ArgumentParser(description="文件魔数识别（不信后缀）")
    ap.add_argument("file")
    ap.add_argument("--out", default="./_probe_out")
    ap.add_argument("--frames", type=int, default=0, help="抽视频帧数，需 ffmpeg")
    ap.add_argument("--extract", action="store_true", help="解压压缩包到 --out")
    ap.add_argument("--view", action="store_true", help="导出图片原图到 --out 便于查看")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    path = a.file
    if not os.path.isfile(path):
        sys.exit(f"不是文件: {path}")

    result = {
        "path": os.path.abspath(path),
        "declared_ext": os.path.splitext(path)[1],
        "size": os.path.getsize(path),
        "declared_mime": mimetypes.guess_type(path)[0],
    }

    with open(path, "rb") as f:
        head = f.read(4096)

    real_mime, real_ext = sniff(head)
    result["real_mime"] = real_mime
    result["real_ext"] = real_ext

    working = path

    # base64 文本 → 解码再识别
    if real_mime == "text/plain":
        try:
            text = head.decode("utf-8", "ignore")
        except Exception:
            text = ""
        if looks_like_base64(text):
            os.makedirs(a.out, exist_ok=True)
            raw = open(path, "rb").read()
            if raw.lstrip().startswith(b"data:"):
                raw = raw.split(b",", 1)[1]
            try:
                dec = base64.b64decode(b"".join(raw.split()), validate=False)
            except (binascii.Error, ValueError):
                dec = b""
            if dec:
                dm, de = sniff(dec[:4096])
                dec_path = os.path.join(a.out, "decoded" + de)
                with open(dec_path, "wb") as f:
                    f.write(dec)
                result["base64_decoded"] = {"path": dec_path, "mime": dm, "ext": de, "bytes": len(dec)}
                real_mime, real_ext = dm, de
                result["real_mime"], result["real_ext"] = dm, de
                working = dec_path

    os.makedirs(a.out, exist_ok=True)

    # 图片：导出原图
    if real_mime.startswith("image/") and a.view:
        dst = os.path.join(a.out, "view" + real_ext)
        shutil.copyfile(working, dst)
        result["view"] = dst

    # 压缩包：解压
    if real_mime in ("application/zip",) and a.extract:
        try:
            with zipfile.ZipFile(working) as z:
                names = z.namelist()
                z.extractall(os.path.join(a.out, "extracted"))
            result["extracted"] = {"count": len(names), "dir": os.path.join(a.out, "extracted"),
                                   "sample": names[:20]}
        except Exception as e:
            result["extracted"] = {"error": str(e)}
    elif real_mime in ("application/gzip", "application/x-tar", "application/x-bzip2",
                       "application/x-xz", "application/zstd") and a.extract:
        d = os.path.join(a.out, "extracted")
        os.makedirs(d, exist_ok=True)
        r = subprocess.run(["tar", "xf", working, "-C", d], capture_output=True, text=True)
        result["extracted"] = {"ok": r.returncode == 0, "dir": d, "stderr": r.stderr[:300]}

    # 视频抽帧
    if a.frames and (real_mime.startswith("video/") or real_mime.startswith("audio/")):
        if not shutil.which("ffmpeg"):
            result["frames"] = {"error": "ffmpeg 不可用（不猜测帧内容）"}
        else:
            d = os.path.join(a.out, "frames")
            os.makedirs(d, exist_ok=True)
            r = subprocess.run(
                ["ffmpeg", "-y", "-i", working, "-vf",
                 f"fps=1/{max(1, a.frames)}", "-frames:v", str(a.frames),
                 os.path.join(d, "f%02d.jpg")],
                capture_output=True, text=True)
            got = sorted(os.listdir(d)) if os.path.isdir(d) else []
            result["frames"] = {"ok": r.returncode == 0, "count": len(got),
                                "dir": d, "stderr": r.stderr[-300:]}

    if a.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    print(f"文件        : {result['path']}")
    print(f"声明后缀    : {result['declared_ext'] or '(无)'}  声明 MIME: {result['declared_mime']}")
    print(f"真实类型    : {result['real_mime']}  ({result['real_ext']})")
    print(f"大小        : {result['size']} 字节")
    if "base64_decoded" in result:
        b = result["base64_decoded"]
        print(f"⚠ base64 伪装: 已解码 -> {b['path']}  ({b['mime']}, {b['bytes']} 字节)")
    if result["declared_ext"] and result["real_ext"] and \
       result["declared_ext"].lower() != result["real_ext"]:
        print("⚠ 后缀与真实类型不一致 —— 以后缀判断会翻车")
    for k in ("view", "extracted", "frames"):
        if k in result:
            print(f"{k:11}: {result[k]}")


if __name__ == "__main__":
    main()
