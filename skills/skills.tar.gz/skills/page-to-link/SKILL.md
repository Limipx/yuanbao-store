---
name: page-to-link
description: |
  把本地项目部署成可访问链接。负责选部署通道、执行部署命令、拿到真实 URL、并验证链接可访问。
  当用户要"部署上线""给我个链接""发到网上能打开""预览地址"时使用。
  触发词：部署、上线、给我个链接、预览地址、publish、deploy。
version: "2.0"
author: "重建于 2026-10-04（原版仅存在于已丢失备份包，按规格重建）"
---

# page-to-link — 部署拿链接

## 铁律

**链接必须是部署命令真实输出的，禁止编造、拼凑、或写"理论上会是 xxx"。**
拿不到链接就如实说拿不到，并说明卡在哪一步。

## 通道选择

| 场景 | 通道 | 备注 |
|---|---|---|
| 纯静态站点 | 静态托管（Pages / OSS / COS / Vercel 类） | 首选，零后端 |
| 带后端服务 | 需常驻进程 → 本环境无守护进程，先告知用户限制 |
| 临时预览 | 内网穿透 / 沙盒临时端口 | 有时效，需说明 |
| 沙盒内验证 | `python3 -m http.server` + 本地 curl | 只有本地 URL，不是公网链接 |

## 标准流程

1. **预检**：构建产物存在？入口文件对不对？`ls -la dist/ && wc -c dist/index.html`
2. **试点**：先本地起服务 `python3 -m http.server 8000 -d dist`，`curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8000/` 必须 200
3. **备份**：打包一份当前产物 `tar czf dist-$(date +%s).tgz dist/`
4. **执行部署**：跑真实部署命令，捕获 stdout
5. **后检**：从命令输出里提取 URL（正则 `https?://\S+`），不要手敲
6. **验证**：`curl -sS -o /dev/null -w '%{http_code}' <URL>` 必须 200/3xx，并回读正文确认内容对得上
7. **回读**：把 URL 与状态码一起交给用户

```bash
URL=$(deploy_cmd 2>&1 | grep -oE 'https?://[^ ]+' | head -1)
[ -z "$URL" ] && { echo "部署未返回链接"; exit 1; }
curl -sS -o /dev/null -w "status=%{http_code}\n" "$URL"
```

## 纪律

- 部署失败就报失败原因（看命令真实 stderr），不要重试超过必要次数
- 涉及生产/正式环境的操作，先跟用户确认目标环境
- 返回的链接要说明时效（临时预览 vs 长期托管）
- 沙盒内 `http.server` 起的地址**不是公网可访问链接**，说清楚，别让用户拿去分享
