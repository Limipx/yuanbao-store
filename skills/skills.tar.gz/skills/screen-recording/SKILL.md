---
name: screen-recording
description: |
  录屏与 GIF 生成。把一段操作过程录成视频，再压缩成适合文档/聊天里展示的小体积 GIF；
  负责帧率、分辨率、时长与体积的平衡，以及录制前的场景准备和录制后的体积校验。
  当用户要"录个操作过程""做个演示动图""生成 GIF""录屏"时使用。
  触发词：录屏、做 GIF、演示动图、操作录屏、转成 gif。
version: "2.0"
author: "重建于 2026-10-04（原版仅存在于已丢失备份包，按规格重建）"
---

# screen-recording — 录屏转 GIF

## 本环境事实

- `ffmpeg` 存在于 `/usr/bin/ffmpeg`，可用
- **无 crontab、无常驻守护进程** → 只能"命令跑多久录多久"，不能起常驻录制服务
- 沙盒多为无显示环境，浏览器录制需 Xvfb 或走 agent-browser 的无头录像能力

## 标准流程

1. **场景准备**：确认要录什么、起始状态、每步动作、预计时长。**先演练一遍再录**
2. **录屏**
   ```bash
   # 有 Xvfb / 有 DISPLAY 时
   /usr/bin/ffmpeg -f x11grab -video_size 1280x720 -framerate 15 -i :99 -t 60 out.mp4
   ```
   无显示环境 → 改走 agent-browser 的录制能力，或改用分步截图合成
3. **转 GIF**（两阶段调色板，体积小很多）
   ```bash
   /usr/bin/ffmpeg -i out.mp4 -vf "fps=10,scale=800:-1:flags=lanczos" -c:v gif frame.gif
   # 或更优：先生成调色板
   /usr/bin/ffmpeg -i out.mp4 -vf "fps=10,scale=800:-1:flags=lanczos,palettegen" pal.png
   /usr/bin/ffmpeg -i out.mp4 -i pal.png -filter_complex \
     "fps=10,scale=800:-1:flags=lanczos[x];[x][1:v]paletteuse" out.gif
   ```
4. **体积校验**（硬要求）
   ```bash
   ls -l out.gif | awk '{print $5}'
   ```
   目标：聊天内嵌 <5MB，文档配图 <2MB。超了就降 fps（10→8）、缩宽（800→640）、或裁时长
5. **回读**：真打开看一遍，确认动作完整、无卡顿、无黑屏段

## 参数速查

| 用途 | fps | 宽度 | 预期体积（60s） |
|---|---|---|---|
| 文档配图 | 8 | 640 | 1-2MB |
| 聊天展示 | 10 | 800 | 3-5MB |
| 细节演示 | 15 | 1000 | 8-15MB |

## 纪律

- 交付前必须真看过成品，不能只报"已生成"
- 体积超标要主动降参数重出，不要丢一个 20MB 的 GIF 给用户
- 录到的画面若含敏感信息（密钥、个人信息），先打码或重录
