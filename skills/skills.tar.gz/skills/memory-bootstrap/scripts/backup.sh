#!/usr/bin/env bash
# backup.sh — 全量快照（手动 / 需要时跑），并同步三层冗余
set -u
VAULT=/root/.skillvault
L2="$HOME"; L3=/data/workspace
FULL=skills-bundle.zip
ts=$(date '+%Y%m%d-%H%M%S')

mkdir -p "$VAULT"
out="$VAULT/$FULL"
if command -v zip >/dev/null 2>&1; then
  ( cd / && zip -qry "$out" data/skills data/memory -x '*.git*' '*__pycache__*' )
else
  out="${out%.zip}.tgz"
  ( cd / && tar czf "$out" data/skills data/memory )
fi
echo "全量包: $out ($(du -h "$out" | cut -f1))"

for d in "$L2" "$L3"; do
  mkdir -p "$d" 2>/dev/null
  cp -f "$out" "$d/$(basename "$out")" 2>/dev/null && echo "已同步 -> $d/$(basename "$out")" || echo "同步失败: $d"
done

# 同时留一份带时间戳的历史快照（保留最近 5 份）
cp -f "$out" "$VAULT/skills-full-$ts.${out##*.}" 2>/dev/null
ls -1t "$VAULT"/skills-full-* 2>/dev/null | tail -n +6 | xargs -r rm -f
echo "完成: skills=$(ls /data/skills 2>/dev/null | wc -l) memory=$(ls /data/memory 2>/dev/null | wc -l)"
