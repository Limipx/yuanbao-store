#!/usr/bin/env bash
# gen-card.sh — 生成/刷新「恢复卡」（一段可直接贴给 AI 的恢复提示词）
# 产物：/root/.skillvault/RECOVERY_CARD.md，并同步三层冗余
set -u
VAULT=/root/.skillvault
L2="$HOME"; L3=/data/workspace
CARD="$VAULT/RECOVERY_CARD.md"
mkdir -p "$VAULT"

n=$(ls /data/skills 2>/dev/null | wc -l)
names=$(ls /data/skills 2>/dev/null | tr '\n' ' ')
[ -f /data/skills/memory-bootstrap/scripts/sync.sh ] && sync_ok=有 || sync_ok=无

cat > "$CARD" <<EOF
# 能力恢复卡（自动生成 $(date '+%F %T')）

技能库现状：/data/skills 共 $n 个 —— $names
sync.sh 状态：$sync_ok

## 恢复步骤（照做）

1. 优先增量同步（检测+恢复+备份一条命令）：
   bash /data/skills/memory-bootstrap/scripts/sync.sh

2. 若 sync.sh 不存在（脚本也一起没了）：零依赖解压，必须在 / 下
   cd / && unzip -qo /root/.skillvault/skills-bundle.zip \\
     || unzip -qo ~/skills-bundle.zip \\
     || unzip -qo /data/workspace/skills-bundle.zip
   （包内路径是 data/skills/...，在 /data 下解压会生成 /data/data/skills，等于没恢复）

3. 备份包也全丢了：网络兜底，走 codeload 不走 api
   cd /tmp && curl -sSL -m 180 -o r.tgz \\
     "https://codeload.github.com/<owner>/<repo>/tar.gz/refs/heads/main" \\
     && mkdir -p x && tar xzf r.tgz -C x && ls x

   核心上游：
   - dev-expert            ebandao777-oss/dev-expert                "."
   - skill-creator / frontend-design / canvas-design / webapp-testing / brand-guidelines
                           anthropics/skills                        "skills/<名>"
   - crawl4ai              brettdavies/crawl4ai-skill               "."
   - game-developer        Jeffallan/claude-skills                  "skills/game-developer"
   - agent-browser         vercel-labs/agent-browser                "skill-data/core"
   - web-reverse-engineering  kings0527/web-reverse-engineering-skill（分支 master） "."
   - video                 coreyhaines31/marketingskills            "skills/video"

   下载后必须校验（防 404 页面冒充）：
   gzip -t r.tgz
   head -12 /data/skills/<name>/SKILL.md    # frontmatter 必须有 name + description
   wc -c  /data/skills/<name>/SKILL.md      # <500B 大概率是错误页

4. 验证（不通过别往下走）
   ls /data/skills | wc -l    # 期望 >= 40
   ls /data/memory            # 期望 MEMORY.md SESSION_LOG.md snapshots

5. 恢复后必读经验（不读等于没迁移）
   cat /data/memory/MEMORY.md
   cat /data/memory/SESSION_LOG.md
   cat /data/memory/.ai-memory/DECISIONS.md
   cat /data/memory/.ai-memory/CONVENTIONS.md
   cat /data/memory/.ai-memory/ERROR_LEDGER.md

## 网络通路实测
codeload.github.com ✅（首选，不计配额）｜api.github.com ⚠️60次/小时｜
skillhub.cn ❌403｜registry.npmjs.org ❌403｜cdn.jsdelivr.net ❌301→502｜raw.githubusercontent.com ❌超时
EOF

for d in "$L2" "$L3"; do
  mkdir -p "$d" 2>/dev/null
  cp -f "$CARD" "$d/RECOVERY_CARD.md" 2>/dev/null
done
echo "恢复卡已生成: $CARD（三层冗余）"
