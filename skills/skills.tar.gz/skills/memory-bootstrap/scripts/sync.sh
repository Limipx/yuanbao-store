#!/usr/bin/env bash
# sync.sh — 检测 + 恢复 + 增量备份（一条命令，可每次会话开场都跑）
# 五步：检测完整性 → 缺失自动从备份包还原 → 扫指纹 → 比对差异 → 有变化才打增量包 → 同步三层冗余
# 无变更时完全不打包。零依赖：bash + python3 + unzip/zip（缺失则自动降级为 tar）

set -u

SKILLS=/data/skills
MEM=/data/memory
VAULT=/root/.skillvault
L1="$VAULT"; L2="$HOME"; L3=/data/workspace
FULL=skills-bundle.zip
FP="$VAULT/.fingerprints.txt"
LOG="$VAULT/sync.log"

mkdir -p "$VAULT" "$MEM"
log(){ echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }

# ---------- Step 1: 检测完整性 ----------
n=$(ls "$SKILLS" 2>/dev/null | wc -l)
[ -f "$MEM/MEMORY.md" ] && mem_ok=1 || mem_ok=0
log "检测: skills=$n memory=$mem_ok"

# ---------- Step 2: 缺失则从备份包还原（必须在 / 下解压） ----------
restore(){
  for p in "$L1/$FULL" "$L2/$FULL" "$L3/$FULL"; do
    if [ -f "$p" ]; then
      log "发现备份包: $p"
      ( cd / && unzip -qo "$p" ) && { log "已从 $p 还原"; return 0; }
      log "还原失败: $p"
    fi
  done
  return 1
}

if [ "$n" -lt 20 ] || [ "$mem_ok" -eq 0 ]; then
  log "完整性不足，尝试从备份还原"
  restore || log "无可用备份包，需走网络兜底（见 memory-bootstrap/SKILL.md）"
  n=$(ls "$SKILLS" 2>/dev/null | wc -l)
  [ -f "$MEM/MEMORY.md" ] && mem_ok=1 || mem_ok=0
  log "还原后: skills=$n memory=$mem_ok"
fi

# ---------- Step 2b: 单项缺失也还原（只抽缺失项，不覆盖本地新版） ----------
# 关键：不能让"删除"被当成变更写进基线，否则技能会被永久丢掉
if command -v unzip >/dev/null 2>&1; then
  for p in "$L1/$FULL" "$L2/$FULL" "$L3/$FULL"; do
    [ -f "$p" ] || continue
    miss=$(unzip -Z1 "$p" 2>/dev/null | grep '^data/skills/' \
           | cut -d/ -f3 | sort -u | while read -r d; do
             [ -n "$d" ] && [ ! -e "$SKILLS/$d" ] && echo "$d"
           done)
    if [ -n "$miss" ]; then
      log "检测到缺失技能: $(printf '%s' "$miss" | tr '\n' ' ')"
      printf '%s\n' "$miss" | while read -r d; do
        [ -n "$d" ] || continue
        ( cd / && unzip -qo "$p" "data/skills/$d/*" ) \
          && log "已还原: $d" || log "还原失败: $d"
      done
    fi
    break
  done
  n=$(ls "$SKILLS" 2>/dev/null | wc -l)
fi

# ---------- Step 3: 扫指纹 ----------
tmp_fp=$(mktemp)
python3 - "$SKILLS" "$MEM" > "$tmp_fp" <<'PY'
import hashlib, os, sys
roots = [sys.argv[1], sys.argv[2]]
for root in roots:
    if not os.path.isdir(root): continue
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ('.git', '__pycache__')]
        for f in sorted(filenames):
            # 跳过 dotfile（.gitignore/.gitattributes 等）：被 -x '*.git*' 排除在包外，
            # 还原后必然"缺失"，若纳入指纹会永久污染基线
            if f.startswith('.'):
                continue
            p = os.path.join(dirpath, f)
            try:
                if os.path.islink(p): continue
                with open(p, 'rb') as fh: h = hashlib.sha1(fh.read()).hexdigest()
            except Exception:
                h = 'ERR'
            print(f"{h}\t{p}")
PY

# ---------- Step 4: 比对差异 ----------
changed=""
if [ -f "$FP" ]; then
  changed=$(python3 - "$FP" "$tmp_fp" <<'PY'
import sys
def load(p):
    d={}
    for line in open(p):
        parts=line.rstrip('\n').split('\t',1)
        if len(parts)==2: d[parts[1]]=parts[0]
    return d
old,new=load(sys.argv[1]),load(sys.argv[2])
keys=set(old)|set(new)
out=[k for k in sorted(keys) if old.get(k)!=new.get(k)]
print('\n'.join(out))
PY
)
else
  log "无历史指纹，视为首次：生成基线并打全量包"
  changed="__FIRST__"
fi

cnt=$(printf '%s' "$changed" | grep -c . || true)

# ---------- Step 5: 有变化才打包 ----------
if [ "$cnt" -eq 0 ]; then
  log "无变更，不打包（指纹已比对）"
else
  ts=$(date '+%Y%m%d-%H%M%S')
  if [ "$changed" = "__FIRST__" ] || [ "$cnt" -gt 200 ]; then
    bundle="$VAULT/$FULL"
    ( cd / && zip -qry "$bundle" data/skills data/memory -x '*.git*' '*__pycache__*' ) \
      || ( cd / && tar czf "${bundle%.zip}.tgz" data/skills data/memory )
    log "打全量包: $bundle"
  else
    delta="$VAULT/skills-delta-$ts.zip"
    printf '%s\n' "$changed" > "$VAULT/.delta-$ts.list"
    # 实测：zip -i@ 会打出空包。改为建临时树再打包，并做体积校验
    tmptree=$(mktemp -d)
    while IFS= read -r p; do
      [ -f "$p" ] || continue
      mkdir -p "$tmptree/$(dirname "$p")"
      cp -f "$p" "$tmptree/$p" 2>/dev/null
    done < "$VAULT/.delta-$ts.list"
    ( cd "$tmptree" && zip -qry "$delta" . ) 2>/dev/null
    if [ ! -s "$delta" ] || [ "$(wc -c < "$delta")" -lt 200 ]; then
      rm -f "$delta"
      ( cd "$tmptree" && tar czf "${delta%.zip}.tgz" . ) \
        && log "zip 降级为 tar: ${delta%.zip}.tgz" || log "增量打包失败"
    fi
    rm -rf "$tmptree"
    # 变更较多时同步刷新全量，避免增量链过长
    if [ "$cnt" -gt 20 ]; then
      ( cd / && zip -qry "$VAULT/$FULL" data/skills data/memory -x '*.git*' '*__pycache__*' ) 2>/dev/null
      log "变更 $cnt 项，同时刷新全量包"
    fi
    log "打增量包: $delta （$cnt 项）"
  fi
fi

# ---------- Step 6: 同步三层冗余 ----------
for f in "$VAULT"/"$FULL" "$VAULT"/skills-delta-*.zip "$VAULT"/*.tgz; do
  [ -f "$f" ] || continue
  b=$(basename "$f")
  for d in "$L2" "$L3"; do
    [ "$d" = "$VAULT" ] && continue
    mkdir -p "$d" 2>/dev/null
    cp -f "$f" "$d/$b" 2>/dev/null || log "同步失败（可忽略）: $d/$b"
  done
done
log "三层冗余同步完成"

cp -f "$tmp_fp" "$FP" 2>/dev/null
rm -f "$tmp_fp"
log "指纹基线已更新"
log "最终: skills=$(ls $SKILLS 2>/dev/null | wc -l) memory=$(ls $MEM 2>/dev/null | wc -l)"
