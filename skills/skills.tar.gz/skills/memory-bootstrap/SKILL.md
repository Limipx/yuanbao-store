---
name: memory-bootstrap
description: |
  记忆与技能库自恢复。每次会话开场跑 sync.sh 做「检测完整性 → 缺失自动从备份包还原 → 扫文件指纹 →
  比对差异 → 有变化才打增量包 → 同步三层冗余」；需要时用 backup.sh 打全量快照、gen-card.sh 刷新恢复卡。
  当会话开头发现 /data/skills 或 /data/memory 被重置、技能数量骤减、memory 目录为空、
  需要恢复技能库或迁移历史经验时使用。
  触发词：能力恢复、技能库被重置、sync、备份、恢复卡、记忆自恢复、迁移经验。
version: "2.0"
author: "重建于 2026-10-04"
---

# memory-bootstrap — 记忆与技能库自恢复

## 铁律

`/data/skills` 与 `/data/memory` 每次会话都可能被重置。不能靠"记得自己有什么技能"，**必须每次跑检测**。

## 开场一条命令

```bash
bash /data/skills/memory-bootstrap/scripts/sync.sh
```

行为：
1. **检测**：`ls /data/skills | wc -l`（<20 视为异常）、`/data/memory/MEMORY.md` 是否存在
2. **还原**：异常时依次尝试 `/root/.skillvault/` → `~/` → `/data/workspace/` 下的 `skills-bundle.zip`，
   **在 `/` 下解压**（包内路径是 `data/skills/...`，在 `/data` 下解压会生成 `/data/data/skills`，等于没恢复）
3. **扫指纹**：对 `/data/skills` 与 `/data/memory` 下所有文件取 sha1
4. **比对**：与上次基线比对，无变化就什么都不做
5. **打包**：有变化才打增量包（>200 项变更或首次则打全量），同步三层冗余

无变更时完全不打包，可放心每次都跑。

## 全量备份（手动 / 需要时）

```bash
bash /data/skills/memory-bootstrap/scripts/backup.sh     # 全量快照 + 三层冗余 + 保留最近5份历史
bash /data/skills/memory-bootstrap/scripts/gen-card.sh   # 刷新 RECOVERY_CARD.md（可直接贴给 AI 的恢复提示词）
```

三层冗余：`/root/.skillvault/` → `~/` → `/data/workspace/`

## 备份包全丢时的网络兜底

**走 codeload，不走 api**（api 未鉴权 60 次/小时，拉十几个技能必撞墙）：

```bash
cd /tmp && curl -sSL -m 180 -o r.tgz \
  "https://codeload.github.com/<owner>/<repo>/tar.gz/refs/heads/main" \
  && mkdir -p x && tar xzf r.tgz -C x && ls x
```

| 技能 | 上游仓库 | 子目录 |
|---|---|---|
| dev-expert | ebandao777-oss/dev-expert | `.` |
| skill-creator / frontend-design / canvas-design / webapp-testing / brand-guidelines | anthropics/skills | `skills/<名>` |
| crawl4ai | brettdavies/crawl4ai-skill | `.` |
| game-developer | Jeffallan/claude-skills | `skills/game-developer` |
| agent-browser | vercel-labs/agent-browser | `skill-data/core` |
| web-reverse-engineering | kings0527/web-reverse-engineering-skill（**分支 master**） | `.` |
| video | coreyhaines31/marketingskills | `skills/video` |

**下载后必须校验**（防止拿到 404 页面）：

```bash
gzip -t r.tgz                            # 先校验再解压（部分仓库默认分支非 main）
head -12 /data/skills/<name>/SKILL.md    # frontmatter 必须有 name + description
wc -c  /data/skills/<name>/SKILL.md      # <500B 大概率是错误页
```

**网络通路实测**：codeload ✅（首选）｜api ⚠️ 60次/小时｜skillhub.cn ❌ 403｜
registry.npmjs.org ❌ 403｜cdn.jsdelivr.net ❌ 301→502｜raw.githubusercontent.com ❌ 超时

## 验证（不通过就别往下走）

```bash
ls /data/skills | wc -l     # 期望 >= 40
ls /data/memory             # 期望 MEMORY.md SESSION_LOG.md snapshots
```

## 恢复后必须真的读

```bash
cat /data/memory/MEMORY.md                    # 环境事实、已建能力、铁律
cat /data/memory/SESSION_LOG.md               # 任务进度表
cat /data/memory/.ai-memory/DECISIONS.md      # 架构决策（含被否决方案与原因）
cat /data/memory/.ai-memory/CONVENTIONS.md    # 目录约定、标准命令集
cat /data/memory/.ai-memory/ERROR_LEDGER.md   # 踩过的坑与解法
```

只恢复文件不读进上下文，等于没迁移经验。

## 教训（2026-10-04）

三层冗余**同时**丢失过一次——环境整体重置时本地备份与其同生命周期。
所以：自建技能的 SKILL.md 必须写清**行为规格**，而不只是"跑某个脚本"，
否则脚本一丢能力就永久消失。
